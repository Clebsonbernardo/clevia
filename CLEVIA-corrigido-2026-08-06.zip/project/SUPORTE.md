# Clevia — Manual de Suporte Técnico

## Visão Geral

O Clevia é um sistema de gestão de manutenção industrial (CMMS) multi-empresa. Cada empresa cliente tem seus próprios dados isolados (máquinas, ordens de serviço, mecânicos, estoque, etc.). O administrador do sistema (Clevia) gerencia empresas, licenças e configurações globais.

## Perfis de Usuário

| Perfil | Acesso |
|--------|--------|
| Admin Clevia | Acesso total ao sistema, gestão de empresas, licenças e configurações |
| CEO (cliente) | Administrador da empresa: cadastra máquinas, setores, mecânicos, usuários |
| Gerente | Cria e gerencia ordens de serviço, acessa relatórios |
| Mecânico | Recebe, aceita, executa e finaliza ordens de serviço |
| Supervisora | Registra produção, acessa indicadores |
| Solicitante | Cadastra máquinas e itens de estoque |

## Fluxos Principais

### 1. Cadastro de Nova Empresa Cliente

1. Acesse a tela **Licenças** (apenas admin Clevia)
2. Clique em **Cadastrar nova empresa**
3. Preencha o assistente de 4 etapas:
   - **Empresa**: nome e CNPJ
   - **Responsável**: nome, e-mail e senha do CEO
   - **Plano**: teste gratuito (60 dias) ou pago
   - **Revisão**: confirme os dados
4. Ao confirmar, a empresa é criada e o CEO já pode acessar o sistema

### 2. Criação de Ordem de Serviço (OS)

1. O **gerente** ou **CEO** acessa **Ordens de Serviço**
2. Clica em **Nova OS**
3. Seleciona a máquina, descreve o problema e define a prioridade
4. A OS é criada com status **aberta** e notifica os mecânicos disponíveis

### 3. Atendimento de OS pelo Mecânico

1. O mecânico vê a OS na sua lista
2. Clica em **Aceitar** — o status muda para **em andamento**
3. Se necessário, pode **pausar** para atender outra OS de maior prioridade
4. Ao concluir, clica em **Finalizar OS** e preenche a descrição do serviço

### 4. Aprovação de OS (quando necessário)

1. Quando uma OS requer aprovação, o gerente recebe notificação
2. O gerente aprova ou reprova na tela de detalhes da OS
3. Se aprovado pelo gerente e a OS exigir aprovação do CEO, o CEO é notificado

### 5. Gestão de Estoque

1. **CEO** ou **solicitante** cadastra itens no estoque
2. Itens podem ter quantidade, custo e fornecedor
3. É possível dar **baixa** (saída) ou **entrada** de itens

### 6. Monitoramento (Telões)

1. **CEO**, **gerente** ou usuários com permissão específica criam telas de monitoramento
2. Cada tela mostra o quadro de setores em tempo real
3. As telas podem ser exibidas em monitores de fábrica

## Troubleshooting

### O usuário não consegue fazer login

- Verifique se a conta foi criada (tela de Licenças mostra o e-mail do CEO)
- Confirme que a senha tem no mínimo 6 caracteres
- Se a empresa está com licença bloqueada, o login será redirecionado para tela de licença

### A OS não aparece para o mecânico

- Confirme que o mecânico está cadastrado na empresa (tela Mecânicos)
- Verifique se o mecânico está com status **disponível** (não em atendimento de outra OS)
- A OS deve estar com status **aberta** e a máquina pertencer à mesma empresa

### Notificações não chegam

- O usuário precisa permitir notificações no navegador
- Para push mobile, o usuário precisa acessar o sistema no celular e aceitar o prompt de notificações
- Verifique se a chave VAPID está configurada em Configurações

### Dados não carregam (tela vazia)

- Verifique a conexão com internet
- O sistema funciona offline com dados em cache, mas precisa sincronizar quando voltar online
- Se o problema persistir, recarregue a página (F5)

### Erro "Licença expirada"

- Acesse a tela de Licenças como admin Clevia
- Verifique o status da licença da empresa
- Se necessário, renove por mais 30 dias ou altere para plano pago

## Manutenção do Sistema

### Backup do Banco de Dados

O sistema possui uma Edge Function de backup automático. Para backup manual:
1. Acesse **Configurações** como admin
2. Clique em **Backup do banco de dados**
3. O arquivo SQL será baixado

### Reset Diário de Produção

O sistema executa automaticamente à meia-noite (00:00) um reset dos logs de produção do dia, arquivando-os no histórico. Isso é feito via pg_cron e não requer intervenção manual.

### Adicionar Nova Tela/Funcionalidade

1. Crie o componente em `src/screens/`
2. Adicione a rota em `src/App.tsx`
3. Configure as permissões em `src/lib/useGrants.ts`
4. Adicione o item de menu em `src/components/AppLayout.tsx`

## Contato

Para suporte técnico, entre em contato com o administrador do sistema Clevia.
