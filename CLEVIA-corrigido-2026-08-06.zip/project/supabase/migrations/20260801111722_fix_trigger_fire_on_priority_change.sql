-- Fix: trigger should also fire when priority changes, not just status.
-- If an OS priority is updated from 'media' to 'critica' while status stays
-- 'aberta', the machine status must be recalculated.

CREATE OR REPLACE FUNCTION sync_machine_status_on_os_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  m_id uuid;
  has_critical boolean;
  has_active boolean;
BEGIN
  m_id := COALESCE(NEW.machine_id, OLD.machine_id);
  IF m_id IS NULL THEN
    RETURN COALESCE(NEW, OLD);
  END IF;

  -- Fire on DELETE, or on INSERT/UPDATE when status OR priority OR machine_id changes
  IF TG_OP = 'DELETE' OR (
    TG_OP IN ('INSERT','UPDATE') AND (
      NEW.status IS DISTINCT FROM OLD.status
      OR NEW.priority IS DISTINCT FROM OLD.priority
      OR NEW.machine_id IS DISTINCT FROM OLD.machine_id
    )
  ) THEN

    SELECT
      EXISTS(
        SELECT 1 FROM work_orders
        WHERE machine_id = m_id
          AND status IN ('aberta', 'em_andamento', 'pausada')
          AND priority IN ('critica', 'alta')
      ),
      EXISTS(
        SELECT 1 FROM work_orders
        WHERE machine_id = m_id
          AND status IN ('aberta', 'em_andamento', 'pausada')
      )
    INTO has_critical, has_active;

    IF has_critical THEN
      UPDATE machines SET status = 'parada' WHERE id = m_id;
    ELSIF has_active THEN
      UPDATE machines SET status = 'manutencao' WHERE id = m_id AND status <> 'manutencao';
    ELSE
      UPDATE machines SET status = 'producao' WHERE id = m_id AND status IN ('parada', 'manutencao');
    END IF;

  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;
