/*
# Admin Roles, Pricing Config, and Pagination Support

1. New Tables
- `system_admins` — stores admin email addresses that have full system access (replaces hardcoded email check)
  - `email` (text, primary key) — admin email
  - `created_at` (timestamptz)
- `system_pricing` — stores configurable pricing (replaces hardcoded frontend price)
  - `id` (int, primary key, default 1) — singleton row
  - `price_per_user` (numeric, default 49.90) — monthly cost per user in BRL
  - `trial_days` (int, default 60) — trial period length
  - `updated_at` (timestamptz)

2. Security
- RLS enabled on both tables
- `system_admins`: only authenticated users can read (to check if they're admin); only admin can insert/delete
- `system_pricing`: anyone can read (needed for license display); only admin can update

3. Important Notes
- The hardcoded admin email 'clebsonbernardovelho@gmail.com' is seeded into system_admins
- Frontend will query system_admins instead of comparing hardcoded email
- Pricing is now server-side, preventing client-side tampering
*/

CREATE TABLE IF NOT EXISTS system_admins (
  email text PRIMARY KEY,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE system_admins ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "authenticated_read_admins" ON system_admins;
CREATE POLICY "authenticated_read_admins"
ON system_admins FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_admins" ON system_admins;
CREATE POLICY "admin_insert_admins"
ON system_admins FOR INSERT
TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM system_admins WHERE email = auth.jwt() ->> 'email')
);

DROP POLICY IF EXISTS "admin_delete_admins" ON system_admins;
CREATE POLICY "admin_delete_admins"
ON system_admins FOR DELETE
TO authenticated USING (
  EXISTS (SELECT 1 FROM system_admins WHERE email = auth.jwt() ->> 'email')
);

-- Seed the initial admin
INSERT INTO system_admins (email)
VALUES ('clebsonbernardovelho@gmail.com')
ON CONFLICT (email) DO NOTHING;

CREATE TABLE IF NOT EXISTS system_pricing (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  price_per_user numeric(10,2) DEFAULT 49.90,
  trial_days int DEFAULT 60,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE system_pricing ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anyone_read_pricing" ON system_pricing;
CREATE POLICY "anyone_read_pricing"
ON system_pricing FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_pricing" ON system_pricing;
CREATE POLICY "admin_update_pricing"
ON system_pricing FOR UPDATE
TO authenticated USING (
  EXISTS (SELECT 1 FROM system_admins WHERE email = auth.jwt() ->> 'email')
) WITH CHECK (
  EXISTS (SELECT 1 FROM system_admins WHERE email = auth.jwt() ->> 'email')
);

-- Seed default pricing
INSERT INTO system_pricing (id, price_per_user, trial_days)
VALUES (1, 49.90, 60)
ON CONFLICT (id) DO NOTHING;