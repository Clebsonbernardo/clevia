/*
# Allow gerente and admin roles to delete sectors and their machines

## Why
The SectorBoardScreen shows a delete button for users with ceo, gerente, or admin roles.
However, the RLS policies on monitor_screens, machines, and work_orders only allow
ceo (or manage_screens grant holders) to delete. This causes the delete to silently
fail for gerente/admin users.

## Changes
1. monitor_screens DELETE policy: also allow gerente and admin roles
2. machines DELETE policy: also allow gerente and admin roles
3. work_orders DELETE policy: also allow gerente and admin roles
*/

-- monitor_screens: replace DELETE policy to include gerente and admin
DROP POLICY IF EXISTS delete_monitor_screens_authorized ON monitor_screens;
DROP POLICY IF EXISTS delete_monitor_screens_ceo ON monitor_screens;
CREATE POLICY delete_monitor_screens_authorized
  ON monitor_screens FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = monitor_screens.company_id
        AND cm.user_id = auth.uid()
        AND (cm.role IN ('ceo', 'gerente', 'admin') OR has_manage_screens_grant(cm.company_id, auth.uid()))
    )
  );

-- machines: replace DELETE policy to include gerente and admin
DROP POLICY IF EXISTS delete_machines_ceo ON machines;
DROP POLICY IF EXISTS delete_machines_authorized ON machines;
CREATE POLICY delete_machines_authorized
  ON machines FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = machines.company_id
        AND cm.user_id = auth.uid()
        AND cm.role IN ('ceo', 'gerente', 'admin')
    )
  );

-- work_orders: replace DELETE policy to include gerente and admin
DROP POLICY IF EXISTS delete_work_orders_own ON work_orders;
DROP POLICY IF EXISTS delete_work_orders_authorized ON work_orders;
CREATE POLICY delete_work_orders_authorized
  ON work_orders FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = work_orders.company_id
        AND cm.user_id = auth.uid()
        AND cm.role IN ('ceo', 'gerente', 'admin')
    )
  );
