/*
  # Remover a policy antiga que ainda permitia auditoria falsificada

  Havia uma segunda policy de INSERT (`insert_audit_logs_company`) sem a
  amarração do usuário. Como policies permissivas se somam, ela mantinha o
  problema aberto. Fica apenas `insert_audit_logs`, que exige
  `user_id = auth.uid()`.
*/

DROP POLICY IF EXISTS "insert_audit_logs_company" ON public.audit_logs;
