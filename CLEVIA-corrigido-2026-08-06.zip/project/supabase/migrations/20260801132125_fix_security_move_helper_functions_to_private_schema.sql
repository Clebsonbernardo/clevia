-- 1. Create private schema (NOT exposed via REST API)
CREATE SCHEMA IF NOT EXISTS private;

-- 2. Recreate helper functions in private schema
CREATE OR REPLACE FUNCTION private.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT EXISTS (
  SELECT 1 FROM auth.users
  WHERE id = auth.uid() AND email = 'clebsonbernardovelho@gmail.com'
);
$$;

CREATE OR REPLACE FUNCTION private.is_clevia_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT EXISTS (
  SELECT 1 FROM auth.users
  WHERE id = auth.uid() AND email = 'clebsonbernardovelho@gmail.com'
);
$$;

CREATE OR REPLACE FUNCTION private.is_company_ceo(check_company_id uuid, check_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT EXISTS (
  SELECT 1 FROM public.company_members
  WHERE company_id = check_company_id AND user_id = check_user_id AND role = 'ceo'
);
$$;

CREATE OR REPLACE FUNCTION private.is_company_member(check_company_id uuid, check_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT EXISTS (
  SELECT 1 FROM public.company_members
  WHERE company_id = check_company_id AND user_id = check_user_id
);
$$;

CREATE OR REPLACE FUNCTION private.is_company_owner(check_company_id uuid, check_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT EXISTS (
  SELECT 1 FROM public.companies
  WHERE id = check_company_id AND owner_id = check_user_id
);
$$;

CREATE OR REPLACE FUNCTION private.is_license_active(p_company_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT NOT EXISTS (
  SELECT 1 FROM company_licenses cl
  WHERE cl.company_id = p_company_id
  AND (
    cl.status IN ('canceled', 'blocked')
    OR cl.expires_at < now()
    OR (cl.plan = 'paid' AND cl.next_payment_date IS NOT NULL AND cl.next_payment_date < CURRENT_DATE)
  )
);
$$;

CREATE OR REPLACE FUNCTION private.has_manage_screens_grant(p_company_id uuid, p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT EXISTS (
  SELECT 1 FROM ceo_grants
  WHERE company_id = p_company_id
  AND user_id = p_user_id
  AND permission_key = 'manage_screens'
  AND granted = true
);
$$;

-- 3. Update get_company_license_status to use private schema helpers
CREATE OR REPLACE FUNCTION public.get_company_license_status(p_company_id uuid)
RETURNS TABLE(plan text, status text, started_at timestamp with time zone, expires_at timestamp with time zone, monthly_fee numeric, next_payment_date date, days_remaining integer, is_blocked boolean)
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
SELECT
cl.plan,
CASE
WHEN cl.status = 'canceled' THEN 'canceled'
WHEN cl.status = 'blocked' THEN 'blocked'
WHEN cl.expires_at < now() THEN 'expired'
WHEN cl.plan = 'paid' AND cl.next_payment_date IS NOT NULL AND cl.next_payment_date < CURRENT_DATE THEN 'expired'
ELSE 'active'
END,
cl.started_at, cl.expires_at, cl.monthly_fee, cl.next_payment_date,
GREATEST(EXTRACT(day FROM cl.expires_at - now())::int, 0),
CASE
WHEN cl.status = 'canceled' THEN true
WHEN cl.status = 'blocked' THEN true
WHEN cl.expires_at < now() THEN true
WHEN cl.plan = 'paid' AND cl.next_payment_date IS NOT NULL AND cl.next_payment_date < CURRENT_DATE THEN true
ELSE false
END
FROM company_licenses cl
WHERE cl.company_id = p_company_id
AND (private.is_company_member(p_company_id, auth.uid()) OR private.is_admin());
$$;

-- 4. Add membership check to get_production_metrics
CREATE OR REPLACE FUNCTION public.get_production_metrics(p_company_id uuid, p_period text DEFAULT 'day', p_start_date date DEFAULT NULL, p_end_date date DEFAULT NULL)
RETURNS TABLE(machine_id uuid, machine_name text, total_units numeric, total_hours numeric, avg_per_hour numeric, period_label text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
DECLARE
v_start date := COALESCE(p_start_date, CURRENT_DATE);
v_end date := COALESCE(p_end_date, CURRENT_DATE);
BEGIN
IF NOT (private.is_company_member(p_company_id, auth.uid()) OR private.is_admin()) THEN
  RETURN;
END IF;
IF p_period = 'hour' OR p_period = 'day' THEN
  v_start := CURRENT_DATE; v_end := CURRENT_DATE;
ELSIF p_period = 'week' THEN
  v_start := CURRENT_DATE - 6; v_end := CURRENT_DATE;
ELSIF p_period = 'month' THEN
  v_start := date_trunc('month', CURRENT_DATE)::date; v_end := CURRENT_DATE;
ELSIF p_period = 'year' THEN
  v_start := date_trunc('year', CURRENT_DATE)::date; v_end := CURRENT_DATE;
END IF;
RETURN QUERY
SELECT m.id, m.name,
COALESCE(SUM(CASE WHEN pl.log_date BETWEEN v_start AND v_end THEN pl.units_produced ELSE 0 END), 0),
COALESCE(SUM(CASE WHEN pl.log_date BETWEEN v_start AND v_end THEN pl.uptime_hours ELSE 0 END), 0),
CASE WHEN COALESCE(SUM(CASE WHEN pl.log_date BETWEEN v_start AND v_end THEN pl.uptime_hours ELSE 0 END), 0) > 0
THEN COALESCE(SUM(CASE WHEN pl.log_date BETWEEN v_start AND v_end THEN pl.units_produced ELSE 0 END), 0) /
SUM(CASE WHEN pl.log_date BETWEEN v_start AND v_end THEN pl.uptime_hours ELSE 0 END)
ELSE 0 END,
p_period
FROM machines m
LEFT JOIN production_logs pl ON pl.machine_id = m.id
WHERE m.company_id = p_company_id
GROUP BY m.id, m.name
ORDER BY total_units DESC;
END;
$$;

-- 5. Update log_audit_entry to use private schema
CREATE OR REPLACE FUNCTION public.log_audit_entry(p_company_id uuid, p_action text, p_entity_type text DEFAULT NULL, p_entity_id uuid DEFAULT NULL, p_description text DEFAULT NULL, p_metadata jsonb DEFAULT '{}'::jsonb)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
DECLARE
v_user_id uuid := auth.uid();
v_user_email text;
v_result uuid;
BEGIN
IF v_user_id IS NULL THEN
  RETURN NULL;
END IF;
IF NOT (private.is_company_member(p_company_id, v_user_id) OR private.is_admin()) THEN
  RETURN NULL;
END IF;
SELECT email INTO v_user_email FROM auth.users WHERE id = v_user_id;
INSERT INTO audit_logs (company_id, user_id, user_email, action, entity_type, entity_id, description, metadata)
VALUES (p_company_id, v_user_id, v_user_email, p_action, p_entity_type, p_entity_id, p_description, p_metadata)
RETURNING id INTO v_result;
RETURN v_result;
END;
$$;

-- 6. Update all RLS policies to use private.* instead of public.*
-- app_settings
DROP POLICY IF EXISTS delete_app_settings_admin ON app_settings;
DROP POLICY IF EXISTS insert_app_settings_admin ON app_settings;
DROP POLICY IF EXISTS read_app_settings_admin ON app_settings;
DROP POLICY IF EXISTS update_app_settings_admin ON app_settings;
CREATE POLICY delete_app_settings_admin ON app_settings FOR DELETE TO authenticated USING (private.is_admin());
CREATE POLICY insert_app_settings_admin ON app_settings FOR INSERT TO authenticated WITH CHECK (private.is_admin());
CREATE POLICY read_app_settings_admin ON app_settings FOR SELECT TO authenticated USING (private.is_admin());
CREATE POLICY update_app_settings_admin ON app_settings FOR UPDATE TO authenticated USING (private.is_admin()) WITH CHECK (private.is_admin());

-- audit_logs
DROP POLICY IF EXISTS delete_audit_logs_admin ON audit_logs;
CREATE POLICY delete_audit_logs_admin ON audit_logs FOR DELETE TO authenticated USING (private.is_admin());

-- companies
DROP POLICY IF EXISTS select_member_companies ON companies;
DROP POLICY IF EXISTS update_own_companies ON companies;
CREATE POLICY select_member_companies ON companies FOR SELECT TO authenticated USING ((auth.uid() = owner_id) OR private.is_company_member(id, auth.uid()) OR private.is_admin());
CREATE POLICY update_own_companies ON companies FOR UPDATE TO authenticated USING ((auth.uid() = owner_id) OR private.is_company_ceo(id, auth.uid()) OR private.is_admin()) WITH CHECK ((auth.uid() = owner_id) OR private.is_company_ceo(id, auth.uid()) OR private.is_admin());

-- company_licenses
DROP POLICY IF EXISTS delete_license_admin ON company_licenses;
DROP POLICY IF EXISTS insert_license_admin ON company_licenses;
DROP POLICY IF EXISTS select_own_license ON company_licenses;
DROP POLICY IF EXISTS update_license_admin ON company_licenses;
CREATE POLICY delete_license_admin ON company_licenses FOR DELETE TO authenticated USING (private.is_admin());
CREATE POLICY insert_license_admin ON company_licenses FOR INSERT TO authenticated WITH CHECK (private.is_admin());
CREATE POLICY select_own_license ON company_licenses FOR SELECT TO authenticated USING ((company_id IN (SELECT company_members.company_id FROM company_members WHERE (company_members.user_id = auth.uid()) AND (company_members.role = 'ceo'))) OR private.is_admin());
CREATE POLICY update_license_admin ON company_licenses FOR UPDATE TO authenticated USING (private.is_admin()) WITH CHECK (private.is_admin());

-- company_members
DROP POLICY IF EXISTS delete_members ON company_members;
DROP POLICY IF EXISTS insert_members ON company_members;
DROP POLICY IF EXISTS select_members ON company_members;
DROP POLICY IF EXISTS update_members ON company_members;
CREATE POLICY delete_members ON company_members FOR DELETE TO authenticated USING (private.is_company_owner(company_id, auth.uid()) OR private.is_company_ceo(company_id, auth.uid()) OR private.is_admin());
CREATE POLICY insert_members ON company_members FOR INSERT TO authenticated WITH CHECK (private.is_company_owner(company_id, auth.uid()) OR private.is_company_ceo(company_id, auth.uid()) OR private.is_admin());
CREATE POLICY select_members ON company_members FOR SELECT TO authenticated USING ((auth.uid() = user_id) OR private.is_admin());
CREATE POLICY update_members ON company_members FOR UPDATE TO authenticated USING (private.is_company_owner(company_id, auth.uid()) OR private.is_company_ceo(company_id, auth.uid()) OR private.is_admin()) WITH CHECK (private.is_company_owner(company_id, auth.uid()) OR private.is_company_ceo(company_id, auth.uid()) OR private.is_admin());

-- contracts
DROP POLICY IF EXISTS admin_delete_contracts ON contracts;
DROP POLICY IF EXISTS admin_insert_contracts ON contracts;
DROP POLICY IF EXISTS admin_select_contracts ON contracts;
DROP POLICY IF EXISTS admin_update_contracts ON contracts;
CREATE POLICY admin_delete_contracts ON contracts FOR DELETE TO authenticated USING (private.is_clevia_admin());
CREATE POLICY admin_insert_contracts ON contracts FOR INSERT TO authenticated WITH CHECK (private.is_clevia_admin());
CREATE POLICY admin_select_contracts ON contracts FOR SELECT TO authenticated USING (private.is_clevia_admin());
CREATE POLICY admin_update_contracts ON contracts FOR UPDATE TO authenticated USING (private.is_clevia_admin()) WITH CHECK (private.is_clevia_admin());

-- inventory_items
DROP POLICY IF EXISTS insert_inventory ON inventory_items;
CREATE POLICY insert_inventory ON inventory_items FOR INSERT TO authenticated WITH CHECK (private.is_license_active(company_id) AND (company_id IN (SELECT company_members.company_id FROM company_members WHERE (company_members.user_id = auth.uid()) AND (company_members.role = ANY (ARRAY['ceo', 'solicitante'])))));

-- machines
DROP POLICY IF EXISTS insert_machines ON machines;
CREATE POLICY insert_machines ON machines FOR INSERT TO authenticated WITH CHECK (private.is_license_active(company_id) AND (company_id IN (SELECT company_members.company_id FROM company_members WHERE (company_members.user_id = auth.uid()) AND (company_members.role = ANY (ARRAY['ceo', 'solicitante'])))));

-- monitor_screens
DROP POLICY IF EXISTS delete_monitor_screens_authorized ON monitor_screens;
DROP POLICY IF EXISTS insert_monitor_screens_authorized ON monitor_screens;
DROP POLICY IF EXISTS update_monitor_screens_authorized ON monitor_screens;
CREATE POLICY delete_monitor_screens_authorized ON monitor_screens FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM company_members cm WHERE (cm.company_id = monitor_screens.company_id) AND (cm.user_id = auth.uid()) AND ((cm.role = ANY (ARRAY['ceo', 'gerente', 'admin'])) OR private.has_manage_screens_grant(cm.company_id, auth.uid()))));
CREATE POLICY insert_monitor_screens_authorized ON monitor_screens FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM company_members cm WHERE (cm.company_id = monitor_screens.company_id) AND (cm.user_id = auth.uid()) AND ((cm.role = 'ceo') OR private.has_manage_screens_grant(cm.company_id, auth.uid()))));
CREATE POLICY update_monitor_screens_authorized ON monitor_screens FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM company_members cm WHERE (cm.company_id = monitor_screens.company_id) AND (cm.user_id = auth.uid()) AND ((cm.role = 'ceo') OR private.has_manage_screens_grant(cm.company_id, auth.uid())))) WITH CHECK (EXISTS (SELECT 1 FROM company_members cm WHERE (cm.company_id = monitor_screens.company_id) AND (cm.user_id = auth.uid()) AND ((cm.role = 'ceo') OR private.has_manage_screens_grant(cm.company_id, auth.uid()))));

-- preventive_plans
DROP POLICY IF EXISTS insert_preventives ON preventive_plans;
CREATE POLICY insert_preventives ON preventive_plans FOR INSERT TO authenticated WITH CHECK (private.is_license_active(company_id) AND (company_id IN (SELECT company_members.company_id FROM company_members WHERE (company_members.user_id = auth.uid()) AND (company_members.role = ANY (ARRAY['ceo', 'solicitante'])))));

-- production_logs
DROP POLICY IF EXISTS insert_production ON production_logs;
CREATE POLICY insert_production ON production_logs FOR INSERT TO authenticated WITH CHECK (private.is_license_active(company_id) AND (company_id IN (SELECT company_members.company_id FROM company_members WHERE (company_members.user_id = auth.uid()) AND (company_members.role = ANY (ARRAY['supervisora', 'ceo'])))));

-- work_orders
DROP POLICY IF EXISTS insert_wo ON work_orders;
CREATE POLICY insert_wo ON work_orders FOR INSERT TO authenticated WITH CHECK (private.is_license_active(company_id) AND (company_id IN (SELECT company_members.company_id FROM company_members WHERE (company_members.user_id = auth.uid()) AND (company_members.role = ANY (ARRAY['ceo', 'gerente'])))));

-- 7. Drop old public.* helper functions
DROP FUNCTION IF EXISTS public.is_admin();
DROP FUNCTION IF EXISTS public.is_clevia_admin();
DROP FUNCTION IF EXISTS public.is_company_ceo(uuid, uuid);
DROP FUNCTION IF EXISTS public.is_company_member(uuid, uuid);
DROP FUNCTION IF EXISTS public.is_company_owner(uuid, uuid);
DROP FUNCTION IF EXISTS public.is_license_active(uuid);
DROP FUNCTION IF EXISTS public.has_manage_screens_grant(uuid, uuid);

-- 8. Revoke EXECUTE on remaining public SECURITY DEFINER functions from anon
REVOKE EXECUTE ON FUNCTION public.get_company_license_status(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_production_metrics(uuid, text, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.log_audit_entry(uuid, text, text, uuid, text, jsonb) FROM anon;
