/*
  # Fechar o acesso anônimo à consulta de licença (parte 2)

  O REVOKE anterior não teve efeito porque o EXECUTE também estava concedido
  ao papel PUBLIC, que inclui `anon`. Removemos o PUBLIC e devolvemos o
  EXECUTE apenas para usuários logados e para a service role.
*/

REVOKE EXECUTE ON FUNCTION public.get_company_license_status(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_company_license_status(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.get_company_license_status(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_company_license_status(uuid) TO service_role;
