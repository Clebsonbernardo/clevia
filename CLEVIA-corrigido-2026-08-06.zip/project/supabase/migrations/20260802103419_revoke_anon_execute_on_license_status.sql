/*
  # Não permitir consulta de licença sem estar logado

  1. Problema
     - `get_company_license_status` é SECURITY DEFINER e tinha EXECUTE
       concedido a `anon`, ficando exposta em /rest/v1/rpc sem login.

  2. Correção
     - Remove o EXECUTE de `anon`. Usuários logados continuam podendo
       consultar a licença das empresas de que fazem parte.
*/

REVOKE EXECUTE ON FUNCTION public.get_company_license_status(uuid) FROM anon;
