/* CLEVIA — ciclo completo das Ordens de Produção (OP)
   Uma OP permanece ativa/pausada até ser encerrada e arquivada.
   Todo apontamento por hora fica vinculado à OP correspondente.
*/

CREATE TABLE IF NOT EXISTS public.production_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  sector text NOT NULL,
  order_number text NOT NULL,
  input_quantity numeric NOT NULL CHECK (input_quantity > 0),
  output_quantity numeric NOT NULL DEFAULT 0 CHECK (output_quantity >= 0),
  target_per_hour numeric NOT NULL DEFAULT 0 CHECK (target_per_hour >= 0),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused', 'archived')),
  started_at timestamptz NOT NULL DEFAULT now(),
  paused_at timestamptz,
  completed_at timestamptz,
  archived_at timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid(),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, sector, order_number)
);

ALTER TABLE public.production_orders ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX IF NOT EXISTS idx_one_open_production_order_per_sector
  ON public.production_orders (company_id, sector)
  WHERE status IN ('active', 'paused');
CREATE INDEX IF NOT EXISTS idx_production_orders_history
  ON public.production_orders (company_id, sector, started_at DESC);

ALTER TABLE public.production_logs
  ADD COLUMN IF NOT EXISTS production_order_id uuid REFERENCES public.production_orders(id) ON DELETE RESTRICT;
CREATE INDEX IF NOT EXISTS idx_production_logs_order_hour
  ON public.production_logs (production_order_id, log_date, production_hour);

DROP POLICY IF EXISTS "read_production_orders" ON public.production_orders;
CREATE POLICY "read_production_orders" ON public.production_orders FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.company_members cm
  WHERE cm.company_id = production_orders.company_id AND cm.user_id = auth.uid()
) OR private.is_admin());

DROP POLICY IF EXISTS "manage_production_orders" ON public.production_orders;
CREATE POLICY "manage_production_orders" ON public.production_orders FOR ALL TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.company_members cm
  WHERE cm.company_id = production_orders.company_id AND cm.user_id = auth.uid()
    AND cm.role IN ('ceo', 'gerente', 'supervisora', 'lider', 'encarregado')
) OR private.is_admin())
WITH CHECK (EXISTS (
  SELECT 1 FROM public.company_members cm
  WHERE cm.company_id = production_orders.company_id AND cm.user_id = auth.uid()
    AND cm.role IN ('ceo', 'gerente', 'supervisora', 'lider', 'encarregado')
) OR private.is_admin());

CREATE OR REPLACE FUNCTION public.set_production_order_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public, pg_temp AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_production_order_updated_at ON public.production_orders;
CREATE TRIGGER trg_production_order_updated_at
BEFORE UPDATE ON public.production_orders
FOR EACH ROW EXECUTE FUNCTION public.set_production_order_updated_at();

ALTER TABLE public.production_orders REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.production_orders;
