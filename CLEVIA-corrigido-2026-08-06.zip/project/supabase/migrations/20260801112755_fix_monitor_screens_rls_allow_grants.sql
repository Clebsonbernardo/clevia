-- Fix: allow users with manage_screens grant to insert/update/delete monitor_screens
-- Previously only CEO could do these operations, but the frontend allows
-- granted users to edit screens too.

-- Helper function to check if user has manage_screens grant
CREATE OR REPLACE FUNCTION has_manage_screens_grant(p_company_id uuid, p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM ceo_grants
    WHERE company_id = p_company_id
      AND user_id = p_user_id
      AND permission_key = 'manage_screens'
      AND granted = true
  );
$$;

-- Replace INSERT policy
DROP POLICY IF EXISTS insert_monitor_screens_ceo ON monitor_screens;
CREATE POLICY insert_monitor_screens_authorized
  ON monitor_screens FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = monitor_screens.company_id
        AND cm.user_id = auth.uid()
        AND (cm.role = 'ceo' OR has_manage_screens_grant(cm.company_id, auth.uid()))
    )
  );

-- Replace UPDATE policy
DROP POLICY IF EXISTS update_monitor_screens_ceo ON monitor_screens;
CREATE POLICY update_monitor_screens_authorized
  ON monitor_screens FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = monitor_screens.company_id
        AND cm.user_id = auth.uid()
        AND (cm.role = 'ceo' OR has_manage_screens_grant(cm.company_id, auth.uid()))
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = monitor_screens.company_id
        AND cm.user_id = auth.uid()
        AND (cm.role = 'ceo' OR has_manage_screens_grant(cm.company_id, auth.uid()))
    )
  );

-- Replace DELETE policy
DROP POLICY IF EXISTS delete_monitor_screens_ceo ON monitor_screens;
CREATE POLICY delete_monitor_screens_authorized
  ON monitor_screens FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = monitor_screens.company_id
        AND cm.user_id = auth.uid()
        AND (cm.role = 'ceo' OR has_manage_screens_grant(cm.company_id, auth.uid()))
    )
  );
