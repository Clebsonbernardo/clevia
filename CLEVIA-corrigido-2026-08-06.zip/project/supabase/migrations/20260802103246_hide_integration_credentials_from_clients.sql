/*
  # Esconder credenciais de integração do cliente

  1. Problema
     - `integrations.credentials_encrypted` guarda usuário/senha e chaves de API
       de sistemas externos (SAP, ERP, Active Directory) em texto legível.
     - A policy de SELECT liberava a linha inteira para QUALQUER membro da
       empresa, então um mecânico podia ler as credenciais do empregador.

  2. Correção
     - Troca o SELECT de tabela inteira por SELECT coluna a coluna, deixando
       `credentials_encrypted` de fora para `anon` e `authenticated`.
     - INSERT/UPDATE/DELETE continuam como estavam, então a tela de
       integrações segue salvando as credenciais normalmente.
     - As edge functions usam a service role e não são afetadas.
*/

REVOKE SELECT ON public.integrations FROM anon;
REVOKE SELECT ON public.integrations FROM authenticated;

GRANT SELECT (
  id, company_id, type, name, endpoint_url, config,
  active, last_sync_at, sync_status, last_error, created_at, updated_at
) ON public.integrations TO authenticated;
