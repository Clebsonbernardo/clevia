/*
# Add plan_type column to company_licenses (Basic vs Premium)

## Visão Geral
Adiciona a coluna `plan_type` na tabela `company_licenses` para diferenciar
entre plano Básico e Premium. Clientes com plano 'basic' veem apenas as telas
essenciais; clientes com plano 'premium' veem todas as telas avançadas.

## Mudanças
1. Nova coluna `plan_type` (text, default 'basic', CHECK IN ('basic', 'premium'))
2. Função `get_company_license_status` recriada para retornar `plan_type`

## Segurança
- RLS já ativo em `company_licenses`.
- `plan_type` só pode ser alterado pelo service role (admin do sistema).
*/

ALTER TABLE company_licenses
  ADD COLUMN IF NOT EXISTS plan_type text NOT NULL DEFAULT 'basic'
  CHECK (plan_type IN ('basic', 'premium'));

DROP FUNCTION IF EXISTS public.get_company_license_status(uuid);

CREATE FUNCTION public.get_company_license_status(p_company_id uuid)
RETURNS TABLE(
  plan text,
  status text,
  started_at timestamp with time zone,
  expires_at timestamp with time zone,
  monthly_fee numeric,
  next_payment_date date,
  days_remaining integer,
  is_blocked boolean,
  plan_type text
)
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $function$
SELECT
  cl.plan,
  CASE
    WHEN cl.status = 'canceled' THEN 'canceled'
    WHEN cl.status = 'blocked' THEN 'blocked'
    WHEN cl.expires_at < now() THEN 'expired'
    WHEN cl.plan = 'paid' AND cl.next_payment_date IS NOT NULL AND cl.next_payment_date < CURRENT_DATE THEN 'expired'
    ELSE 'active'
  END,
  cl.started_at,
  cl.expires_at,
  cl.monthly_fee,
  cl.next_payment_date,
  GREATEST(EXTRACT(day FROM cl.expires_at - now())::int, 0),
  CASE
    WHEN cl.status = 'canceled' THEN true
    WHEN cl.status = 'blocked' THEN true
    WHEN cl.expires_at < now() THEN true
    WHEN cl.plan = 'paid' AND cl.next_payment_date IS NOT NULL AND cl.next_payment_date < CURRENT_DATE THEN true
    ELSE false
  END,
  cl.plan_type
FROM company_licenses cl
WHERE cl.company_id = p_company_id
  AND (private.is_company_member(p_company_id, auth.uid()) OR private.is_admin());
$function$;

REVOKE EXECUTE ON FUNCTION public.get_company_license_status(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.get_company_license_status(uuid) TO authenticated;
