-- Fix: when all active OSes are cleared, reset machine to 'producao' regardless of
-- its current status (previously only reset if status was 'parada' or 'manutencao',
-- leaving machines stuck in other states like 'fora_turno' after OS completion).
CREATE OR REPLACE FUNCTION public.sync_machine_status_on_os_change()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
m_id uuid;
has_critical boolean;
has_active boolean;
BEGIN
m_id := COALESCE(NEW.machine_id, OLD.machine_id);
IF m_id IS NULL THEN
RETURN COALESCE(NEW, OLD);
END IF;

-- Fire on DELETE, or on INSERT/UPDATE when status OR priority OR machine_id changes
IF TG_OP = 'DELETE' OR (
TG_OP IN ('INSERT','UPDATE') AND (
NEW.status IS DISTINCT FROM OLD.status
OR NEW.priority IS DISTINCT FROM OLD.priority
OR NEW.machine_id IS DISTINCT FROM OLD.machine_id
)
) THEN

SELECT
EXISTS(
SELECT 1 FROM work_orders
WHERE machine_id = m_id
AND status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
AND priority IN ('critica', 'alta')
),
EXISTS(
SELECT 1 FROM work_orders
WHERE machine_id = m_id
AND status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
)
INTO has_critical, has_active;

IF has_critical THEN
UPDATE machines SET status = 'parada' WHERE id = m_id;
ELSIF has_active THEN
UPDATE machines SET status = 'manutencao' WHERE id = m_id AND status <> 'manutencao';
ELSE
-- No active OSes: machine returns to production regardless of current status
UPDATE machines SET status = 'producao' WHERE id = m_id;
END IF;

END IF;

RETURN COALESCE(NEW, OLD);
END;
$function$;
