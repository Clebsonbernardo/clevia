-- Fix: the trigger excluded the NEW work order from its own status check.
-- On INSERT of a critical/high priority OS, the new order was filtered out
-- (id <> NEW.id), so the machine was never set to 'parada'.
--
-- Fix logic:
-- - On INSERT: include the new order in the check (no exclusion).
-- - On UPDATE: include the updated order (use NEW.status/priority).
-- - On DELETE: exclude the deleted order (it no longer exists in the table
--   anyway, so no explicit exclusion needed).

CREATE OR REPLACE FUNCTION sync_machine_status_on_os_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  m_id uuid;
  has_critical boolean;
  has_active boolean;
BEGIN
  m_id := COALESCE(NEW.machine_id, OLD.machine_id);
  IF m_id IS NULL THEN
    RETURN COALESCE(NEW, OLD);
  END IF;

  -- Only act on status transitions (INSERT/UPDATE) or deletion (DELETE)
  IF TG_OP = 'DELETE' OR (TG_OP IN ('INSERT','UPDATE') AND NEW.status IS DISTINCT FROM OLD.status) THEN

    SELECT
      EXISTS(
        SELECT 1 FROM work_orders
        WHERE machine_id = m_id
          AND status IN ('aberta', 'em_andamento', 'pausada')
          AND priority IN ('critica', 'alta')
      ),
      EXISTS(
        SELECT 1 FROM work_orders
        WHERE machine_id = m_id
          AND status IN ('aberta', 'em_andamento', 'pausada')
      )
    INTO has_critical, has_active;

    IF has_critical THEN
      UPDATE machines SET status = 'parada' WHERE id = m_id;
    ELSIF has_active THEN
      UPDATE machines SET status = 'manutencao' WHERE id = m_id AND status <> 'manutencao';
    ELSE
      UPDATE machines SET status = 'producao' WHERE id = m_id AND status IN ('parada', 'manutencao');
    END IF;

  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Backfill: ensure machines with active critical/high OS are set to 'parada'
UPDATE machines SET status = 'parada'
WHERE id IN (
  SELECT DISTINCT machine_id FROM work_orders
  WHERE status IN ('aberta', 'em_andamento', 'pausada')
    AND priority IN ('critica', 'alta')
    AND machine_id IS NOT NULL
)
AND status <> 'parada';

-- Ensure machines with active (non-critical) OS are 'manutencao'
UPDATE machines SET status = 'manutencao'
WHERE id IN (
  SELECT DISTINCT machine_id FROM work_orders
  WHERE status IN ('aberta', 'em_andamento', 'pausada')
    AND priority NOT IN ('critica', 'alta')
    AND machine_id IS NOT NULL
)
AND id NOT IN (
  SELECT DISTINCT machine_id FROM work_orders
  WHERE status IN ('aberta', 'em_andamento', 'pausada')
    AND priority IN ('critica', 'alta')
    AND machine_id IS NOT NULL
)
AND status <> 'manutencao';
