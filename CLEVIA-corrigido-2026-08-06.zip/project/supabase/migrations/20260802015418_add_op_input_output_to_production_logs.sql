/*
# Add OP input/output columns to production_logs

1. Changes
- Adds `op_input` numeric column (Entrada de OP — quantity of pieces entering the production order).
- Adds `op_output` numeric column (Saída de OP — quantity of pieces completed/leaving the order).
- The difference (op_input - op_output) represents pieces left behind ("ficou para trás").
2. Security
- No RLS changes needed; existing policies cover the new columns.
3. Notes
- Both columns are nullable and default to 0 so existing rows are unaffected.
- The frontend will populate these when the encarregada registers production,
  allowing the chart to show Entrada vs Saída and the backlog.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'production_logs' AND column_name = 'op_input'
  ) THEN
    ALTER TABLE production_logs ADD COLUMN op_input numeric NOT NULL DEFAULT 0;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'production_logs' AND column_name = 'op_output'
  ) THEN
    ALTER TABLE production_logs ADD COLUMN op_output numeric NOT NULL DEFAULT 0;
  END IF;
END $$;
