/*
  # Não expor a lista de administradores do sistema

  1. Problema
     - A policy `authenticated_read_admins` usava `USING (true)`, então
       qualquer pessoa logada podia listar os e-mails dos administradores da
       plataforma — exatamente as contas mais valiosas para um ataque.

  2. Correção
     - A leitura passa a devolver apenas a própria linha do usuário.
     - O aplicativo só consulta esta tabela filtrando pelo próprio e-mail
       (AuthContext), então a verificação de "sou admin?" continua igual.
     - As policies de escrita e o helper `private.is_admin()` não mudam.
*/

DROP POLICY IF EXISTS "authenticated_read_admins" ON public.system_admins;

CREATE POLICY "authenticated_read_admins" ON public.system_admins
  FOR SELECT TO authenticated
  USING (email = (auth.jwt() ->> 'email'));
