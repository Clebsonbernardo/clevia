-- Include 'aguardando_pecas' as an active status in the machine sync trigger,
-- matching what the SectorBoardScreen considers active.

CREATE OR REPLACE FUNCTION sync_machine_status_on_os_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  m_id uuid;
  has_critical boolean;
  has_active boolean;
BEGIN
  m_id := COALESCE(NEW.machine_id, OLD.machine_id);
  IF m_id IS NULL THEN
    RETURN COALESCE(NEW, OLD);
  END IF;

  -- Fire on DELETE, or on INSERT/UPDATE when status OR priority OR machine_id changes
  IF TG_OP = 'DELETE' OR (
    TG_OP IN ('INSERT','UPDATE') AND (
      NEW.status IS DISTINCT FROM OLD.status
      OR NEW.priority IS DISTINCT FROM OLD.priority
      OR NEW.machine_id IS DISTINCT FROM OLD.machine_id
    )
  ) THEN

    SELECT
      EXISTS(
        SELECT 1 FROM work_orders
        WHERE machine_id = m_id
          AND status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
          AND priority IN ('critica', 'alta')
      ),
      EXISTS(
        SELECT 1 FROM work_orders
        WHERE machine_id = m_id
          AND status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
      )
    INTO has_critical, has_active;

    IF has_critical THEN
      UPDATE machines SET status = 'parada' WHERE id = m_id;
    ELSIF has_active THEN
      UPDATE machines SET status = 'manutencao' WHERE id = m_id AND status <> 'manutencao';
    ELSE
      UPDATE machines SET status = 'producao' WHERE id = m_id AND status IN ('parada', 'manutencao');
    END IF;

  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Backfill with aguardando_pecas included
UPDATE machines SET status = 'parada'
WHERE id IN (
  SELECT DISTINCT machine_id FROM work_orders
  WHERE status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
    AND priority IN ('critica', 'alta')
    AND machine_id IS NOT NULL
)
AND status <> 'parada';

UPDATE machines SET status = 'manutencao'
WHERE id IN (
  SELECT DISTINCT machine_id FROM work_orders
  WHERE status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
    AND priority NOT IN ('critica', 'alta')
    AND machine_id IS NOT NULL
)
AND id NOT IN (
  SELECT DISTINCT machine_id FROM work_orders
  WHERE status IN ('aberta', 'em_andamento', 'pausada', 'aguardando_pecas')
    AND priority IN ('critica', 'alta')
    AND machine_id IS NOT NULL
)
AND status <> 'manutencao';
