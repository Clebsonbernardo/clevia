/*
  # Impedir registros de auditoria falsificados

  1. Problema
     - A policy de INSERT em `audit_logs` só exigia que a linha pertencesse a
       uma empresa da qual o usuário é membro. Nada amarrava `user_id` à
       sessão, então qualquer membro podia gravar entradas no histórico
       assinadas por outra pessoa (por exemplo, o CEO).

  2. Correção
     - O INSERT agora exige `user_id = auth.uid()`.
     - O aplicativo grava auditoria pela função `log_audit_entry`, que já
       preenche o usuário a partir da sessão, então nada deixa de funcionar.
*/

DROP POLICY IF EXISTS "insert_audit_logs" ON public.audit_logs;

CREATE POLICY "insert_audit_logs" ON public.audit_logs
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND company_id IN (
      SELECT company_members.company_id
      FROM company_members
      WHERE company_members.user_id = auth.uid()
    )
  );
