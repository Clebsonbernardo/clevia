/*
# Create company_feature_grants table

## What this does
Creates a new table `company_feature_grants` that allows the system admin (software owner)
to grant access to admin-only features (Contracts, Licenses, Settings, Integrations)
to specific client companies on demand. These features are NOT part of any plan
(basic or premium) — they are only accessible if the system admin explicitly
grants them per company.

## New Table: company_feature_grants
- id (uuid, primary key)
- company_id (uuid, FK to companies) — the client company receiving the grant
- feature_key (text) — e.g. 'contracts', 'licenses', 'settings', 'integrations'
- granted (boolean, default true) — whether the grant is active
- granted_by (uuid, FK to auth.users) — the system admin who granted it
- created_at (timestamptz)

## Security
- RLS enabled
- Any company member can SELECT grants for their company (so the frontend can check access)
- Only system admins can INSERT/UPDATE/DELETE grants (checked via system_admins table)
- Realtime enabled for live updates
*/

CREATE TABLE IF NOT EXISTS company_feature_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  feature_key text NOT NULL,
  granted boolean NOT NULL DEFAULT true,
  granted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(company_id, feature_key)
);

ALTER TABLE company_feature_grants ENABLE ROW LEVEL SECURITY;

-- SELECT: any company member can see grants for their company
DROP POLICY IF EXISTS "select_company_feature_grants" ON company_feature_grants;
CREATE POLICY "select_company_feature_grants" ON company_feature_grants FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM company_members cm
      WHERE cm.company_id = company_feature_grants.company_id
        AND cm.user_id = auth.uid()
    )
  );

-- INSERT: only system admins
DROP POLICY IF EXISTS "insert_company_feature_grants_admin" ON company_feature_grants;
CREATE POLICY "insert_company_feature_grants_admin" ON company_feature_grants FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM system_admins sa
      WHERE sa.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- UPDATE: only system admins
DROP POLICY IF EXISTS "update_company_feature_grants_admin" ON company_feature_grants;
CREATE POLICY "update_company_feature_grants_admin" ON company_feature_grants FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM system_admins sa
      WHERE sa.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM system_admins sa
      WHERE sa.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- DELETE: only system admins
DROP POLICY IF EXISTS "delete_company_feature_grants_admin" ON company_feature_grants;
CREATE POLICY "delete_company_feature_grants_admin" ON company_feature_grants FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM system_admins sa
      WHERE sa.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

CREATE INDEX IF NOT EXISTS idx_company_feature_grants_company ON company_feature_grants(company_id);
CREATE INDEX IF NOT EXISTS idx_company_feature_grants_feature ON company_feature_grants(feature_key);

-- Add to realtime
ALTER PUBLICATION supabase_realtime ADD TABLE company_feature_grants;