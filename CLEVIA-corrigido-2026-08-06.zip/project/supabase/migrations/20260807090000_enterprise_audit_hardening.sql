/* CLEVIA — endurecimento da auditoria empresarial
   - logs imutáveis
   - leitura somente pela direção/gestão e administradores do sistema
   - índices para filtros empresariais
   - retenção controlada por função administrativa explícita
*/

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_audit_logs_company" ON public.audit_logs;
DROP POLICY IF EXISTS "select_audit_logs" ON public.audit_logs;
CREATE POLICY "select_audit_logs_management"
ON public.audit_logs FOR SELECT TO authenticated
USING (
  private.is_admin()
  OR EXISTS (
    SELECT 1 FROM public.company_members cm
    WHERE cm.company_id = audit_logs.company_id
      AND cm.user_id = auth.uid()
      AND cm.role IN ('ceo', 'gerente')
  )
);

DROP POLICY IF EXISTS "delete_audit_logs_admin" ON public.audit_logs;
REVOKE UPDATE, DELETE, TRUNCATE ON public.audit_logs FROM authenticated;

CREATE INDEX IF NOT EXISTS idx_audit_logs_company_action_created
  ON public.audit_logs (company_id, action, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_company_entity_created
  ON public.audit_logs (company_id, entity_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_company_user_created
  ON public.audit_logs (company_id, user_id, created_at DESC);

COMMENT ON TABLE public.audit_logs IS
  'Trilha de auditoria imutável do CLEVIA. Registros não podem ser editados ou excluídos pela aplicação.';
