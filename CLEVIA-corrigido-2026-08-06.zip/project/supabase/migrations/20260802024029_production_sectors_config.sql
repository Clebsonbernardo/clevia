/*
# Create production_sectors table — control which sectors use the production chart

1. New Tables
- `production_sectors`
  - `id` (uuid, primary key)
  - `company_id` (uuid, references companies, cascade delete)
  - `sector_name` (text, not null) — the sector that uses the production chart
  - `created_at` (timestamptz, default now())
  - Unique constraint on (company_id, sector_name) so each sector appears once

2. Security
- Enable RLS on `production_sectors`.
- Owner-scoped CRUD via company membership check (same pattern as other tables).
- Only authenticated users who are members of the company can read/write.
*/

CREATE TABLE IF NOT EXISTS production_sectors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  sector_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (company_id, sector_name)
);

ALTER TABLE production_sectors ENABLE ROW LEVEL SECURITY;

-- Allow company members to read
DROP POLICY IF EXISTS "select_production_sectors" ON production_sectors;
CREATE POLICY "select_production_sectors" ON production_sectors FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM company_members cm
    WHERE cm.company_id = production_sectors.company_id
    AND cm.user_id = auth.uid()
  )
);

-- Allow company members to insert
DROP POLICY IF EXISTS "insert_production_sectors" ON production_sectors;
CREATE POLICY "insert_production_sectors" ON production_sectors FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM company_members cm
    WHERE cm.company_id = production_sectors.company_id
    AND cm.user_id = auth.uid()
  )
);

-- Allow company members to update
DROP POLICY IF EXISTS "update_production_sectors" ON production_sectors;
CREATE POLICY "update_production_sectors" ON production_sectors FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM company_members cm
    WHERE cm.company_id = production_sectors.company_id
    AND cm.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM company_members cm
    WHERE cm.company_id = production_sectors.company_id
    AND cm.user_id = auth.uid()
  )
);

-- Allow company members to delete
DROP POLICY IF EXISTS "delete_production_sectors" ON production_sectors;
CREATE POLICY "delete_production_sectors" ON production_sectors FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM company_members cm
    WHERE cm.company_id = production_sectors.company_id
    AND cm.user_id = auth.uid()
  )
);

-- Add to realtime
ALTER TABLE production_sectors REPLICA IDENTITY FULL;
