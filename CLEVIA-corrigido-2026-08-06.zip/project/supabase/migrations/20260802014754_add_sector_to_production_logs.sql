/*
# Add sector column to production_logs

1. Changes
- Adds `sector` text column to `production_logs` so production can be tracked per sector
  (lavanderia, acabamento, etc.) independently of which machine produced it.
- Adds an index on (company_id, sector, log_date) for fast per-sector queries.
2. Security
- No RLS policy changes needed; existing policies already cover the new column
  (column-level privileges are not restricted on production_logs).
3. Notes
- The column is nullable so existing rows are unaffected.
- The frontend will populate `sector` from the machine's sector when a machine is
  selected, or from a sector picker when registering sector-level production.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'production_logs' AND column_name = 'sector'
  ) THEN
    ALTER TABLE production_logs ADD COLUMN sector text;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_production_sector
  ON production_logs(company_id, sector, log_date);
