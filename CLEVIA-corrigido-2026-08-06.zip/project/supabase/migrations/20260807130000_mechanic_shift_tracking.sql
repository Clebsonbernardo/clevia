/* CLEVIA — localização durante o turno, com histórico e consentimento visível */

ALTER TABLE public.mechanic_locations
  ADD COLUMN IF NOT EXISTS tracking_active boolean NOT NULL DEFAULT false;

DROP POLICY IF EXISTS "read_company_locations" ON public.mechanic_locations;
CREATE POLICY "read_company_locations" ON public.mechanic_locations FOR SELECT TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.company_members cm
    WHERE cm.company_id = mechanic_locations.company_id
      AND cm.user_id = auth.uid()
      AND cm.role IN ('ceo', 'gerente', 'supervisora', 'lider')
  )
  OR private.is_admin()
);

CREATE TABLE IF NOT EXISTS public.mechanic_location_history (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mechanic_id uuid REFERENCES public.mechanics(id) ON DELETE SET NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  accuracy_meters double precision,
  heading double precision,
  speed double precision,
  tracking_active boolean NOT NULL DEFAULT true,
  recorded_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_mechanic_history_company_time
  ON public.mechanic_location_history (company_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_mechanic_history_user_time
  ON public.mechanic_location_history (user_id, recorded_at DESC);

ALTER TABLE public.mechanic_location_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "mechanic_insert_own_history" ON public.mechanic_location_history
FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE POLICY "mechanic_read_own_history" ON public.mechanic_location_history
FOR SELECT TO authenticated USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.company_members cm
    WHERE cm.company_id = mechanic_location_history.company_id
      AND cm.user_id = auth.uid()
      AND cm.role IN ('ceo', 'gerente', 'supervisora', 'lider')
  )
  OR private.is_admin()
);

REVOKE UPDATE, DELETE, TRUNCATE ON public.mechanic_location_history FROM authenticated;

CREATE OR REPLACE FUNCTION public.purge_old_mechanic_location_history()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE removed integer;
BEGIN
  DELETE FROM public.mechanic_location_history WHERE recorded_at < now() - interval '30 days';
  GET DIAGNOSTICS removed = ROW_COUNT;
  RETURN removed;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.purge_old_mechanic_location_history() FROM PUBLIC, anon, authenticated;

ALTER TABLE public.mechanic_location_history REPLICA IDENTITY FULL;
