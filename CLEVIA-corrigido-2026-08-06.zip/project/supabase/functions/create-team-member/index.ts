import { createClient } from "npm:@supabase/supabase-js@2";

function cryptoRandomPassword(length = 20): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnpqrstuvwxyz";
  const digits = "23456789";
  const symbols = "!@#$%&*?";
  const all = upper + lower + digits + symbols;
  const bytes = new Uint8Array(length);
  (crypto as any).getRandomValues(bytes);
  let pwd = Array.from(bytes, (b: number) => all[b % all.length]).join("");
  // Garante pelo menos um de cada tipo
  pwd = pwd.split("");
  pwd[0] = upper[bytes[0] % upper.length];
  pwd[1] = lower[bytes[1] % lower.length];
  pwd[2] = digits[bytes[2] % digits.length];
  pwd[3] = symbols[bytes[3] % symbols.length];
  // Embaralha
  for (let i = pwd.length - 1; i > 0; i--) {
    const j = bytes[i] % (i + 1);
    [pwd[i], pwd[j]] = [pwd[j], pwd[i]];
  }
  return pwd.join("");
}

async function gotrueUpdateUser(userId: string, payload: Record<string, unknown>): Promise<{ ok: boolean; error: string | null }> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  try {
    const res = await fetch(`${supabaseUrl}/auth/v1/admin/users/${userId}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${serviceRoleKey}`,
        apikey: serviceRoleKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error("gotrueUpdateUser failed", res.status, text);
      let friendly = "unknown_error";
      try {
        const parsed = JSON.parse(text);
        if (parsed?.error_code === "weak_password" || parsed?.weak_password) {
          friendly = "weak_password";
        }
      } catch {}
      return { ok: false, error: friendly };
    }
    return { ok: true, error: null };
  } catch (err) {
    console.error("gotrueUpdateUser threw", err);
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Client com service role para criar usuário e inserir membro
    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Verifica o JWT do chamador para garantir que está autenticado
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(JSON.stringify({ error: "Não autorizado." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const caller = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: callerUser, error: callerErr } = await caller.auth.getUser();
    if (callerErr || !callerUser.user) {
      return new Response(JSON.stringify({ error: "Sessão inválida." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { email, password, displayName, role, companyId } = body as {
      email: string;
      password: string;
      displayName: string;
      role: string;
      companyId: string;
    };

    if (!email || !role || !companyId) {
      return new Response(JSON.stringify({ error: "Dados incompletos." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // O papel precisa ser um dos conhecidos: o corpo da requisição não pode inventar papel.
    const ALLOWED_ROLES = ["ceo", "gerente", "solicitante", "mecanico", "supervisora"];
    if (!ALLOWED_ROLES.includes(role)) {
      return new Response(JSON.stringify({ error: "Função inválida." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verifica se o chamador é admin (ceo/gerente) da empresa
    const { data: callerMember } = await admin
      .from("company_members")
      .select("role")
      .eq("user_id", callerUser.user.id)
      .eq("company_id", companyId)
      .maybeSingle();

    if (!callerMember || !["ceo", "gerente"].includes(callerMember.role)) {
      return new Response(
        JSON.stringify({ error: "Você não tem permissão para adicionar usuários." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Somente o CEO pode conceder os papeis administrativos.
    const PRIVILEGED_ROLES = ["ceo", "gerente"];
    if (PRIVILEGED_ROLES.includes(role) && callerMember.role !== "ceo") {
      return new Response(
        JSON.stringify({ error: "Apenas o CEO pode criar usuários com essa função." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Cria o usuário no auth (se ainda não existir)
    let userId: string | null = null;
    let createdNow = false;
    let linkedExisting = false;
    let passwordWarning: string | null = null;

    const { data: newUser, error: createErr } = await admin.auth.admin.createUser({
      email,
      password: password || cryptoRandomPassword(),
      email_confirm: true,
    });

    if (createErr) {
      if (!createErr.message.toLowerCase().includes("already")) {
        console.error("createUser failed", createErr);
        return new Response(JSON.stringify({ error: "Não foi possível criar o usuário." }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // E-mail já existe no auth: localiza o usuário existente via busca direta
      const normalizedEmail = email.trim().toLowerCase();
      let existingId: string | null = null;

      // Usa a API admin do GoTrue com filtro de busca (muito mais rápido que paginar)
      try {
        const searchRes = await fetch(
          `${supabaseUrl}/auth/v1/admin/users?per_page=1000&search=${encodeURIComponent(normalizedEmail)}`,
          {
            headers: {
              Authorization: `Bearer ${serviceRoleKey}`,
              apikey: anonKey,
              "Content-Type": "application/json",
            },
          },
        );
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          const found = (searchData.users ?? []).find(
            (u: { email?: string; id: string }) =>
              (u.email ?? "").toLowerCase() === normalizedEmail,
          );
          if (found) existingId = found.id;
        } else {
          console.error("GoTrue admin search failed", searchRes.status);
        }
      } catch (searchErr) {
        console.error("GoTrue admin search threw", searchErr);
      }

      // Fallback: paginação se a busca direta não encontrou
      if (!existingId) {
        for (let page = 1; page <= 20 && !existingId; page++) {
          const { data: pageData, error: listErr } = await admin.auth.admin.listUsers({
            page,
            perPage: 200,
          });
          if (listErr || !pageData?.users) {
            console.error("listUsers failed", listErr);
            break;
          }
          const found = pageData.users.find(
            (u) => (u.email ?? "").toLowerCase() === normalizedEmail,
          );
          if (found) existingId = found.id;
          if (pageData.users.length < 200) break;
        }
      }

      // Mensagem única para qualquer conta que já exista fora desta empresa:
      // não revelamos se a conta existe nem a que empresa pertence.
      const GENERIC_TAKEN = "Não é possível usar este e-mail. Verifique o endereço ou use outro.";

      if (!existingId) {
        return new Response(JSON.stringify({ error: GENERIC_TAKEN }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Verifica vínculos existentes desse usuário
      const { data: memberships } = await admin
        .from("company_members")
        .select("company_id")
        .eq("user_id", existingId);

      if (memberships && memberships.some((m) => m.company_id === companyId)) {
        // A pessoa já é membro desta empresa. Em vez de bloquear, atualizamos
        // o papel e a senha (se informada) e retornamos sucesso.

        // Um gerente não pode mexer na conta de um CEO: caso contrário poderia
        // trocar a senha do dono da empresa e assumir o acesso dele.
        const { data: targetMember } = await admin
          .from("company_members")
          .select("role")
          .eq("user_id", existingId)
          .eq("company_id", companyId)
          .maybeSingle();
        if (targetMember?.role === "ceo" && callerMember.role !== "ceo") {
          return new Response(
            JSON.stringify({ error: "Você não tem permissão para alterar esta conta." }),
            { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }

        let passwordUpdated = false;
        if (password) {
          if (password.length < 6) {
            passwordWarning =
              "A senha temporária deve ter no mínimo 6 caracteres. O papel foi atualizado, mas a senha não foi alterada.";
          } else {
            const upd = await gotrueUpdateUser(existingId, { password, email_confirm: true });
            if (!upd.ok) {
              if (upd.error === "weak_password") {
                passwordWarning = "A senha escolhida é muito comum ou aparece em vazamentos de dados. O papel foi atualizado, mas a senha não foi alterada. Escolha uma senha mais forte.";
              } else {
                const { error: recoveryErr } = await admin.auth.admin.generateLink({
                  type: "recovery",
                  email,
                });
                passwordWarning = recoveryErr
                  ? "Não foi possível redefinir a senha. O papel foi atualizado — peça para a pessoa usar a opção 'Esqueci minha senha' na tela de login."
                  : "O papel foi atualizado. Não foi possível definir a senha temporária, mas enviamos um e-mail de recuperação para a pessoa redefinir a senha.";
              }
            } else {
              passwordUpdated = true;
            }
          }
        } else {
          // Mesmo sem nova senha, garante que o e-mail está confirmado para a
          // pessoa conseguir entrar com a senha que já conhece.
          await gotrueUpdateUser(existingId, { email_confirm: true });
        }

        // Atualiza o papel e o nome de exibição
        await admin.from("company_members")
          .update({ role, display_name: displayName || email.split("@")[0] })
          .eq("user_id", existingId)
          .eq("company_id", companyId);

        // Se for mecânico, garante o registro na tabela mechanics
        if (role === "mecanico") {
          const { data: existingMech } = await admin
            .from("mechanics")
            .select("id")
            .eq("company_id", companyId)
            .eq("user_id", existingId)
            .maybeSingle();
          if (!existingMech) {
            await admin.from("mechanics").insert({
              company_id: companyId,
              user_id: existingId,
              name: displayName || email.split("@")[0],
              status: "disponivel",
            });
          }
        }

        return new Response(
          JSON.stringify({
            success: true,
            userId: existingId,
            linkedExisting: true,
            alreadyMember: true,
            passwordUpdated,
            passwordWarning,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      // A conta já existe e NÃO pertence a esta empresa.
      //
      // Nunca alteramos a senha nem vinculamos uma conta que já é de outra
      // pessoa/empresa: quem administra uma empresa poderia, de outra forma,
      // escolher uma senha para a conta de qualquer usuário da plataforma e
      // entrar como essa pessoa. Respondemos sempre a mesma mensagem, que
      // também não revela se a conta existe.
      console.warn("create-team-member: refused to link an account owned outside this company");
      return new Response(JSON.stringify({ error: GENERIC_TAKEN }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } else {
      userId = newUser.user.id;
      createdNow = true;
    }

    // Vincula à empresa
    const { error: memberErr } = await admin.from("company_members").insert({
      company_id: companyId,
      user_id: userId,
      role,
      display_name: displayName || email.split("@")[0],
    });

    if (memberErr) {
      if (createdNow) await admin.auth.admin.deleteUser(userId);
      console.error("company_members insert failed", memberErr);
      return new Response(
        JSON.stringify({ error: "Não foi possível vincular o usuário à empresa." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Se for mecânico, cria registro na tabela mechanics (reaproveita se já existir)
    if (role === "mecanico") {
      const { data: existingMech } = await admin
        .from("mechanics")
        .select("id")
        .eq("company_id", companyId)
        .eq("user_id", userId)
        .maybeSingle();
      if (!existingMech) {
        await admin.from("mechanics").insert({
          company_id: companyId,
          user_id: userId,
          name: displayName || email.split("@")[0],
          status: "disponivel",
        });
      }
    }

    return new Response(
      JSON.stringify({ success: true, userId, linkedExisting, passwordWarning }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    console.error("create-team-member error", err);
    return new Response(
      JSON.stringify({ error: "Não foi possível concluir a operação." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
