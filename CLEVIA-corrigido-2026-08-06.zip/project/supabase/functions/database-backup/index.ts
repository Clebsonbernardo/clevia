import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

// Cada tabela é exportada apenas com as linhas da empresa do solicitante.
// `scope` diz qual coluna liga a linha à empresa.
// Tabelas globais (app_settings, system_admins, system_pricing) e tabelas com
// segredos por usuário (user_2fa_secrets) nunca entram no backup do cliente.
const TABLES: { name: string; scope: string }[] = [
  { name: "companies", scope: "id" },
  { name: "company_members", scope: "company_id" },
  { name: "company_licenses", scope: "company_id" },
  { name: "machines", scope: "company_id" },
  { name: "machine_positions", scope: "company_id" },
  { name: "machine_integrations", scope: "company_id" },
  { name: "work_orders", scope: "company_id" },
  { name: "work_order_approvals", scope: "company_id" },
  { name: "mechanics", scope: "company_id" },
  { name: "mechanic_locations", scope: "company_id" },
  { name: "production_logs", scope: "company_id" },
  { name: "production_daily_history", scope: "company_id" },
  { name: "production_sectors", scope: "company_id" },
  { name: "inventory_items", scope: "company_id" },
  { name: "preventive_plans", scope: "company_id" },
  { name: "monitor_screens", scope: "company_id" },
  { name: "ceo_grants", scope: "company_id" },
  { name: "notifications", scope: "company_id" },
  { name: "push_subscriptions", scope: "company_id" },
  { name: "audit_logs", scope: "company_id" },
  { name: "ai_predictions", scope: "company_id" },
  { name: "ai_search_history", scope: "company_id" },
  { name: "knowledge_base", scope: "company_id" },
  { name: "contracts", scope: "company_id" },
  { name: "compliance_audits", scope: "company_id" },
  { name: "compliance_documents", scope: "company_id" },
  { name: "compliance_findings", scope: "company_id" },
  { name: "nr12_machine_inspections", scope: "company_id" },
  { name: "integration_sync_logs", scope: "company_id" },
  { name: "report_templates", scope: "company_id" },
  { name: "branches", scope: "company_id" },
];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: userData, error: authErr } = await supabase.auth.getUser(token);
    if (authErr || !userData.user) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = userData.user.id;

    let companyId: string | null = null;
    try {
      const body = await req.json();
      companyId = typeof body?.company_id === "string" ? body.company_id : null;
    } catch {
      companyId = null;
    }

    if (!companyId) {
      return new Response(JSON.stringify({ error: "Informe a empresa que deseja exportar." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // O backup é sempre da empresa informada, e só o CEO daquela empresa pode pedir.
    const { data: member } = await supabase
      .from("company_members")
      .select("role")
      .eq("user_id", userId)
      .eq("company_id", companyId)
      .maybeSingle();

    if (!member || member.role !== "ceo") {
      return new Response(JSON.stringify({ error: "Apenas o CEO pode exportar o backup do banco" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const lines: string[] = [];
    lines.push("-- ============================================");
    lines.push("-- CLEVIA Cloud - Backup do Banco de Dados");
    lines.push(`-- Gerado em: ${new Date().toISOString()}`);
    lines.push("-- ============================================");
    lines.push("");
    lines.push("SET statement_timeout = 0;");
    lines.push("SET lock_timeout = 0;");
    lines.push("SET client_encoding = 'UTF8';");
    lines.push("SET standard_conforming_strings = on;");
    lines.push("SET check_function_bodies = false;");
    lines.push("SET row_security = off;");
    lines.push("");

    let totalRows = 0;

    for (const { name: table, scope } of TABLES) {
      const { data, error } = await supabase
        .from(table)
        .select("*")
        .eq(scope, companyId);

      if (error) {
        console.error(`backup read failed for ${table}`, error);
        lines.push(`-- Aviso: não foi possível ler a tabela ${table}.`);
        lines.push("");
        continue;
      }

      lines.push(`-- Tabela: ${table} (${data.length} registros)`);
      lines.push("");

      if (data.length === 0) {
        lines.push("");
        continue;
      }

      const columns = Object.keys(data[0]);
      const colList = columns.map((c) => `"${c}"`).join(", ");

      for (const row of data) {
        const values = columns.map((col) => {
          const val = (row as Record<string, unknown>)[col];
          if (val === null || val === undefined) return "NULL";
          if (typeof val === "number") return String(val);
          if (typeof val === "boolean") return val ? "true" : "false";
          if (typeof val === "object") {
            return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
          }
          return `'${String(val).replace(/'/g, "''")}'`;
        });
        lines.push(`INSERT INTO "${table}" (${colList}) VALUES (${values.join(", ")};`);
        totalRows++;
      }
      lines.push("");
    }

    lines.push("-- ============================================");
    lines.push(`-- Total de registros exportados: ${totalRows}`);
    lines.push("-- Fim do backup");
    lines.push("-- ============================================");

    const sql = lines.join("\n");
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const filename = `clevia_backup_${timestamp}.sql`;

    return new Response(JSON.stringify({ sql, filename }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("database-backup failed", err);
    return new Response(JSON.stringify({ error: "Não foi possível gerar o backup." }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
