import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Este endpoint zera a produção do dia de TODAS as empresas, por isso só
    // pode ser disparado pelo próprio sistema (job agendado), nunca por um
    // visitante. A rotina diária normal roda no banco via pg_cron.
    const token = (req.headers.get("Authorization") ?? "").replace("Bearer ", "").trim();
    const cronSecret = Deno.env.get("CRON_SECRET") ?? "";
    const authorized = token !== "" && (token === serviceRoleKey || (cronSecret !== "" && token === cronSecret));
    if (!authorized) {
      return new Response(
        JSON.stringify({ error: "Não autorizado." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      serviceRoleKey
    );

    // Call the archive_and_reset_daily_production function
    const { error } = await supabase.rpc("archive_and_reset_daily_production");

    if (error) {
      console.error("archive_and_reset_daily_production failed", error);
      return new Response(
        JSON.stringify({ error: "Não foi possível concluir a operação." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, message: "Daily production archived and reset successfully", timestamp: new Date().toISOString() }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("midnight-reset failed", err);
    return new Response(
      JSON.stringify({ error: "Não foi possível concluir a operação." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
