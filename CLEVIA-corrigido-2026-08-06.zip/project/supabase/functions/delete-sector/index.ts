import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) throw new Error("Não autenticado");

    const { company_id, sector_name } = await req.json();
    if (!company_id) throw new Error("company_id é obrigatório");
    if (!sector_name) throw new Error("sector_name é obrigatório");

    // Verify the caller is a member with ceo/gerente/admin role
    const { data: member } = await supabaseAdmin
      .from("company_members")
      .select("role")
      .eq("company_id", company_id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (!member) throw new Error("Você não tem permissão nesta empresa");
    if (!["ceo", "gerente", "admin"].includes(member.role)) {
      throw new Error("Apenas CEO, gerente ou admin podem excluir setores");
    }

    // Find all machines in this sector
    const { data: machines } = await supabaseAdmin
      .from("machines")
      .select("id")
      .eq("company_id", company_id)
      .eq("sector", sector_name);

    const machineIds = (machines ?? []).map((m) => m.id);

    if (machineIds.length > 0) {
      // Delete work_orders for those machines
      const { error: woErr } = await supabaseAdmin
        .from("work_orders")
        .delete()
        .in("machine_id", machineIds);
      if (woErr) console.warn("work_orders delete warning:", woErr.message);

      // Delete the machines
      const { error: mErr } = await supabaseAdmin
        .from("machines")
        .delete()
        .in("id", machineIds);
      if (mErr) throw new Error("Erro ao excluir máquinas: " + mErr.message);
    }

    // Delete the sector (monitor_screens row)
    const { error: sErr } = await supabaseAdmin
      .from("monitor_screens")
      .delete()
      .eq("company_id", company_id)
      .eq("name", sector_name);
    if (sErr) throw new Error("Erro ao excluir setor: " + sErr.message);

    // Also remove from production_sectors so it stops appearing in the chart
    const { error: psErr } = await supabaseAdmin
      .from("production_sectors")
      .delete()
      .eq("company_id", company_id)
      .eq("sector_name", sector_name);
    if (psErr) console.warn("production_sectors delete warning:", psErr.message);

    return new Response(
      JSON.stringify({
        success: true,
        machines_deleted: machineIds.length,
        sector_name,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("delete-sector failed", err);
    const message = err instanceof Error ? err.message : "Não foi possível concluir a operação.";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
