import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(JSON.stringify({ error: "Não autorizado." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const caller = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: callerUser, error: callerErr } = await caller.auth.getUser();
    if (callerErr || !callerUser.user) {
      return new Response(JSON.stringify({ error: "Sessão inválida." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { targetUserId, newPassword, companyId } = body as {
      targetUserId: string;
      newPassword: string;
      companyId: string;
    };

    if (!targetUserId || !newPassword || !companyId) {
      return new Response(JSON.stringify({ error: "Dados incompletos." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (newPassword.length < 6) {
      return new Response(JSON.stringify({ error: "A senha deve ter no mínimo 6 caracteres." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verifica se o chamador é admin (ceo/gerente) da empresa
    const { data: callerMember } = await admin
      .from("company_members")
      .select("role")
      .eq("user_id", callerUser.user.id)
      .eq("company_id", companyId)
      .maybeSingle();

    if (!callerMember || !["ceo", "gerente"].includes(callerMember.role)) {
      return new Response(
        JSON.stringify({ error: "Você não tem permissão para redefinir senhas." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Verifica se o usuário-alvo pertence à mesma empresa
    const { data: targetMember } = await admin
      .from("company_members")
      .select("user_id, role")
      .eq("user_id", targetUserId)
      .eq("company_id", companyId)
      .maybeSingle();

    if (!targetMember) {
      return new Response(
        JSON.stringify({ error: "Usuário não pertence a esta empresa." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Um gerente não pode redefinir a senha de um CEO: se pudesse, bastaria
    // trocar a senha do dono da empresa para entrar como ele.
    if (targetMember.role === "ceo" && callerMember.role !== "ceo") {
      return new Response(
        JSON.stringify({ error: "Você não tem permissão para redefinir a senha desta conta." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Nem o dono da empresa pode ter a senha trocada por outra pessoa.
    const { data: ownedCompany } = await admin
      .from("companies")
      .select("owner_id")
      .eq("id", companyId)
      .maybeSingle();

    if (ownedCompany?.owner_id === targetUserId && callerUser.user.id !== targetUserId) {
      return new Response(
        JSON.stringify({ error: "Você não tem permissão para redefinir a senha desta conta." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Redefine a senha do usuário via GoTrue REST API direto
    const url = `${supabaseUrl.replace(/\/$/, "")}/auth/v1/admin/users/${targetUserId}`;
    console.log("GoTrue update URL:", url);
    const res = await fetch(url, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${serviceRoleKey}`,
        apikey: serviceRoleKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ password: newPassword, email_confirm: true }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error("GoTrue updateUser failed", res.status, text);
      let friendly = "Não foi possível redefinir a senha. Tente novamente.";
      try {
        const parsed = JSON.parse(text);
        if (parsed?.error_code === "weak_password" || parsed?.weak_password) {
          friendly = "Esta senha é muito comum ou aparece em vazamentos de dados conhecidos. Escolha uma senha mais forte — use letras maiúsculas e minúsculas, números e símbolos, e evite sequências como 123456 ou senha123.";
        }
      } catch {}
      return new Response(
        JSON.stringify({ error: friendly }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    console.error("reset-user-password error", err);
    return new Response(
      JSON.stringify({ error: "Não foi possível concluir a operação." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
