import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase, type Company, type CompanyMember, type CompanyFeatureGrant, type LicenseStatusResult } from '@/lib/supabase';
import { logAction } from '@/lib/audit';
import { isOnline, cacheCompanyData, getCachedCompanyData } from '@/lib/offline';

type AuthContextValue = {
  session: Session | null;
  user: User | null;
  loading: boolean;
  activeCompany: Company | null;
  activeRole: string | null;
  members: CompanyMember[];
  license: LicenseStatusResult | null;
  licenseLoading: boolean;
  companyLoading: boolean;
  planType: 'basic' | 'premium';
  isAdmin: boolean;
  pricePerUser: number;
  featureGrants: CompanyFeatureGrant[];
  hasFeatureGrant: (featureKey: string) => boolean;
  refreshFeatureGrants: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  setActiveCompany: (c: Company | null) => void;
  refreshMembers: () => Promise<void>;
  refreshLicense: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  // Read the session synchronously from localStorage on first render.
  // supabase.auth.getSession() is async (even though it reads from localStorage),
  // and that async gap causes the "Carregando..." flash when a logged-in user
  // reopens the app. By reading the cached session inline we can render the
  // dashboard on the very first paint.
  const [initialSession] = useState<Session | null>(() => {
    try {
      const raw = localStorage.getItem('sb-wcwgatbkbjmfueogewbl-auth-token');
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      // Supabase stores either { access_token, ... } or { currentSession: { ... } }
      const session = parsed?.currentSession ?? parsed;
      if (session?.access_token && session?.user?.id) return session as Session;
      return null;
    } catch {
      return null;
    }
  });

  const [session, setSession] = useState<Session | null>(initialSession);
  const [loading, setLoading] = useState(initialSession ? false : true);

  // Restore cached company data synchronously so the dashboard renders on
  // the very first paint — no loading flash when reopening the app.
  const [initialCompany] = useState(() => {
    if (!initialSession) return null;
    const cached = getCachedCompanyData();
    return cached;
  });
  const [activeCompany, setActiveCompanyState] = useState<Company | null>(() => {
    if (!initialCompany?.company) return null;
    return initialCompany.company as Company;
  });
  const [members, setMembers] = useState<CompanyMember[]>(() => {
    if (!initialCompany?.members) return [];
    return initialCompany.members as CompanyMember[];
  });
  const [activeRole, setActiveRole] = useState<string | null>(() => {
    if (!initialSession || !initialCompany?.company || !initialCompany?.members) return null;
    const m = (initialCompany.members as CompanyMember[]).find(
      (x) => x.company_id === (initialCompany.company as Company).id && x.user_id === initialSession.user.id
    );
    return m?.role ?? null;
  });
  const [isAdmin, setIsAdmin] = useState(() => initialCompany?.is_admin ?? false);
  const [license, setLicense] = useState<LicenseStatusResult | null>(null);
  const [licenseLoading, setLicenseLoading] = useState(false);
  const [companyLoading, setCompanyLoading] = useState(false);
  const [pricePerUser, setPricePerUser] = useState(49.90);
  const [featureGrants, setFeatureGrants] = useState<CompanyFeatureGrant[]>([]);

  useEffect(() => {
    // If we already have a session from localStorage, validate it with Supabase
    // in the background — don't block the UI. If it's expired, onAuthStateChange
    // will fire with null and we'll show the login screen.
    if (initialSession) {
      supabase.auth.getSession().then(({ data }) => {
        if (data.session) setSession(data.session);
      });
    } else {
      supabase.auth.getSession().then(({ data }) => {
        setSession(data.session);
        if (!data.session) setLoading(false);
      });
    }

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      (async () => {
        setSession(newSession);
        if (!newSession) {
          setIsAdmin(false);
          setActiveCompanyState(null);
          setMembers([]);
          setActiveRole(null);
          setLicense(null);
          setCompanyLoading(false);
          setLoading(false);
        }
      })();
    });

    return () => { listener.subscription.unsubscribe(); };
  }, [initialSession]);

  // Carrega empresas do usuário quando a sessão muda
  useEffect(() => {
    if (!session?.user) {
      setCompanyLoading(false);
      return;
    }

    // 1. Instantly restore from cache so the app opens without waiting for network.
    //    Fresh data is fetched in the background and updates state when it arrives.
    const cached = getCachedCompanyData();
    if (cached?.company) {
      setActiveCompanyState(cached.company as Company);
      setMembers(cached.members as CompanyMember[]);
      setIsAdmin(cached.is_admin);
      const m = (cached.members as CompanyMember[]).find(
        (x) => x.company_id === (cached.company as Company).id && x.user_id === session.user.id
      );
      setActiveRole(m?.role ?? null);
    }
    // Whether online or offline, unblock the loading screen immediately —
    // the user sees the dashboard right away.
    setCompanyLoading(false);
    setLoading(false);

    // 2. If offline, skip the network fetch entirely — cached data is all we have.
    if (!isOnline()) return;

    // 3. Fetch fresh data in the background. This updates state if anything changed,
    //    but the user is already in the app and doesn't wait for this.
    (async () => {
      const [adminRes, pricingRes, memberRes] = await Promise.all([
        supabase.from('system_admins').select('email').eq('email', session.user.email ?? '').maybeSingle(),
        supabase.from('system_pricing').select('price_per_user').eq('id', 1).maybeSingle(),
        supabase.from('company_members').select('*, companies(*)').eq('user_id', session.user.id),
      ]);

      setIsAdmin(!!adminRes.data);
      if (pricingRes.data?.price_per_user) setPricePerUser(Number(pricingRes.data.price_per_user));

      const memberRows = memberRes.data;
      if (memberRows && memberRows.length > 0) {
        const stored = localStorage.getItem('clevia-active-company');
        const found = stored
          ? memberRows.find((m: { companies: Company }) => m.companies?.id === stored)?.companies
          : null;
        const company = found ?? (memberRows[0] as { companies: Company }).companies;
        setActiveCompanyState(company);
        setMembers(memberRows as unknown as CompanyMember[]);
        cacheCompanyData(company, memberRows as unknown as CompanyMember[], !!adminRes.data);
        if (localStorage.getItem('clevia_pending_login_audit')) {
          const companyId = company?.id;
          if (companyId) {
            logAction(companyId, 'login', 'auth', undefined, `Usuário ${session?.user?.email || ''} entrou no sistema`);
          }
          localStorage.removeItem('clevia_pending_login_audit');
        }
      }
    })();
  }, [session]);

  // Atualiza o papel ativo quando a empresa ou membros mudam
  useEffect(() => {
    if (activeCompany && session?.user) {
      const m = members.find((x) => x.company_id === activeCompany.id && x.user_id === session.user.id);
      setActiveRole(m?.role ?? null);
    } else {
      setActiveRole(null);
    }
  }, [activeCompany, members, session]);

  // Carrega status da licença da empresa ativa
  const refreshFeatureGrants = async () => {
    if (!activeCompany) { setFeatureGrants([]); return; }
    const { data } = await supabase
      .from('company_feature_grants')
      .select('*')
      .eq('company_id', activeCompany.id);
    setFeatureGrants(data ?? []);
  };

  const refreshLicense = async () => {
    if (!activeCompany) { setLicense(null); return; }
    // When offline, skip license check — don't block the user from working
    if (!isOnline()) { setLicenseLoading(false); return; }
    setLicenseLoading(true);
    const { data, error } = await supabase.rpc('get_company_license_status', { p_company_id: activeCompany.id });
    if (error) { console.error('license status check failed', error); setLicense(null); }
    else setLicense((data as LicenseStatusResult) ?? null);
    setLicenseLoading(false);
  };

  useEffect(() => {
    refreshLicense();
    refreshFeatureGrants();
    if (!activeCompany) return;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    try {
      channel = supabase.channel('feature-grants-realtime')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'company_feature_grants', filter: `company_id=eq.${activeCompany.id}` }, refreshFeatureGrants)
        .subscribe();
    } catch {
      channel = null;
    }
    return () => { if (channel) supabase.removeChannel(channel); };
  }, [activeCompany]);

  const refreshMembers = async () => {
    if (!session?.user) return;
    const { data } = await supabase.from('company_members').select('*, companies(*)').eq('user_id', session.user.id);
    setMembers(data ?? []);
  };

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (!error && data.session) {
      // Set session immediately from the response — don't wait for onAuthStateChange.
      // This shaves the event-loop round-trip and makes login feel instant.
      setSession(data.session);

      // Restore cached company data right now so the dashboard appears with zero loading.
      const cached = getCachedCompanyData();
      if (cached?.company) {
        setActiveCompanyState(cached.company as Company);
        setMembers(cached.members as CompanyMember[]);
        setIsAdmin(cached.is_admin);
        const m = (cached.members as CompanyMember[]).find(
          (x) => x.company_id === (cached.company as Company).id && x.user_id === data.session.user.id
        );
        setActiveRole(m?.role ?? null);
      }
      setCompanyLoading(false);
      setLoading(false);
      localStorage.setItem('clevia_pending_login_audit', '1');
    }
    return { error: error ? translateError(error.message) : null };
  };

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    return { error: error ? translateError(error.message) : null };
  };

  const signOut = async () => {
    if (activeCompany) {
      await logAction(activeCompany.id, 'logout', 'auth', undefined, `Usuário ${session?.user?.email || ''} saiu do sistema`);
    }
    await supabase.auth.signOut();
    setSession(null);
    setActiveCompanyState(null);
    setMembers([]);
    setActiveRole(null);
    setLicense(null);
    setFeatureGrants([]);
    localStorage.removeItem('clevia-active-company');
  };

  const setActiveCompany = (c: Company | null) => {
    setActiveCompanyState(c);
    if (c) localStorage.setItem('clevia-active-company', c.id);
    else localStorage.removeItem('clevia-active-company');
  };

  return (
    <AuthContext.Provider value={{
      session, user: session?.user ?? null, loading,
      activeCompany, activeRole, members,
      license, licenseLoading, companyLoading,
      planType: license?.plan_type ?? 'basic',
      isAdmin,
      pricePerUser,
      featureGrants,
      hasFeatureGrant: (featureKey: string) => featureGrants.some(g => g.feature_key === featureKey && g.granted),
      refreshFeatureGrants,
      signIn, signUp, signOut, setActiveCompany, refreshMembers, refreshLicense,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

function translateError(message: string): string {
  if (message.includes('Invalid login credentials')) return 'E-mail ou senha incorretos.';
  // Não confirmamos se um e-mail já possui conta: isso permitiria descobrir
  // quais pessoas usam o sistema. Mensagem neutra para o mesmo caso.
  if (message.includes('User already registered')) {
    return 'Não foi possível concluir o cadastro com estes dados. Verifique o e-mail informado ou entre com sua conta.';
  }
  if (message.includes('Password should be at least')) return 'A senha deve ter pelo menos 6 caracteres.';
  if (message.includes('Unable to validate email')) return 'E-mail inválido.';
  // Nunca devolvemos a mensagem original do servidor: ela expõe detalhes internos.
  console.error('auth error', message);
  return 'Não foi possível concluir a operação. Tente novamente.';
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider');
  return ctx;
}
