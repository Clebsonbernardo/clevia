import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase, type AuditLog } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { EmptyState, Spinner, inputCls } from '@/components/ui';
import {
  AlertTriangle, CalendarDays, ChevronDown, ChevronLeft, ChevronRight, ChevronUp,
  Clock, Download, FileJson, FilterX, Globe, Monitor, MousePointerClick, RefreshCw,
  Search, ShieldAlert, ShieldCheck, Trash2, User,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const PAGE_SIZE = 25;

const ACTIONS: Record<string, { color: string; bg: string; label: string; risk: 'baixo' | 'medio' | 'alto' }> = {
  create: { color: 'text-emerald-300', bg: 'bg-emerald-500/10', label: 'Criação', risk: 'baixo' },
  update: { color: 'text-amber-300', bg: 'bg-amber-500/10', label: 'Alteração', risk: 'medio' },
  delete: { color: 'text-rose-300', bg: 'bg-rose-500/10', label: 'Exclusão', risk: 'alto' },
  login: { color: 'text-sky-300', bg: 'bg-sky-500/10', label: 'Login', risk: 'baixo' },
  logout: { color: 'text-slate-300', bg: 'bg-slate-500/10', label: 'Logout', risk: 'baixo' },
  accept: { color: 'text-cyan-300', bg: 'bg-cyan-500/10', label: 'OS assumida', risk: 'baixo' },
  finish: { color: 'text-violet-300', bg: 'bg-violet-500/10', label: 'OS finalizada', risk: 'medio' },
  pause: { color: 'text-orange-300', bg: 'bg-orange-500/10', label: 'OS pausada', risk: 'medio' },
  resume: { color: 'text-teal-300', bg: 'bg-teal-500/10', label: 'OS retomada', risk: 'baixo' },
  transfer: { color: 'text-indigo-300', bg: 'bg-indigo-500/10', label: 'Transferência', risk: 'medio' },
  permission_change: { color: 'text-rose-300', bg: 'bg-rose-500/10', label: 'Permissão alterada', risk: 'alto' },
  password_reset: { color: 'text-rose-300', bg: 'bg-rose-500/10', label: 'Senha redefinida', risk: 'alto' },
};

const ENTITY_LABELS: Record<string, string> = {
  work_order: 'Ordem de Serviço', machine: 'Máquina', mechanic: 'Mecânico', user: 'Usuário',
  company: 'Empresa', inventory_item: 'Estoque', preventive_plan: 'Preventiva', production_log: 'Produção',
  integration: 'Integração', company_license: 'Licença', permission: 'Permissão', settings: 'Configuração',
};

const dateTime = (value: string) => new Date(value).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'medium' });
const csvSafe = (value: unknown) => {
  let text = typeof value === 'string' ? value : JSON.stringify(value ?? '');
  if (/^[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
};

function exportCsv(rows: AuditLog[], companyName: string) {
  const header = ['Data/Hora', 'Usuário', 'Ação', 'Módulo', 'Registro', 'Descrição', 'IP', 'Dispositivo', 'Metadados'];
  const content = [header.map(csvSafe).join(';'), ...rows.map((log) => [
    dateTime(log.created_at), log.user_email || 'Sistema', ACTIONS[log.action]?.label || log.action,
    ENTITY_LABELS[log.entity_type || ''] || log.entity_type || '', log.entity_id || '', log.description || '',
    log.ip_address || '', log.device_info || '', log.metadata,
  ].map(csvSafe).join(';'))].join('\n');
  const blob = new Blob([`\uFEFF${content}`], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `auditoria-${companyName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-${new Date().toISOString().slice(0, 10)}.csv`;
  anchor.click();
  URL.revokeObjectURL(url);
}

export default function AuditLogScreen() {
  const { activeCompany } = useAuth();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [action, setAction] = useState('all');
  const [entity, setEntity] = useState('all');
  const [risk, setRisk] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [page, setPage] = useState(1);
  const [expanded, setExpanded] = useState<string | null>(null);

  const loadLogs = useCallback(async () => {
    if (!activeCompany) return;
    setLoading(true);
    setError(null);
    const { data, error: queryError } = await supabase
      .from('audit_logs').select('*').eq('company_id', activeCompany.id)
      .order('created_at', { ascending: false }).limit(2000);
    if (queryError) setError('Não foi possível carregar a auditoria. Verifique sua permissão de acesso.');
    else setLogs((data || []) as AuditLog[]);
    setLoading(false);
  }, [activeCompany]);

  useEffect(() => { void loadLogs(); }, [loadLogs]);
  useEffect(() => {
    if (!activeCompany) return;
    const channel = supabase.channel(`audit-${activeCompany.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'audit_logs', filter: `company_id=eq.${activeCompany.id}` },
        (payload) => setLogs((previous) => [payload.new as AuditLog, ...previous].slice(0, 2000)))
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [activeCompany]);

  const actionTypes = useMemo(() => Array.from(new Set(logs.map((log) => log.action))).sort(), [logs]);
  const entityTypes = useMemo(() => Array.from(new Set(logs.map((log) => log.entity_type).filter(Boolean) as string[])).sort(), [logs]);
  const filtered = useMemo(() => logs.filter((log) => {
    const cfg = ACTIONS[log.action];
    const haystack = `${log.description || ''} ${log.user_email || ''} ${log.action} ${log.entity_type || ''} ${log.entity_id || ''}`.toLowerCase();
    if (search && !haystack.includes(search.trim().toLowerCase())) return false;
    if (action !== 'all' && log.action !== action) return false;
    if (entity !== 'all' && log.entity_type !== entity) return false;
    if (risk !== 'all' && (cfg?.risk || 'medio') !== risk) return false;
    const created = new Date(log.created_at);
    if (startDate && created < new Date(`${startDate}T00:00:00`)) return false;
    if (endDate && created > new Date(`${endDate}T23:59:59.999`)) return false;
    return true;
  }), [logs, search, action, entity, risk, startDate, endDate]);

  useEffect(() => setPage(1), [search, action, entity, risk, startDate, endDate]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const rows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const today = new Date().toISOString().slice(0, 10);
  const todayCount = logs.filter((log) => log.created_at.slice(0, 10) === today).length;
  const uniqueUsers = new Set(logs.map((log) => log.user_email).filter(Boolean)).size;
  const highRisk = logs.filter((log) => ACTIONS[log.action]?.risk === 'alto').length;
  const stats: Array<{ label: string; value: number; icon: LucideIcon; color: string }> = [
    { label: 'Registros carregados', value: logs.length, icon: ShieldCheck, color: 'text-cyan-300' },
    { label: 'Ações hoje', value: todayCount, icon: CalendarDays, color: 'text-emerald-300' },
    { label: 'Usuários identificados', value: uniqueUsers, icon: User, color: 'text-violet-300' },
    { label: 'Eventos de alto risco', value: highRisk, icon: AlertTriangle, color: 'text-rose-300' },
  ];

  const clearFilters = () => { setSearch(''); setAction('all'); setEntity('all'); setRisk('all'); setStartDate(''); setEndDate(''); };

  return (
    <div className="space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2"><ShieldAlert className="w-6 h-6 text-rose-300" />Auditoria empresarial</h1>
          <p className="text-sm text-slate-400 mt-1">Rastreabilidade protegida das ações realizadas no CLEVIA</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => void loadLogs()} className="px-3 py-2 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 flex items-center gap-2 text-sm"><RefreshCw className="w-4 h-4" />Atualizar</button>
          <button disabled={!filtered.length} onClick={() => exportCsv(filtered, activeCompany?.name || 'clevia')} className="px-3 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white flex items-center gap-2 text-sm"><Download className="w-4 h-4" />Exportar CSV</button>
        </div>
      </div>

      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {stats.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/40">
            <Icon className={`w-5 h-5 ${color}`} /><p className="text-2xl font-bold text-white mt-2">{value}</p><p className="text-xs text-slate-400">{label}</p>
          </div>
        ))}
      </div>

      <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/40 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-6 gap-2">
          <div className="relative xl:col-span-2"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Usuário, descrição, registro..." className={`${inputCls} pl-9 text-sm`} /></div>
          <select value={action} onChange={(event) => setAction(event.target.value)} className={`${inputCls} text-sm`}><option value="all">Todas as ações</option>{actionTypes.map((item) => <option key={item} value={item}>{ACTIONS[item]?.label || item}</option>)}</select>
          <select value={entity} onChange={(event) => setEntity(event.target.value)} className={`${inputCls} text-sm`}><option value="all">Todos os módulos</option>{entityTypes.map((item) => <option key={item} value={item}>{ENTITY_LABELS[item] || item}</option>)}</select>
          <select value={risk} onChange={(event) => setRisk(event.target.value)} className={`${inputCls} text-sm`}><option value="all">Todos os riscos</option><option value="baixo">Risco baixo</option><option value="medio">Risco médio</option><option value="alto">Risco alto</option></select>
          <button onClick={clearFilters} className="px-3 py-2 rounded-lg border border-slate-700 text-slate-400 hover:text-white flex items-center justify-center gap-2 text-sm"><FilterX className="w-4 h-4" />Limpar</button>
        </div>
        <div className="flex flex-wrap items-center gap-2"><span className="text-xs text-slate-500">Período:</span><input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} className={`${inputCls} text-sm w-auto`} /><span className="text-slate-600">até</span><input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} className={`${inputCls} text-sm w-auto`} /><span className="text-xs text-slate-500 ml-auto">{filtered.length} resultado(s)</span></div>
      </div>

      {error && <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-200 text-sm">{error}</div>}
      {loading ? <div className="flex justify-center py-20"><Spinner /></div> : rows.length === 0 ? <EmptyState icon={ShieldAlert} text="Nenhum registro de auditoria encontrado" /> : (
        <div className="space-y-2">
          {rows.map((log) => {
            const cfg = ACTIONS[log.action] || { color: 'text-slate-300', bg: 'bg-slate-500/10', label: log.action, risk: 'medio' as const };
            const isOpen = expanded === log.id;
            return <article key={log.id} className="rounded-xl bg-slate-800/40 border border-slate-700/30 overflow-hidden">
              <button onClick={() => setExpanded(isOpen ? null : log.id)} className="w-full text-left p-4 flex items-start gap-3 hover:bg-slate-800/70 transition">
                <span className={`shrink-0 w-10 h-10 rounded-lg ${cfg.bg} flex items-center justify-center`}><MousePointerClick className={`w-4 h-4 ${cfg.color}`} /></span>
                <span className="flex-1 min-w-0">
                  <span className="flex items-center gap-2 flex-wrap"><strong className={`text-sm ${cfg.color}`}>{cfg.label}</strong><span className="text-xs px-2 py-0.5 rounded-full bg-slate-700/60 text-slate-300">{ENTITY_LABELS[log.entity_type || ''] || log.entity_type || 'Sistema'}</span><span className={`text-[10px] uppercase tracking-wide ${cfg.risk === 'alto' ? 'text-rose-300' : cfg.risk === 'medio' ? 'text-amber-300' : 'text-emerald-300'}`}>Risco {cfg.risk}</span></span>
                  <span className="block text-sm text-slate-300 mt-1">{log.description || 'Ação registrada sem descrição.'}</span>
                  <span className="flex items-center gap-4 mt-2 flex-wrap text-xs text-slate-400"><span className="flex items-center gap-1"><User className="w-3 h-3" />{log.user_email || 'Sistema'}</span><span className="flex items-center gap-1"><Clock className="w-3 h-3" />{dateTime(log.created_at)}</span></span>
                </span>{isOpen ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
              </button>
              {isOpen && <div className="px-4 pb-4 pt-1 border-t border-slate-700/30 grid lg:grid-cols-2 gap-3 text-xs">
                <div className="space-y-2 text-slate-400"><p><b className="text-slate-300">ID do evento:</b> {log.id}</p><p><b className="text-slate-300">ID do registro:</b> {log.entity_id || 'Não informado'}</p><p className="flex items-center gap-1"><Globe className="w-3 h-3" /><b className="text-slate-300">IP:</b> {log.ip_address || 'Não capturado'}</p><p className="flex items-start gap-1"><Monitor className="w-3 h-3 mt-0.5" /><b className="text-slate-300">Dispositivo:</b> {log.device_info || String(log.metadata?.device_info || 'Não capturado')}</p></div>
                <div><p className="text-slate-300 font-medium flex items-center gap-1 mb-1"><FileJson className="w-3 h-3" />Detalhes técnicos</p><pre className="max-h-48 overflow-auto whitespace-pre-wrap break-all rounded-lg bg-slate-950/60 p-3 text-slate-400">{JSON.stringify(log.metadata || {}, null, 2)}</pre></div>
              </div>}
            </article>;
          })}
        </div>
      )}

      {!loading && filtered.length > PAGE_SIZE && <div className="flex items-center justify-between gap-3 text-sm"><span className="text-slate-500">Página {page} de {totalPages}</span><div className="flex gap-2"><button disabled={page === 1} onClick={() => setPage((value) => value - 1)} className="p-2 rounded-lg border border-slate-700 disabled:opacity-40 text-slate-300"><ChevronLeft className="w-4 h-4" /></button><button disabled={page === totalPages} onClick={() => setPage((value) => value + 1)} className="p-2 rounded-lg border border-slate-700 disabled:opacity-40 text-slate-300"><ChevronRight className="w-4 h-4" /></button></div></div>}

      <div className="p-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5 flex items-start gap-2 text-xs text-emerald-200/80"><ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" /><span>Os eventos são vinculados ao usuário autenticado e ficam protegidos contra edição e exclusão. A visualização é destinada à direção e à gestão autorizada.</span></div>
    </div>
  );
}
