import { useState, useEffect, useCallback } from 'react';
import { supabase, type CompanyFeatureGrant } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { ShieldCheck, Building2, ToggleLeft, ToggleRight, Loader2, Search, Sparkles } from 'lucide-react';

const FEATURE_KEYS = [
  { key: 'contracts', label: 'Contratos', desc: 'Gestão de contratos da empresa' },
  { key: 'licenses', label: 'Licenças', desc: 'Controle de licenças e pagamentos' },
  { key: 'settings', label: 'Configurações', desc: 'Configurações avançadas do sistema' },
  { key: 'integrations', label: 'Integrações', desc: 'Integração com sistemas externos' },
  { key: 'techdoc', label: 'Documento Técnico', desc: 'Documentação técnica do sistema' },
];

type Company = { id: string; name: string; cnpj: string | null };

export default function FeatureGrantsScreen() {
  const { isAdmin } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [grants, setGrants] = useState<CompanyFeatureGrant[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [toggling, setToggling] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    const [{ data: comps }, { data: grs }] = await Promise.all([
      supabase.from('companies').select('id, name, cnpj').order('name'),
      supabase.from('company_feature_grants').select('*'),
    ]);
    setCompanies(comps ?? []);
    setGrants(grs ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (isAdmin) loadData();
  }, [isAdmin, loadData]);

  useEffect(() => {
    if (!isAdmin) return;
    const channel = supabase.channel('feature-grants-rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'company_feature_grants' }, loadData)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [isAdmin, loadData]);

  const toggleGrant = async (companyId: string, featureKey: string) => {
    const key = `${companyId}-${featureKey}`;
    setToggling(key);
    const existing = grants.find(g => g.company_id === companyId && g.feature_key === featureKey);
    try {
      if (existing) {
        await supabase.from('company_feature_grants')
          .update({ granted: !existing.granted })
          .eq('id', existing.id);
      } else {
        await supabase.from('company_feature_grants')
          .insert({ company_id: companyId, feature_key: featureKey, granted: true });
      }
      loadData();
    } finally {
      setToggling(null);
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <ShieldCheck className="w-12 h-12 text-rose-400 mx-auto mb-3" />
          <p className="text-slate-400">Acesso restrito ao administrador do sistema.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
      </div>
    );
  }

  const filtered = companies.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.cnpj ?? '').includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Liberação de Recursos por Empresa</h2>
            <p className="text-sm text-slate-400">Ative ou desative funcionalidades específicas para cada cliente. Só você, administrador do sistema, tem acesso a esta tela.</p>
          </div>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar empresa por nome ou CNPJ..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
        />
      </div>

      <div className="space-y-3">
        {filtered.map((company) => (
          <div key={company.id} className="rounded-xl bg-slate-800/50 border border-slate-700/50 overflow-hidden">
            <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-700/40">
              <Building2 className="w-5 h-5 text-cyan-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-white truncate">{company.name}</p>
                <p className="text-xs text-slate-500">{company.cnpj || 'Sem CNPJ'}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 p-4">
              {FEATURE_KEYS.map((feat) => {
                const grant = grants.find(g => g.company_id === company.id && g.feature_key === feat.key);
                const isActive = grant?.granted ?? false;
                const toggleKey = `${company.id}-${feat.key}`;
                const isToggling = toggling === toggleKey;
                return (
                  <button
                    key={feat.key}
                    onClick={() => toggleGrant(company.id, feat.key)}
                    disabled={isToggling}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg border transition-all duration-200 text-left ${
                      isActive
                        ? 'bg-emerald-500/10 border-emerald-500/30 hover:bg-emerald-500/20'
                        : 'bg-slate-800/40 border-slate-700/30 hover:bg-slate-800/70'
                    }`}
                  >
                    {isToggling ? (
                      <Loader2 className="w-5 h-5 text-slate-400 animate-spin shrink-0" />
                    ) : isActive ? (
                      <ToggleRight className="w-5 h-5 text-emerald-400 shrink-0" />
                    ) : (
                      <ToggleLeft className="w-5 h-5 text-slate-500 shrink-0" />
                    )}
                    <div className="min-w-0">
                      <p className={`text-sm font-medium ${isActive ? 'text-emerald-300' : 'text-slate-400'}`}>{feat.label}</p>
                      <p className="text-xs text-slate-500 truncate">{feat.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-500 text-sm">Nenhuma empresa encontrada.</p>
          </div>
        )}
      </div>

      <div className="rounded-xl bg-amber-500/5 border border-amber-500/20 p-4 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <p className="text-xs text-slate-400 leading-relaxed">
          Esta tela é exclusiva do administrador do sistema. Nenhum cliente, nem mesmo o CEO de uma empresa, consegue acessá-la.
          As alterações feitas aqui afetam apenas a empresa selecionada — nenhum outro cliente é impactado.
        </p>
      </div>
    </div>
  );
}
