import { useState, type FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { Mail, Lock, ArrowRight, Loader2, CheckCircle2, KeyRound } from 'lucide-react';
import { CleviaGear } from '@/components/CleviaLogo';

export default function ResetPasswordScreen() {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < 6) { setError('A senha deve ter pelo menos 6 caracteres.'); return; }
    if (password !== confirm) { setError('As senhas não coincidem.'); return; }
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) {
        setError('Não foi possível redefinir a senha. O link pode ter expirado — solicite um novo.');
      } else {
        setDone(true);
        setTimeout(() => { window.location.hash = ''; window.location.reload(); }, 2500);
      }
    } catch {
      setError('Erro inesperado. Tente novamente.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 px-6 py-12 relative overflow-hidden">
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: 'radial-gradient(circle at 50% 20%, rgba(34,211,238,0.15) 0%, transparent 50%), radial-gradient(circle at 50% 80%, rgba(14,165,233,0.1) 0%, transparent 50%)'
      }} />
      <div className="absolute inset-0 opacity-[0.025]" style={{
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)',
        backgroundSize: '48px 48px'
      }} />

      <div className="relative z-10 w-full max-w-md flex flex-col items-center">
        <div className="flex flex-col items-center text-center mb-12">
          <CleviaGear size={120} className="mx-auto" />
          <h1 className="mt-6 text-7xl sm:text-8xl font-black tracking-[0.15em] bg-gradient-to-r from-cyan-300 via-sky-400 to-blue-500 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(56,189,248,0.4)]">
            CLEVIA
          </h1>
          <div className="mt-3 flex items-center justify-center gap-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-cyan-500/50" />
            <p className="text-xs font-semibold tracking-[0.3em] uppercase text-slate-500">Plataforma de Gestão</p>
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-cyan-500/50" />
          </div>
        </div>

        <div className="w-full bg-slate-900/70 backdrop-blur-xl border border-slate-800 rounded-2xl p-8 shadow-2xl shadow-cyan-500/5">
          {done ? (
            <div className="space-y-5">
              <div className="flex flex-col items-center text-center gap-3 py-4">
                <CheckCircle2 className="w-12 h-12 text-emerald-400" />
                <h2 className="text-xl font-bold text-white">Senha redefinida!</h2>
                <p className="text-sm text-slate-300">Sua senha foi atualizada com sucesso. Você será redirecionado para o login.</p>
              </div>
            </div>
          ) : (
            <>
              <div className="text-center mb-8">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 to-sky-500 flex items-center justify-center shadow-lg shadow-cyan-500/30 mx-auto mb-4">
                  <KeyRound className="w-7 h-7 text-slate-950" strokeWidth={2.5} />
                </div>
                <h2 className="text-xl font-bold text-white">Redefinir senha</h2>
                <p className="text-sm text-slate-400 mt-1.5">Digite sua nova senha abaixo</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Nova senha</label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                    <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mínimo 6 caracteres"
                      className="w-full pl-11 pr-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Confirmar senha</label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                    <input type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Repita a nova senha"
                      className="w-full pl-11 pr-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition" />
                  </div>
                </div>
                {error && <div className="px-4 py-3 rounded-lg text-sm bg-rose-950/50 border border-rose-800 text-rose-300">{error}</div>}
                <button type="submit" disabled={loading}
                  className="w-full flex items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-cyan-400 to-sky-500 text-slate-950 font-semibold rounded-xl hover:from-cyan-300 hover:to-sky-400 transition shadow-lg shadow-cyan-500/20 disabled:opacity-60 disabled:cursor-not-allowed">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Redefinir senha <ArrowRight className="w-5 h-5" /></>}
                </button>
              </form>
            </>
          )}
        </div>

        <p className="mt-10 text-center text-xs text-slate-600">
          © 2026 CLEVIA Software · Clebson Bernardo Velho
        </p>
      </div>
    </div>
  );
}
