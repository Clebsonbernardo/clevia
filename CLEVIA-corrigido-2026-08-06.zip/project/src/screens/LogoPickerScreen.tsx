import { useState } from 'react';
import { Check, ArrowLeft, Download, Eye } from 'lucide-react';
import { LOGO_VARIANTS, setChosenLogo, useChosenLogo, type LogoVariant } from '@/components/CleviaLogo';

export default function LogoPickerScreen({ onBack }: { onBack: () => void }) {
  const chosen = useChosenLogo();
  const [preview, setPreview] = useState<LogoVariant | null>(null);

  const handleSelect = (v: LogoVariant) => {
    setChosenLogo(v);
  };

  const handleDownload = (v: LogoVariant) => {
    const svgEl = document.querySelector(`[data-logo-svg="${v}"]`)?.querySelector('svg');
    if (!svgEl) return;
    const clone = svgEl.cloneNode(true) as SVGElement;
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const markup = new XMLSerializer().serializeToString(clone);
    const blob = new Blob([markup], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clevia-logo-${v}.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center px-6 py-10 relative overflow-hidden">
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: 'radial-gradient(circle at 50% 20%, rgba(34,211,238,0.12) 0%, transparent 50%), radial-gradient(circle at 50% 80%, rgba(14,165,233,0.08) 0%, transparent 50%)'
      }} />

      <div className="relative z-10 w-full max-w-5xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition">
            <ArrowLeft className="w-5 h-5" /> Voltar
          </button>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-300 to-sky-500 bg-clip-text text-transparent">Escolha o Logo do CLEVIA</h1>
          <div className="w-20" />
        </div>

        <p className="text-center text-slate-400 mb-10 max-w-2xl mx-auto">
          Selecione o logo que será usado no app e ao instalar o CLEVIA no navegador (PWA). Cada opção tem um estilo único.
        </p>

        {/* Logo grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {(Object.keys(LOGO_VARIANTS) as LogoVariant[]).map((key) => {
            const v = LOGO_VARIANTS[key];
            const Comp = v.Comp;
            const isChosen = chosen === key;
            return (
              <div key={key}
                className={`relative group bg-slate-900/80 border-2 rounded-2xl p-6 transition-all cursor-pointer ${
                  isChosen ? 'border-cyan-500 shadow-lg shadow-cyan-500/20' : 'border-slate-800 hover:border-slate-600'
                }`}
                onClick={() => handleSelect(key)}
              >
                {isChosen && (
                  <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/40">
                    <Check className="w-5 h-5 text-slate-950" strokeWidth={3} />
                  </div>
                )}
                <div className="flex flex-col items-center gap-4">
                  <div className="w-32 h-32 flex items-center justify-center rounded-2xl bg-slate-950/50 border border-slate-800 overflow-hidden" data-logo-svg={key}>
                    <Comp size={110} />
                  </div>
                  <div className="text-center">
                    <h3 className="font-bold text-white text-lg">{v.name}</h3>
                    <p className="text-sm text-slate-400 mt-1">{v.desc}</p>
                  </div>
                  <div className="flex gap-2 w-full">
                    <button
                      onClick={(e) => { e.stopPropagation(); setPreview(key); }}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-slate-800 text-slate-300 text-sm font-medium hover:bg-slate-700 transition"
                    >
                      <Eye className="w-4 h-4" /> Ver
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDownload(key); }}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-slate-800 text-slate-300 text-sm font-medium hover:bg-slate-700 transition"
                    >
                      <Download className="w-4 h-4" /> SVG
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Preview area */}
        {preview && (
          <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setPreview(null)}>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
              <div className="flex flex-col items-center gap-6">
                {(() => {
                  const Comp = LOGO_VARIANTS[preview].Comp;
                  return <Comp size={200} />;
                })()}
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white">{LOGO_VARIANTS[preview].name}</h3>
                  <p className="text-slate-400 mt-1">{LOGO_VARIANTS[preview].desc}</p>
                </div>
                <div className="flex gap-3 w-full">
                  <button onClick={() => setPreview(null)} className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-medium hover:bg-slate-800 transition">Fechar</button>
                  <button onClick={() => { handleSelect(preview); setPreview(null); }} className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 text-slate-950 font-semibold hover:from-cyan-300 hover:to-sky-400 transition">Usar este</button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="mt-10 text-center">
          <p className="text-sm text-slate-500">
            Logo atual: <span className="text-cyan-400 font-semibold">{LOGO_VARIANTS[chosen].name}</span> · A escolha é salva automaticamente neste navegador.
          </p>
        </div>
      </div>
    </div>
  );
}

