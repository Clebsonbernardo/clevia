import { useState, useEffect, lazy, Suspense } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { registerServiceWorker } from '@/lib/push';
import { ThemeProvider } from '@/context/ThemeContext';
import LoginScreen from '@/screens/LoginScreen';
import ResetPasswordScreen from '@/screens/ResetPasswordScreen';
import LogoPickerScreen from '@/screens/LogoPickerScreen';
import LicenseBlockedScreen from '@/screens/LicenseBlockedScreen';
import AppLayout, { canAccessPage, type NavId } from '@/components/AppLayout';
import ErrorBoundary from '@/components/ErrorBoundary';

const Dashboard = lazy(() => import('@/screens/Dashboard'));
const WorkOrdersScreen = lazy(() => import('@/screens/WorkOrdersScreen'));
const MechanicsScreen = lazy(() => import('@/screens/MechanicsScreen'));
const PreventivesScreen = lazy(() => import('@/screens/PreventivesScreen'));
const IndicatorsScreen = lazy(() => import('@/screens/IndicatorsScreen'));
const CompaniesScreen = lazy(() => import('@/screens/CompaniesScreen'));
const UsersScreen = lazy(() => import('@/screens/UsersScreen'));
const InventoryScreen = lazy(() => import('@/screens/InventoryScreen'));
const SettingsScreen = lazy(() => import('@/screens/SettingsScreen'));
const OSHistoryScreen = lazy(() => import('@/screens/OSHistoryScreen'));
const MachineHistoryScreen = lazy(() => import('@/screens/MachineHistoryScreen'));
const MachinesScreen = lazy(() => import('@/screens/MachinesScreen'));
const AIAssistantScreen = lazy(() => import('@/screens/AIAssistantScreen'));
const MechanicLocationScreen = lazy(() => import('@/screens/MechanicLocationScreen'));
const ManageScreensScreen = lazy(() => import('@/screens/ManageScreensScreen'));
const PermissionsScreen = lazy(() => import('@/screens/PermissionsScreen'));
const SectorBoardScreen = lazy(() => import('@/screens/SectorBoardScreen'));
const TechDocScreen = lazy(() => import('@/screens/TechDocScreen'));
const FactoryMapScreen = lazy(() => import('@/screens/FactoryMapScreen'));
const ReportsScreen = lazy(() => import('@/screens/ReportsScreen'));
const AiPredictionsScreen = lazy(() => import('@/screens/AiPredictionsScreen'));
const AuditLogScreen = lazy(() => import('@/screens/AuditLogScreen'));
const IntegrationsScreen = lazy(() => import('@/screens/IntegrationsScreen'));
const ComplianceScreen = lazy(() => import('@/screens/ComplianceScreen'));
const LicensesScreen = lazy(() => import('@/screens/LicensesScreen'));
const ContractsScreen = lazy(() => import('@/screens/ContractsScreen'));
const FeatureGrantsScreen = lazy(() => import('@/screens/FeatureGrantsScreen'));

function PageLoader() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="w-8 h-8 border-4 border-slate-200 dark:border-slate-800 border-t-cyan-400 rounded-full animate-spin" />
    </div>
  );
}

function AppContent() {
  const { session, loading, activeCompany, activeRole, user, license, licenseLoading, companyLoading, planType, isAdmin, hasFeatureGrant } = useAuth();
  const [page, setPage] = useState<NavId>('dashboard');
  const [presetSector, setPresetSector] = useState<string | undefined>(undefined);
  const [showLogoPicker, setShowLogoPicker] = useState(false);
  const [isPasswordReset, setIsPasswordReset] = useState(false);

  const navigate = (id: string, opts?: { sector?: string }) => {
    if (opts?.sector !== undefined) {
      setPresetSector(opts.sector);
    } else {
      setPresetSector(undefined);
    }
    setPage(id as NavId);
  };

  useEffect(() => {
    registerServiceWorker();
  }, []);

  // Preload the Dashboard bundle while the login screen is visible so that
  // the moment the user signs in, the Dashboard is ready with zero chunk-download delay.
  useEffect(() => {
    if (!session) {
      void import('@/screens/Dashboard');
    }
  }, [session]);

  // Detecta link de recuperação de senha (token TYPE=recovery chega na hash)
  useEffect(() => {
    const checkRecovery = () => {
      const hash = window.location.hash;
      if (hash.includes('type=recovery') || hash.includes('type=signup') || hash.includes('access_token=')) {
        setIsPasswordReset(true);
      }
    };
    checkRecovery();
  }, []);

  useEffect(() => {
    const applyHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash && canAccessPage(hash as NavId, activeRole ?? 'mecanico', isAdmin, planType, hasFeatureGrant)) {
        setPage(hash as NavId);
        window.history.replaceState(null, '', window.location.pathname);
      }
    };
    applyHash();
    window.addEventListener('hashchange', applyHash);
    return () => window.removeEventListener('hashchange', applyHash);
  }, [activeRole, isAdmin, hasFeatureGrant]);

  useEffect(() => {
    if (!activeRole && !isAdmin) return;
    if (!canAccessPage(page, activeRole, isAdmin, planType, hasFeatureGrant)) {
      if (isAdmin) setPage('licenses');
      else if (activeRole === 'mecanico') setPage('workorders');
      else setPage('dashboard');
    }
  }, [activeRole, page, isAdmin, hasFeatureGrant]);

  if (loading || (session && companyLoading && !activeCompany && !isAdmin)) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center gap-4">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <svg viewBox="0 0 32 32" className="w-7 h-7 text-white" fill="none">
              <rect x="4" y="4" width="24" height="24" rx="6" stroke="currentColor" strokeWidth="2.5"/>
              <path d="M12 16h8M16 12v8" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
            </svg>
          </div>
          <span className="text-slate-800 dark:text-slate-200 font-semibold text-lg tracking-tight">CLEVIA</span>
          <span className="text-slate-400 dark:text-slate-500 text-xs">Carregando...</span>
        </div>
        <div className="w-8 h-8 border-4 border-slate-200 dark:border-slate-800 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  if (!session && isPasswordReset) return <ResetPasswordScreen />;

  if (!session) return <LoginScreen onOpenLogoPicker={() => setShowLogoPicker(true)} />;

  if (showLogoPicker && isAdmin) return <LogoPickerScreen onBack={() => setShowLogoPicker(false)} />;



  if (!activeCompany && !isAdmin) {
    return <LoginScreen />;
  }

  if (!isAdmin && !licenseLoading && license?.is_blocked) {
    return <LicenseBlockedScreen />;
  }

  return (
    <AppLayout active={page} onNavigate={setPage} onOpenLogoPicker={isAdmin ? () => setShowLogoPicker(true) : undefined}>
      <Suspense fallback={<PageLoader />}>
        {canAccessPage(page, activeRole, isAdmin, planType, hasFeatureGrant) && (
          <>
            {page === 'dashboard' && <Dashboard onNavigate={(id) => navigate(id)} />}
            {page === 'workorders' && <WorkOrdersScreen />}
            {page === 'oshistory' && <OSHistoryScreen />}
            {page === 'machinehistory' && <MachineHistoryScreen />}
            {page === 'machines' && <MachinesScreen presetSector={presetSector} />}
            {page === 'mechanics' && <MechanicsScreen />}
            {page === 'preventives' && <PreventivesScreen />}
            {page === 'indicators' && <IndicatorsScreen />}
            {page === 'aiassistant' && <AIAssistantScreen />}
            {page === 'companies' && <CompaniesScreen />}
            {page === 'users' && <UsersScreen />}
            {page === 'inventory' && <InventoryScreen />}
            {page === 'licenses' && <LicensesScreen />}
            {page === 'contracts' && <ContractsScreen />}
            {page === 'settings' && <SettingsScreen />}
            {page === 'mechaniclocation' && <MechanicLocationScreen />}
            {page === 'managescreens' && <ManageScreensScreen onNavigate={(id, opts) => navigate(id, opts)} />}
            {page === 'permissions' && <PermissionsScreen />}
            {page === 'sectorboard' && <SectorBoardScreen onNavigate={(id) => navigate(id)} />}
            {page === 'techdoc' && <TechDocScreen />}
            {page === 'factorymap' && <FactoryMapScreen />}
            {page === 'reports' && <ReportsScreen />}
            {page === 'aipredictions' && <AiPredictionsScreen />}
            {page === 'auditlog' && <AuditLogScreen />}
            {page === 'integrations' && <IntegrationsScreen />}
            {page === 'compliance' && <ComplianceScreen />}
            {page === 'featuregrants' && <FeatureGrantsScreen />}
          </>
        )}
      </Suspense>
    </AppLayout>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
