import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { ToastProvider } from '@/components/ui';
import { getChosenLogo, applyPwaIcon } from '@/components/CleviaLogo';
import './index.css';

applyPwaIcon(getChosenLogo());

// Seed history immediately (before React mounts) so the first browser-back
// on mobile is caught by our popstate handler instead of exiting the app.
if (!window.history.state || !('clevia' in (window.history.state as Record<string, unknown>))) {
  window.history.pushState({ clevia: 0 }, '', '');
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ToastProvider>
      <App />
    </ToastProvider>
  </StrictMode>
);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}
