import { useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';

type Point = { latitude: number; longitude: number; accuracy: number; at: number };

const distanceMeters = (a: Point, b: Point) => {
  const radius = 6_371_000;
  const toRad = (value: number) => value * Math.PI / 180;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return radius * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
};

/** Rastreia somente quando o mecânico ativa o acompanhamento do turno. */
export function useMechanicLocation(userId: string | undefined, companyId: string | undefined, role: string | null, trackingEnabled: boolean) {
  const watchId = useRef<number | null>(null);
  const lastPoint = useRef<Point | null>(null);
  const mechanicId = useRef<string | null>(null);
  const sending = useRef(false);
  const wakeLock = useRef<{ release: () => Promise<void>; released?: boolean } | null>(null);

  useEffect(() => {
    if (!userId || !companyId || role !== 'mecanico' || !trackingEnabled || !('geolocation' in navigator)) return;
    let stopped = false;

    const resolveMechanic = async () => {
      const { data } = await supabase.from('mechanics').select('id').eq('company_id', companyId).eq('user_id', userId).maybeSingle();
      mechanicId.current = data?.id ?? null;
    };

    const send = async (position: GeolocationPosition) => {
      if (stopped || sending.current) return;
      const point: Point = { latitude: position.coords.latitude, longitude: position.coords.longitude, accuracy: position.coords.accuracy, at: position.timestamp || Date.now() };
      if (!Number.isFinite(point.latitude) || !Number.isFinite(point.longitude) || point.accuracy > 100) return;
      const previous = lastPoint.current;
      const moved = previous ? distanceMeters(previous, point) : 999;
      const elapsed = previous ? point.at - previous.at : 999_999;
      if (previous && moved < 1.5 && elapsed < 12_000 && point.accuracy >= previous.accuracy) return;

      sending.current = true;
      const recordedAt = new Date().toISOString();
      const payload = {
        user_id: userId, company_id: companyId, mechanic_id: mechanicId.current,
        latitude: point.latitude, longitude: point.longitude, accuracy_meters: point.accuracy,
        heading: position.coords.heading ?? null, speed: position.coords.speed ?? (elapsed > 0 ? moved / (elapsed / 1000) : null),
        tracking_active: true, updated_at: recordedAt,
      };
      const { error } = await supabase.from('mechanic_locations').upsert(payload, { onConflict: 'user_id,company_id' });
      if (!error) {
        await supabase.from('mechanic_location_history').insert({ ...payload, recorded_at: recordedAt });
        lastPoint.current = point;
      }
      sending.current = false;
    };

    const onError = (error: GeolocationPositionError) => {
      window.dispatchEvent(new CustomEvent('clevia-location-error', { detail: error.message }));
    };

    const options: PositionOptions = { enableHighAccuracy: true, timeout: 20_000, maximumAge: 2_000 };
    const start = () => {
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
      navigator.geolocation.getCurrentPosition((position) => void send(position), onError, { ...options, maximumAge: 0 });
      watchId.current = navigator.geolocation.watchPosition((position) => void send(position), onError, options);
    };

    const requestWakeLock = async () => {
      try {
        if ('wakeLock' in navigator && document.visibilityState === 'visible') {
          wakeLock.current = await navigator.wakeLock.request('screen');
        }
      } catch { /* o rastreamento continua sem bloqueio de tela */ }
    };

    void resolveMechanic().then(start);
    void requestWakeLock();
    const fallback = window.setInterval(() => navigator.geolocation.getCurrentPosition((position) => void send(position), onError, options), 7_500);
    const onVisible = () => { if (document.visibilityState === 'visible') { start(); void requestWakeLock(); } };
    document.addEventListener('visibilitychange', onVisible);

    return () => {
      stopped = true;
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
      window.clearInterval(fallback);
      document.removeEventListener('visibilitychange', onVisible);
      void wakeLock.current?.release().catch(() => undefined);
      wakeLock.current = null;
      void supabase.from('mechanic_locations').update({ tracking_active: false, updated_at: new Date().toISOString() }).eq('company_id', companyId).eq('user_id', userId);
    };
  }, [userId, companyId, role, trackingEnabled]);
}
