import { printHTMLtoPDF } from './pdf';

const BRAND = '#0ea5e9';
const BRAND_DARK = '#0369a1';
const SLATE = '#1e293b';
const MUTED = '#64748b';
const BG_TINT = '#f0f9ff';
const CARD_BORDER = '#e2e8f0';

const CEO_ITEMS = [
  { icon: 'Dashboard', desc: 'Visão geral da operação: indicadores, OS abertas, máquinas críticas, gráficos e produção em tempo real.' },
  { icon: 'Ordens de Serviço', desc: 'Criar, atribuir, pausar, retomar e encerrar OS. Filtrar por status, prioridade, setor e mecânico.' },
  { icon: 'Máquinas', desc: 'Cadastrar e gerenciar todas as máquinas, setores e status de cada equipamento.' },
  { icon: 'Quadro de Setores', desc: 'Painel visual de setores com produção, paradas e status de cada linha.' },
  { icon: 'Mapa da Fábrica', desc: 'Mapa interativo com localização de máquinas e mecânicos no chão de fábrica.' },
  { icon: 'Histórico de OS', desc: 'Histórico completo de ordens de serviço encerradas, com filtros e exportação.' },
  { icon: 'Histórico de Máquinas', desc: 'Histórico de manutenção e eventos por máquina.' },
  { icon: 'Mecânicos', desc: 'Cadastrar e gerenciar mecânicos, ver produtividade e OS atribuídas.' },
  { icon: 'Localização de Mecânicos', desc: 'Rastreamento em tempo real da localização de cada mecânico.' },
  { icon: 'Gerenciar Telas', desc: 'Configurar monitores e telas de produção para exibição em setores.' },
  { icon: 'Permissões', desc: 'Controle granular: conceder ou revogar permissões individuais por usuário.' },
  { icon: 'Preventivas', desc: 'Criar e gerenciar planos de manutenção preventiva por máquina.' },
  { icon: 'Indicadores', desc: 'KPIs de manutenção: MTTR, MTBF, disponibilidade, taxa de conformidade.' },
  { icon: 'Relatórios', desc: 'Relatórios gerenciais com gráficos, exportáveis em PDF.' },
  { icon: 'IA Preditiva', desc: 'Previsões de falhas e recomendações baseadas em IA.' },
  { icon: 'Assistente IA', desc: 'Assistente inteligente para dúvidas técnicas e diagnósticos.' },
  { icon: 'Empresas', desc: 'Cadastrar empresas, filiais e gerenciar multi-tenant.' },
  { icon: 'Usuários', desc: 'Convidar membros, definir cargos e gerenciar acessos.' },
  { icon: 'Estoque', desc: 'Controle de peças, insumos, fornecedores e custos.' },
  { icon: 'Conformidade', desc: 'Checklists de conformidade ISO 55001 e NR-12.' },
  { icon: 'Auditoria', desc: 'Log de auditoria: todas as ações dos usuários registradas.' },
  { icon: 'Sistema & Personalização', desc: 'Escolher logo do sistema e acessar documentação (PDF/PPT). Exclusivo do CEO.' },
];

const MECHANIC_ITEMS = [
  { icon: 'Dashboard', desc: 'Visão geral: OS atribuídas a você, máquinas e avisos.' },
  { icon: 'Ordens de Serviço', desc: 'Ver OS atribuídas, aceitar, iniciar, pausar, retomar e encerrar. Registrar diagnóstico e peças usadas.' },
  { icon: 'Quadro de Setores', desc: 'Ver status dos setores e produção.' },
  { icon: 'Mapa da Fábrica', desc: 'Ver localização das máquinas no chão de fábrica.' },
  { icon: 'Histórico de OS', desc: 'Consultar OS anteriores para referência.' },
  { icon: 'Histórico de Máquinas', desc: 'Ver histórico de manutenção das máquinas.' },
  { icon: 'Mecânicos', desc: 'Ver colegas mecânicos e suas OS.' },
  { icon: 'Preventivas', desc: 'Executar preventivas atribuídas e registrar conclusão.' },
  { icon: 'Indicadores', desc: 'Ver seus indicadores de produtividade.' },
  { icon: 'Conformidade', desc: 'Preencher checklists de conformidade.' },
];

function card(item: { icon: string; desc: string }, accent: string): string {
  return `<div style="display:flex;gap:12px;padding:14px 16px;border:1px solid ${CARD_BORDER};border-radius:10px;background:#fff;page-break-inside:avoid;">
    <div style="flex-shrink:0;width:36px;height:36px;border-radius:8px;background:${accent};display:flex;align-items:center;justify-content:center;">
      <span style="color:#fff;font-size:18px;font-weight:bold;">${item.icon.charAt(0)}</span>
    </div>
    <div>
      <div style="font-weight:700;font-size:13px;color:${SLATE};margin-bottom:2px;">${item.icon}</div>
      <div style="font-size:12px;color:${MUTED};line-height:1.5;">${item.desc}</div>
    </div>
  </div>`;
}

function section(title: string, subtitle: string, items: { icon: string; desc: string }[], accent: string): string {
  return `<div style="margin-bottom:36px;">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
      <div style="width:6px;height:28px;border-radius:3px;background:${accent};"></div>
      <div>
        <h2 style="font-size:20px;font-weight:800;color:${SLATE};margin:0;">${title}</h2>
        <p style="font-size:13px;color:${MUTED};margin:2px 0 0 0;">${subtitle}</p>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px;">
      ${items.map((i) => card(i, accent)).join('')}
    </div>
  </div>`;
}

export function generateOnboardingPDF(companyName: string = 'Nova Empresa') {
  const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Guia de Implantação CLEVIA — ${companyName}</title>
<style>
  @page { margin: 18mm 16mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; margin: 0; color: ${SLATE}; line-height: 1.6; }
  .cover { text-align:center; padding:60px 40px 40px; background:linear-gradient(135deg, ${BG_TINT}, #fff); border-radius:16px; margin-bottom:32px; }
  .cover-badge { display:inline-block; padding:6px 18px; border-radius:999px; background:${BRAND}; color:#fff; font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-bottom:20px; }
  .cover h1 { font-size:34px; font-weight:900; color:${SLATE}; margin:0 0 8px; letter-spacing:2px; }
  .cover h2 { font-size:16px; font-weight:600; color:${BRAND_DARK}; margin:0 0 24px; }
  .cover-meta { display:flex; justify-content:center; gap:40px; margin-top:28px; }
  .cover-meta div { text-align:center; }
  .cover-meta .label { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:${MUTED}; }
  .cover-meta .value { font-size:14px; font-weight:700; color:${SLATE}; margin-top:2px; }
  .intro { padding:0 4px; margin-bottom:32px; }
  .intro p { font-size:14px; color:${MUTED}; line-height:1.8; }
  .roles { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:32px; }
  .role-card { border:1px solid ${CARD_BORDER}; border-radius:12px; padding:20px; }
  .role-card.ceo { border-top:4px solid ${BRAND}; }
  .role-card.mec { border-top:4px solid #f59e0b; }
  .role-card h3 { font-size:16px; font-weight:800; margin:0 0 4px; }
  .role-card p { font-size:12px; color:${MUTED}; margin:0 0 12px; }
  .role-tag { display:inline-block; padding:3px 10px; border-radius:6px; font-size:11px; font-weight:600; }
  .role-tag.ceo { background:${BG_TINT}; color:${BRAND_DARK}; }
  .role-tag.mec { background:#fffbeb; color:#92400e; }
  .footer { margin-top:40px; padding-top:16px; border-top:1px solid ${CARD_BORDER}; text-align:center; font-size:11px; color:${MUTED}; }
  .note { background:${BG_TINT}; border-left:4px solid ${BRAND}; border-radius:0 8px 8px 0; padding:14px 18px; margin:24px 0; font-size:13px; color:${SLATE}; }
  .note strong { color:${BRAND_DARK}; }
  h2 { page-break-after: avoid; }
</style>
</head>
<body>

<div class="cover">
  <div class="cover-badge">Guia de Implantação</div>
  <h1>CLEVIA</h1>
  <h2>Plataforma Inteligente de Gestão Industrial e Manutenção</h2>
  <p style="font-size:14px;color:${MUTED};max-width:480px;margin:0 auto;">Guia de boas-vindas para novos clientes — o que cada perfil enxerga ao entrar no sistema.</p>
  <div class="cover-meta">
    <div><div class="label">Cliente</div><div class="value">${companyName}</div></div>
    <div><div class="label">Data</div><div class="value">${today}</div></div>
    <div><div class="label">Versão</div><div class="value">Cloud 2.0</div></div>
  </div>
</div>

<div class="intro">
  <p>Bem-vindo ao CLEVIA. Este guia mostra exatamente o que aparece para o <strong>CEO da empresa</strong> e para os <strong>Mecânicos</strong> ao acessarem o sistema pela primeira vez. Cada perfil tem um conjunto de telas e permissões ajustado à sua função, garantindo que cada pessoa veja apenas o que precisa para trabalhar com eficiência.</p>
</div>

<div class="roles">
  <div class="role-card ceo">
    <span class="role-tag ceo">Perfil Completo</span>
    <h3 style="color:${BRAND_DARK};">CEO da Empresa</h3>
    <p>Acesso total ao sistema: gestão, configuração, relatórios, IA e personalização.</p>
    <p style="font-weight:600;color:${SLATE};">${CEO_ITEMS.length} telas disponíveis</p>
  </div>
  <div class="role-card mec">
    <span class="role-tag mec">Perfil Operacional</span>
    <h3 style="color:#92400e;">Mecânico</h3>
    <p>Foco em execução: ver e executar OS, preventivas e checklists de conformidade.</p>
    <p style="font-weight:600;color:${SLATE};">${MECHANIC_ITEMS.length} telas disponíveis</p>
  </div>
</div>

${section('CEO da Empresa', 'Tudo o que o CEO vê na barra lateral ao entrar no sistema', CEO_ITEMS, BRAND)}

<div class="note">
  <strong>Exclusivo do CEO:</strong> O ícone "Sistema & Personalização" na barra lateral permite trocar o logo do sistema e acessar a documentação completa em PDF/PPT. Nenhum outro perfil tem acesso a essas opções.
</div>

${section('Mecânico', 'Tudo o que o mecânico vê na barra lateral ao entrar no sistema', MECHANIC_ITEMS, '#f59e0b')}

<div class="note">
  <strong>Notificações para Mecânicos:</strong> Quando uma nova OS é atribuída, o mecânico recebe notificação com som e vibração no celular. O sistema reenvia lembretes a cada minuto até a OS ser aceita.
</div>

<div class="footer">
  CLEVIA Cloud 2.0 — Plataforma Inteligente de Gestão Industrial e Manutenção<br/>
  Documento gerado em ${today} para ${companyName}
</div>

</body>
</html>`;

  printHTMLtoPDF(html, `Guia-Implantacao-CLEVIA-${companyName.replace(/\s+/g, '-')}`);
}
