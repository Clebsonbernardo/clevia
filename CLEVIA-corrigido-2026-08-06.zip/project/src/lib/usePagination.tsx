import { useState, useMemo, useEffect } from 'react';

const DEFAULT_PAGE_SIZE = 24;

type UsePaginationOptions = {
  pageSize?: number;
};

export function usePagination<T>(items: T[], options: UsePaginationOptions = {}) {
  const pageSize = options.pageSize ?? DEFAULT_PAGE_SIZE;
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));

  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(1);
  }, [totalPages, currentPage]);

  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return items.slice(start, start + pageSize);
  }, [items, currentPage, pageSize]);

  const hasNext = currentPage < totalPages;
  const hasPrev = currentPage > 1;

  return {
    paginatedItems,
    currentPage,
    totalPages,
    pageSize,
    hasNext,
    hasPrev,
    nextPage: () => setCurrentPage((p) => Math.min(p + 1, totalPages)),
    prevPage: () => setCurrentPage((p) => Math.max(p - 1, 1)),
    goToPage: (page: number) => setCurrentPage(Math.min(Math.max(page, 1), totalPages)),
  };
}

type PaginationControlsProps = {
  currentPage: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
  nextPage: () => void;
  prevPage: () => void;
  totalItems: number;
  pageSize: number;
};

export function PaginationControls({
  currentPage, totalPages, hasNext, hasPrev, nextPage, prevPage, totalItems, pageSize,
}: PaginationControlsProps) {
  if (totalItems <= pageSize) return null;

  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(currentPage * pageSize, totalItems);

  return (
    <div className="flex items-center justify-between gap-3 py-4">
      <p className="text-sm text-slate-500 dark:text-slate-400">
        Mostrando {start}–{end} de {totalItems}
      </p>
      <div className="flex items-center gap-2">
        <button
          onClick={prevPage}
          disabled={!hasPrev}
          className="px-3 py-1.5 rounded-lg text-sm font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-cyan-400 transition disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Anterior
        </button>
        <span className="text-sm text-slate-500 dark:text-slate-400 min-w-[60px] text-center">
          {currentPage} / {totalPages}
        </span>
        <button
          onClick={nextPage}
          disabled={!hasNext}
          className="px-3 py-1.5 rounded-lg text-sm font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-cyan-400 transition disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Próximo
        </button>
      </div>
    </div>
  );
}
