// Offline support for CLEVIA.
// Caches data in localStorage and queues actions to sync when online.

const WO_CACHE_KEY = 'clevia:wo_cache';
const QUEUE_KEY = 'clevia:wo_pending_finishes';
const APP_CACHE_KEY = 'clevia:app_cache';
const COMPANY_CACHE_KEY = 'clevia:company_cache';

export type PendingFinish = {
  id: string;
  work_order_id: string;
  company_id: string;
  defect: string;
  procedure: string;
  replaced_part: string;
  finished_at: string;
  actor_name: string;
  mechanic_id?: string | null;
};

type WOCache = {
  orders: unknown[];
  machines: unknown[];
  mechanics: unknown[];
  branches: unknown[];
  company_id: string;
  cached_at: string;
};

type AppCache = {
  machines: unknown[];
  inventory: unknown[];
  preventives: unknown[];
  dashboard: unknown;
  indicators: unknown;
  company_id: string;
  cached_at: string;
};

export function isOnline(): boolean {
  return typeof navigator !== 'undefined' ? navigator.onLine : true;
}

// ─── Work order cache ───

export function cacheWorkData(data: {
  orders: unknown[];
  machines: unknown[];
  mechanics: unknown[];
  branches: unknown[];
}, companyId: string) {
  try {
    const payload: WOCache = { ...data, company_id: companyId, cached_at: new Date().toISOString() } as WOCache;
    localStorage.setItem(WO_CACHE_KEY, JSON.stringify(payload));
  } catch {
    // storage full or unavailable — non-critical
  }
}

export function getCachedWorkData(companyId: string): WOCache | null {
  try {
    const raw = localStorage.getItem(WO_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as WOCache;
    if (parsed.company_id !== companyId) return null;
    return parsed;
  } catch {
    return null;
  }
}

// ─── App-wide cache (machines, inventory, preventives, dashboard) ───

export function cacheAppData(data: {
  machines?: unknown[];
  inventory?: unknown[];
  preventives?: unknown[];
  dashboard?: unknown;
  indicators?: unknown;
}, companyId: string) {
  try {
    const existing = getAppCache(companyId);
    const payload: AppCache = {
      machines: data.machines ?? existing?.machines ?? [],
      inventory: data.inventory ?? existing?.inventory ?? [],
      preventives: data.preventives ?? existing?.preventives ?? [],
      dashboard: data.dashboard ?? existing?.dashboard ?? null,
      indicators: data.indicators ?? existing?.indicators ?? null,
      company_id: companyId,
      cached_at: new Date().toISOString(),
    };
    localStorage.setItem(APP_CACHE_KEY, JSON.stringify(payload));
  } catch {
    // non-critical
  }
}

export function getAppCache(companyId: string): AppCache | null {
  try {
    const raw = localStorage.getItem(APP_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AppCache;
    if (parsed.company_id !== companyId) return null;
    return parsed;
  } catch {
    return null;
  }
}

// ─── Company cache (for offline app startup) ───

export function cacheCompanyData(company: unknown, members: unknown[], isAdmin: boolean) {
  try {
    localStorage.setItem(COMPANY_CACHE_KEY, JSON.stringify({
      company,
      members,
      is_admin: isAdmin,
      cached_at: new Date().toISOString(),
    }));
  } catch {
    // non-critical
  }
}

export function getCachedCompanyData(): { company: unknown; members: unknown[]; is_admin: boolean } | null {
  try {
    const raw = localStorage.getItem(COMPANY_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return { company: parsed.company, members: parsed.members ?? [], is_admin: parsed.is_admin ?? false };
  } catch {
    return null;
  }
}

// ─── Pending finish queue ───

export function queuePendingFinish(finish: PendingFinish) {
  try {
    const queue = getPendingFinishes();
    // remove any existing pending finish for the same work order
    const filtered = queue.filter((f) => f.work_order_id !== finish.work_order_id);
    filtered.push(finish);
    localStorage.setItem(QUEUE_KEY, JSON.stringify(filtered));
  } catch {
    // non-critical
  }
}

export function getPendingFinishes(): PendingFinish[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as PendingFinish[];
  } catch {
    return [];
  }
}

export function removePendingFinish(id: string) {
  try {
    const queue = getPendingFinishes().filter((f) => f.id !== id);
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch {
    // non-critical
  }
}
