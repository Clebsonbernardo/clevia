import { describe, it, expect } from 'vitest';
import { safeUrl } from '@/lib/safeUrl';

describe('safeUrl', () => {
  it('accepts http URLs', () => {
    expect(safeUrl('http://example.com')).toBe('http://example.com/');
  });

  it('accepts https URLs', () => {
    expect(safeUrl('https://example.com/path?q=1')).toBe('https://example.com/path?q=1');
  });

  it('rejects javascript: URLs', () => {
    expect(safeUrl('javascript:alert(1)')).toBeUndefined();
  });

  it('rejects data: URLs', () => {
    expect(safeUrl('data:text/html,<script>alert(1)</script>')).toBeUndefined();
  });

  it('rejects vbscript: URLs', () => {
    expect(safeUrl('vbscript:msgbox(1)')).toBeUndefined();
  });

  it('rejects file: URLs', () => {
    expect(safeUrl('file:///etc/passwd')).toBeUndefined();
  });

  it('rejects non-string values', () => {
    expect(safeUrl(null)).toBeUndefined();
    expect(safeUrl(undefined)).toBeUndefined();
    expect(safeUrl(123)).toBeUndefined();
    expect(safeUrl({})).toBeUndefined();
  });

  it('rejects empty strings', () => {
    expect(safeUrl('')).toBeUndefined();
    expect(safeUrl('   ')).toBeUndefined();
  });

  it('treats relative URLs as http when origin is https', () => {
    const result = safeUrl('/path/to/page');
    expect(result).toMatch(/^https?:\/\//);
  });
});
