import { describe, it, expect } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { usePagination } from '@/lib/usePagination';

describe('usePagination', () => {
  it('returns all items when under page size', () => {
    const items = [1, 2, 3];
    const { result } = renderHook(() => usePagination(items, { pageSize: 24 }));
    expect(result.current.paginatedItems).toEqual([1, 2, 3]);
    expect(result.current.currentPage).toBe(1);
    expect(result.current.totalPages).toBe(1);
    expect(result.current.hasNext).toBe(false);
    expect(result.current.hasPrev).toBe(false);
  });

  it('splits items across pages', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items, { pageSize: 10 }));
    expect(result.current.totalPages).toBe(5);
    expect(result.current.paginatedItems).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    expect(result.current.hasNext).toBe(true);
  });

  it('navigates to next page', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items, { pageSize: 10 }));
    act(() => result.current.nextPage());
    expect(result.current.currentPage).toBe(2);
    expect(result.current.paginatedItems).toEqual([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]);
  });

  it('navigates to prev page', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items, { pageSize: 10 }));
    act(() => result.current.nextPage());
    act(() => result.current.prevPage());
    expect(result.current.currentPage).toBe(1);
  });

  it('does not go below page 1', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items, { pageSize: 10 }));
    act(() => result.current.prevPage());
    expect(result.current.currentPage).toBe(1);
  });

  it('does not go above last page', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items, { pageSize: 10 }));
    act(() => result.current.goToPage(5));
    act(() => result.current.nextPage());
    expect(result.current.currentPage).toBe(5);
  });

  it('goToPage clamps to valid range', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items, { pageSize: 10 }));
    act(() => result.current.goToPage(0));
    expect(result.current.currentPage).toBe(1);
    act(() => result.current.goToPage(999));
    expect(result.current.currentPage).toBe(5);
  });

  it('resets to page 1 when items shrink below current page', () => {
    const items = Array.from({ length: 50 }, (_, i) => i + 1);
    const { result, rerender } = renderHook(({ data }) => usePagination(data, { pageSize: 10 }), {
      initialProps: { data: items },
    });
    act(() => result.current.goToPage(3));
    expect(result.current.currentPage).toBe(3);
    rerender({ data: [1, 2, 3] });
    expect(result.current.currentPage).toBe(1);
  });

  it('uses default page size of 24', () => {
    const items = Array.from({ length: 25 }, (_, i) => i + 1);
    const { result } = renderHook(() => usePagination(items));
    expect(result.current.pageSize).toBe(24);
    expect(result.current.totalPages).toBe(2);
    expect(result.current.paginatedItems.length).toBe(24);
  });

  it('handles empty array', () => {
    const { result } = renderHook(() => usePagination([]));
    expect(result.current.paginatedItems).toEqual([]);
    expect(result.current.totalPages).toBe(1);
    expect(result.current.currentPage).toBe(1);
  });
});
