import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { printHTMLtoPDF, printElementToPDF } from '@/lib/pdf';

describe('printHTMLtoPDF', () => {
  let iframe: HTMLIFrameElement | null;
  let originalCreateElement: typeof document.createElement;

  beforeEach(() => {
    iframe = null;
    originalCreateElement = document.createElement;
    vi.spyOn(document.body, 'appendChild').mockImplementation((node) => {
      if (node instanceof HTMLIFrameElement) iframe = node;
      return node;
    });
    vi.spyOn(document.body, 'removeChild').mockImplementation((node) => node);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('creates an iframe and writes content', () => {
    const doc = { open: vi.fn(), write: vi.fn(), close: vi.fn() };
    vi.spyOn(document, 'createElement').mockReturnValue({
      style: {},
      contentWindow: { document: doc, focus: vi.fn(), print: vi.fn() },
      onload: null,
    } as any);

    printHTMLtoPDF('<h1>Test</h1>', 'test');

    expect(doc.open).toHaveBeenCalled();
    expect(doc.write).toHaveBeenCalledWith('<h1>Test</h1>');
    expect(doc.close).toHaveBeenCalled();
  });

  it('handles missing contentWindow gracefully', () => {
    vi.spyOn(document, 'createElement').mockReturnValue({
      style: {},
      contentWindow: null,
      onload: null,
    } as any);

    expect(() => printHTMLtoPDF('<h1>Test</h1>', 'test')).not.toThrow();
  });
});

describe('printElementToPDF', () => {
  it('does nothing when element does not exist', () => {
    expect(() => printElementToPDF('nonexistent', 'test')).not.toThrow();
  });
});
