import { describe, it, expect } from 'vitest';
import {
  PRIORITY_RANK,
  PRIORITY_LABELS,
  PRIORITY_STYLES,
  machineEffectivePriority,
  machinesByPriority,
  priorityCounts,
  type OSPriority,
} from '@/lib/priority';
import type { Machine, WorkOrder } from '@/lib/supabase';

describe('priority constants', () => {
  it('ranks critica as highest priority', () => {
    expect(PRIORITY_RANK.critica).toBe(0);
    expect(PRIORITY_RANK.alta).toBe(1);
    expect(PRIORITY_RANK.media).toBe(2);
    expect(PRIORITY_RANK.baixa).toBe(3);
  });

  it('provides labels for all priorities', () => {
    expect(PRIORITY_LABELS.critica).toBe('Crítica');
    expect(PRIORITY_LABELS.alta).toBe('Alta');
    expect(PRIORITY_LABELS.media).toBe('Média');
    expect(PRIORITY_LABELS.baixa).toBe('Baixa');
  });

  it('provides styles for all priorities', () => {
    (['critica', 'alta', 'media', 'baixa'] as OSPriority[]).forEach((key) => {
      expect(PRIORITY_STYLES[key]).toBeDefined();
      expect(PRIORITY_STYLES[key].hex).toMatch(/^#[0-9a-f]{6}$/);
    });
  });
});

describe('machineEffectivePriority', () => {
  const machineId = 'm1';

  it('returns null when machineId is null', () => {
    expect(machineEffectivePriority(null, [])).toBeNull();
  });

  it('returns null when no work orders exist', () => {
    expect(machineEffectivePriority(machineId, [])).toBeNull();
  });

  it('returns null when all work orders are closed', () => {
    const wos: WorkOrder[] = [
      { id: 'w1', machine_id: machineId, status: 'concluida', priority: 'critica' } as WorkOrder,
      { id: 'w2', machine_id: machineId, status: 'cancelada', priority: 'alta' } as WorkOrder,
    ];
    expect(machineEffectivePriority(machineId, wos)).toBeNull();
  });

  it('returns the highest priority among open work orders', () => {
    const wos: WorkOrder[] = [
      { id: 'w1', machine_id: machineId, status: 'aberta', priority: 'baixa' } as WorkOrder,
      { id: 'w2', machine_id: machineId, status: 'em_andamento', priority: 'critica' } as WorkOrder,
      { id: 'w3', machine_id: machineId, status: 'pausada', priority: 'media' } as WorkOrder,
    ];
    expect(machineEffectivePriority(machineId, wos)).toBe('critica');
  });

  it('ignores work orders for other machines', () => {
    const wos: WorkOrder[] = [
      { id: 'w1', machine_id: 'other', status: 'aberta', priority: 'critica' } as WorkOrder,
      { id: 'w2', machine_id: machineId, status: 'aberta', priority: 'baixa' } as WorkOrder,
    ];
    expect(machineEffectivePriority(machineId, wos)).toBe('baixa');
  });

  it('includes aguardando_pecas as an open status', () => {
    const wos: WorkOrder[] = [
      { id: 'w1', machine_id: machineId, status: 'aguardando_pecas', priority: 'alta' } as WorkOrder,
    ];
    expect(machineEffectivePriority(machineId, wos)).toBe('alta');
  });
});

describe('machinesByPriority', () => {
  const machines: Machine[] = [
    { id: 'm1', name: 'Machine 1' } as Machine,
    { id: 'm2', name: 'Machine 2' } as Machine,
    { id: 'm3', name: 'Machine 3' } as Machine,
  ];

  it('groups machines by their effective priority', () => {
    const wos: WorkOrder[] = [
      { id: 'w1', machine_id: 'm1', status: 'aberta', priority: 'critica' } as WorkOrder,
      { id: 'w2', machine_id: 'm2', status: 'em_andamento', priority: 'media' } as WorkOrder,
    ];
    const result = machinesByPriority(machines, wos);
    expect(result.critica).toHaveLength(1);
    expect(result.critica[0].id).toBe('m1');
    expect(result.media).toHaveLength(1);
    expect(result.media[0].id).toBe('m2');
    expect(result.baixa).toHaveLength(0);
    expect(result.alta).toHaveLength(0);
  });

  it('excludes machines with no open work orders', () => {
    const wos: WorkOrder[] = [];
    const result = machinesByPriority(machines, wos);
    expect(result.critica).toHaveLength(0);
    expect(result.alta).toHaveLength(0);
    expect(result.media).toHaveLength(0);
    expect(result.baixa).toHaveLength(0);
  });
});

describe('priorityCounts', () => {
  it('counts machines per priority bucket', () => {
    const machines: Machine[] = [
      { id: 'm1' } as Machine,
      { id: 'm2' } as Machine,
      { id: 'm3' } as Machine,
    ];
    const wos: WorkOrder[] = [
      { id: 'w1', machine_id: 'm1', status: 'aberta', priority: 'critica' } as WorkOrder,
      { id: 'w2', machine_id: 'm2', status: 'aberta', priority: 'critica' } as WorkOrder,
      { id: 'w3', machine_id: 'm3', status: 'aberta', priority: 'baixa' } as WorkOrder,
    ];
    const counts = priorityCounts(machines, wos);
    expect(counts.critica).toBe(2);
    expect(counts.baixa).toBe(1);
    expect(counts.alta).toBe(0);
    expect(counts.media).toBe(0);
  });
});
