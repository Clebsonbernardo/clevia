/**
 * Generates a true PDF from HTML content using the browser's built-in print engine.
 * Opens a hidden iframe, writes the HTML, triggers print, and the user selects "Save as PDF".
 * This produces a real PDF file (not an HTML file).
 */
export function printHTMLtoPDF(html: string, filename: string) {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) {
    document.body.removeChild(iframe);
    return;
  }

  doc.open();
  doc.write(html);
  doc.close();

  iframe.onload = () => {
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 1000);
    }, 250);
  };

  // Fallback: if onload doesn't fire (some browsers), print after a delay
  setTimeout(() => {
    if (iframe.contentWindow && document.body.contains(iframe)) {
      try {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
      } catch {
        // already printing or removed
      }
      setTimeout(() => {
        if (document.body.contains(iframe)) document.body.removeChild(iframe);
      }, 1000);
    }
  }, 1000);
}

/**
 * Prints a DOM element by its ID as a PDF.
 */
export function printElementToPDF(elementId: string, title: string) {
  const element = document.getElementById(elementId);
  if (!element) return;

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${title}</title>
  <style>
    body { font-family: Georgia, serif; margin: 40px; color: #1e293b; line-height: 1.8; }
    @media print { body { margin: 20px; } }
  </style></head><body>${element.innerHTML}</body></html>`;

  printHTMLtoPDF(html, title);
}
