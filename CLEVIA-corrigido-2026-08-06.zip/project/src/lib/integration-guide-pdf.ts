import { printHTMLtoPDF } from './pdf';

const BRAND = '#0ea5e9';
const BRAND_DARK = '#0369a1';
const SLATE = '#1e293b';
const MUTED = '#64748b';
const BG_TINT = '#f0f9ff';
const CARD_BORDER = '#e2e8f0';
const AMBER = '#f59e0b';
const AMBER_DARK = '#92400e';
const EMERALD = '#10b981';
const EMERALD_DARK = '#047857';
const ROSE = '#f43f5e';
const ROSE_DARK = '#be123c';
const VIOLET = '#8b5cf6';
const VIOLET_DARK = '#6d28d9';

function stepCard(num: number, title: string, body: string, accent: string): string {
  return `<div style="display:flex;gap:14px;padding:16px 18px;border:1px solid ${CARD_BORDER};border-radius:10px;background:#fff;page-break-inside:avoid;margin-bottom:10px;">
    <div style="flex-shrink:0;width:32px;height:32px;border-radius:50%;background:${accent};display:flex;align-items:center;justify-content:center;">
      <span style="color:#fff;font-size:14px;font-weight:800;">${num}</span>
    </div>
    <div>
      <div style="font-weight:700;font-size:14px;color:${SLATE};margin-bottom:4px;">${title}</div>
      <div style="font-size:12px;color:${MUTED};line-height:1.6;">${body}</div>
    </div>
  </div>`;
}

function infoBox(title: string, body: string, accent: string, bg: string): string {
  return `<div style="background:${bg};border-left:4px solid ${accent};border-radius:0 8px 8px 0;padding:14px 18px;margin:16px 0;">
    <div style="font-weight:700;font-size:13px;color:${SLATE};margin-bottom:4px;">${title}</div>
    <div style="font-size:12px;color:${MUTED};line-height:1.6;">${body}</div>
  </div>`;
}

function codeBlock(label: string, code: string): string {
  return `<div style="margin:12px 0;">
    <div style="font-size:11px;font-weight:700;color:${MUTED};text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">${label}</div>
    <pre style="background:#0f172a;color:#e2e8f0;border-radius:10px;padding:16px;font-size:11px;line-height:1.6;overflow-x:auto;margin:0;font-family:'Courier New',monospace;white-space:pre-wrap;">${code}</pre>
  </div>`;
}

function tableRow(cells: string[], isHeader = false): string {
  const bg = isHeader ? BRAND : '#fff';
  const color = isHeader ? '#fff' : SLATE;
  const fontWeight = isHeader ? '700' : '400';
  return `<tr>${cells.map((c) => `<td style="padding:10px 14px;border:1px solid ${CARD_BORDER};font-size:12px;color:${isHeader ? color : SLATE};font-weight:${fontWeight};background:${isHeader ? bg : '#fff'};">${c}</td>`).join('')}</tr>`;
}

function table(headers: string[], rows: string[][]): string {
  return `<table style="width:100%;border-collapse:collapse;margin:12px 0;">
    <thead>${tableRow(headers, true)}</thead>
    <tbody>${rows.map((r) => tableRow(r)).join('')}</tbody>
  </table>`;
}

export function generateIntegrationGuidePDF(companyName: string = 'Nova Empresa') {
  const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Guia de Integração CLEVIA — ${companyName}</title>
<style>
  @page { margin: 16mm 14mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI','Helvetica Neue',Arial,sans-serif; margin:0; color:${SLATE}; line-height:1.6; }
  .cover { text-align:center; padding:50px 36px 36px; background:linear-gradient(135deg,${BG_TINT},#fff); border-radius:16px; margin-bottom:30px; }
  .cover-badge { display:inline-block; padding:6px 18px; border-radius:999px; background:${BRAND}; color:#fff; font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-bottom:18px; }
  .cover h1 { font-size:32px; font-weight:900; color:${SLATE}; margin:0 0 6px; letter-spacing:2px; }
  .cover h2 { font-size:15px; font-weight:600; color:${BRAND_DARK}; margin:0 0 20px; }
  .cover-meta { display:flex; justify-content:center; gap:36px; margin-top:24px; }
  .cover-meta .label { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:${MUTED}; }
  .cover-meta .value { font-size:13px; font-weight:700; color:${SLATE}; margin-top:2px; }
  h2.section { font-size:20px; font-weight:800; color:${SLATE}; margin:28px 0 14px; padding-bottom:8px; border-bottom:2px solid ${BRAND}; page-break-after:avoid; }
  h2.section .num { display:inline-block; width:28px; height:28px; border-radius:6px; background:${BRAND}; color:#fff; font-size:14px; text-align:center; line-height:28px; margin-right:10px; }
  h3.sub { font-size:16px; font-weight:700; color:${BRAND_DARK}; margin:20px 0 10px; page-break-after:avoid; }
  p.intro { font-size:13px; color:${MUTED}; line-height:1.8; margin-bottom:20px; }
  .footer { margin-top:36px; padding-top:14px; border-top:1px solid ${CARD_BORDER}; text-align:center; font-size:11px; color:${MUTED}; }
  .two-col { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .compare-card { border:1px solid ${CARD_BORDER}; border-radius:10px; padding:16px; }
  .compare-card h4 { font-size:14px; font-weight:800; margin:0 0 8px; }
  .compare-card ul { margin:0; padding-left:16px; }
  .compare-card li { font-size:12px; color:${MUTED}; line-height:1.7; }
</style>
</head>
<body>

<div class="cover">
  <div class="cover-badge">Guia de Integração — Passo a Passo</div>
  <h1>CLEVIA</h1>
  <h2>Integração com Sistemas ERP Externos</h2>
  <p style="font-size:13px;color:${MUTED};max-width:520px;margin:0 auto;">Guia completo de configuração para integrar o CLEVIA com sistemas ERP externos, com exemplo prático de configuração para o ERP da TOTVS.</p>
  <div class="cover-meta">
    <div><div class="label">Cliente</div><div class="value">${companyName}</div></div>
    <div><div class="label">Data</div><div class="value">${today}</div></div>
    <div><div class="label">Versão</div><div class="value">Cloud 2.0</div></div>
  </div>
</div>

<p class="intro">Este documento descreve o processo completo de configuração de integração entre o CLEVIA e sistemas ERP externos. A integração permite sincronizar dados de estoque, ordens de serviço, fornecedores e outras informações entre o CLEVIA e o ERP da empresa, eliminando a digitacao manual e mantendo os dados sempre atualizados em ambos os sistemas.</p>

<h2 class="section"><span class="num">1</span>Visão Geral da Integração</h2>

<p class="intro">O CLEVIA possui um módulo de integração nativo que se comunica com sistemas externos via API REST (HTTPS). A integracao funciona no modelo "pull": o CLEVIA busca os dados do ERP em intervalos definidos ou sob demanda, e grava as informacoes no banco de dados do CLEVIA. As credenciais de acesso ao ERP ficam armazenadas de forma segura e nunca sao enviadas ao navegador.</p>

${table(
  ['Tipo de Integração', 'Sistemas Compatíveis', 'O que Sincroniza'],
  [
    ['SAP', 'SAP ERP / S4HANA', 'Ordens de produção, notificações de manutenção, equipamentos'],
    ['ERP Genérico', 'TOTVS, Oracle, Omie, Sankhya, qualquer ERP com API REST', 'Estoque, ordens de serviço, fornecedores'],
    ['IoT — OPC UA', 'Servidores OPC UA industriais', 'Tags de produção em tempo real'],
    ['IoT — Modbus TCP', 'Dispositivos Modbus TCP', 'Registradores de produção'],
    ['Active Directory', 'Microsoft AD / Entra ID', 'Usuários e departamentos'],
  ]
)}

${infoBox('Como funciona tecnicamente',
  'O CLEVIA envia uma requisicao HTTPS (GET ou POST) para o endpoint (URL) do ERP externo, autenticando com API Key (token) ou usuario/senha. O ERP responde com os dados em formato JSON. O CLEVIA le esses dados e grava no banco de dados interno (estoque, ordens de serviço, etc). Todo o processo e executado no servidor do CLEVIA (Edge Function), nunca no navegador do usuario. As credenciais ficam armazenadas de forma criptografada no banco de dados.',
  BRAND, BG_TINT
)}

<h2 class="section"><span class="num">2</span>Requisitos para Integração</h2>

${stepCard(1, 'ERP com API REST disponível',
  'O ERP da empresa precisa ter uma API REST acessível por HTTPS. Quase todos os ERPs modernos possuem: TOTVS Protheus (API REST nativa), TOTVS CARLOS (API REST), Oracle NetSuite (SuiteTalk REST), Omie API, Sankhya, etc. Se o ERP nao tem API REST nativa, e possivel usar um middleware (como um servidor intermediario) que faz a ponte entre o ERP e o CLEVIA.',
  BRAND)}

${stepCard(2, 'URL de acesso à API',
  'Voce precisa da URL base da API do ERP. Por exemplo: https://api.minhaempresa.com.br/protheus. Essa URL precisa ser acessível pela internet (nao pode ser um endereco interno de rede local, a menos que o CLEVIA esteja instalado na mesma rede). O endereco deve ser HTTPS (com certificado de segurança).',
  BRAND)}

${stepCard(3, 'Credenciais de acesso',
  'Voce precisa de credenciais validas para autenticar na API do ERP. Pode ser um Token (API Key) ou usuario e senha. Essas credenciais sao fornecidas pelo administrador do ERP da empresa. O CLEVIA aceita ambos os metodos: Bearer Token (API Key) ou autenticacao Basic (usuario e senha).',
  BRAND)}

${stepCard(4, 'Permissão de gerente ou CEO',
  'Apenas usuarios com cargo de CEO ou Gerente podem criar e gerenciar integracoes no CLEVIA. Mecanicos e outros cargos nao tem acesso à tela de Integrações.',
  AMBER)}

<h2 class="section"><span class="num">3</span>Passo a Passo: Criando uma Integração</h2>

<p class="intro">Siga os passos abaixo para configurar uma integracao entre o CLEVIA e qualquer ERP externo. O exemplo usa o TOTVS Protheus, mas o processo e o mesmo para qualquer ERP com API REST.</p>

${stepCard(1, 'Acessar a tela de Integrações',
  'Acesse o CLEVIA com seu login de CEO ou Gerente. Na barra lateral (menu lateral esquerdo), clique em "Integrações". Se voce nao ve essa opcao, entre em contato com o administrador do sistema para liberar o recurso de Integrações para sua empresa.',
  BRAND)}

${stepCard(2, 'Clicar em "Nova Integração"',
  'No canto superior direito da tela de Integrações, clique no botao azul "Nova Integração". Vai abrir uma janela com os tipos de integracao disponiveis.',
  BRAND)}

${stepCard(3, 'Escolher o tipo de integração',
  'Selecione "ERP Genérico" para TOTVS ou qualquer outro ERP com API REST. Se for integrar com SAP especificamente, escolha "SAP". Para integrar com IoT (sensores de producao), escolha "IoT — OPC UA" ou "IoT — Modbus TCP". Para sincronizar usuarios do Active Directory, escolha "Active Directory".',
  BRAND)}

${stepCard(4, 'Preencher o nome da integração',
  'Digite um nome para identificar a integracao. Exemplo: "TOTVS Protheus — Estoque e OS". Esse nome aparece na lista de integracoes para voce identificar depois.',
  BRAND)}

${stepCard(5, 'Informar a URL do endpoint',
  'Digite a URL base da API do ERP. Para o TOTVS Protheus, normalmente e algo como: https://api.suaempresa.com.br/rest. Para o TOTVS CARLOS, pode ser: https://api.suaempresa.com.br/api/v1. Essa URL deve ser HTTPS (com certificado de segurança). Enderecos HTTP (sem certificado) nao sao aceitos.',
  BRAND)}

${stepCard(6, 'Informar as credenciais',
  'Se o ERP usa Token (API Key), preencha o campo "API Key / Token" com o token fornecido pelo administrador do ERP. Se o ERP usa usuario e senha, preencha os campos "Usuario" e "Senha". O CLEVIA aceita apenas um dos dois metodos: se preencher o token, ele usa Bearer Token; se preencher usuario e senha, ele usa autenticacao Basic.',
  AMBER)}

${stepCard(7, 'Configurar o que sincronizar (opcional)',
  'Por padrao, a integracao do tipo "ERP Genérico" sincroniza o estoque (itens, quantidades, fornecedores). Se quiser sincronizar tambem as ordens de serviço do ERP, e possivel ativar essa opcao na configuracao. Para o TOTVS Protheus, os endpoints padrao sao: /items (estoque) e /workorders (ordens de serviço).',
  AMBER)}

${stepCard(8, 'Salvar e ativar',
  'Clique em "Criar Integração". A integracao aparece na lista com status "Em espera". Para testar, clique no botao "Sincronizar" (icone de seta circular). O CLEVIA vai conectar ao ERP, buscar os dados e gravar no sistema. O status muda para "Sucesso" (verde) ou "Erro" (vermelho) com a mensagem de erro.',
  EMERALD)}

${stepCard(9, 'Acompanhar os logs de sincronização',
  'Cada sincronizacao gera um log (registro) que mostra quantos dados foram sincronizados e se houve erro. Clique em "Ver logs" na integracao para ver o historico. Os logs sao mantidos por 50 sincronizacoes.',
  EMERALD)}

${infoBox('Segurança das credenciais',
  'As credenciais (token, usuario, senha) sao armazenadas de forma criptografada no banco de dados do CLEVIA. Elas nunca sao enviadas para o navegador de nenhum usuario, nem mesmo do CEO. Quando o CLEVIA lista as integracoes na tela, o campo de credenciais nao aparece. Apenas o servidor (Edge Function) tem acesso as credenciais, e apenas no momento da sincronizacao.',
  ROSE, '#fff1f2'
)}

<h2 class="section"><span class="num">4</span>Exemplo Prático: Integrando com o TOTVS Protheus</h2>

<p class="intro">Abaixo esta um exemplo completo de configuracao para integrar o CLEVIA com o TOTVS Protheus. O TOTVS Protheus possui uma API REST nativa que permite ler e gravar dados. Este exemplo assume que o Protheus ja tem a API REST habilitada e acessivel por HTTPS.</p>

<h3 class="sub">Dados do exemplo</h3>

${table(
  ['Campo', 'Valor de Exemplo'],
  [
    ['Tipo de integração', 'ERP Genérico'],
    ['Nome', 'TOTVS Protheus — Produção'],
    ['URL do endpoint', 'https://api.minhaempresa.com.br/rest'],
    ['Autenticação', 'Usuario e Senha (Basic Auth)'],
    ['Usuario', 'admin.clevia'],
    ['Senha', '••••••••••••'],
    ['Sincronizar estoque', 'Sim (padrão)'],
    ['Sincronizar OS', 'Sim (opcional)'],
  ]
)}

<h3 class="sub">Endpoints do TOTVS Protheus utilizados</h3>

<p style="font-size:13px;color:${SLATE};line-height:1.8;">O CLEVIA acessa os seguintes endpoints do TOTVS Protheus durante a sincronizacao:</p>

${table(
  ['Endpoint', 'Método', 'O que retorna', 'Onde grava no CLEVIA'],
  [
    ['/items', 'GET', 'Lista de itens de estoque (codigo, nome, quantidade, fornecedor, custo)', 'Estoque (inventory_items)'],
    ['/workorders', 'GET', 'Lista de ordens de serviço (se ativado)', 'Ordens de Serviço (work_orders)'],
  ]
)}

<h3 class="sub">Exemplo de requisicao enviada pelo CLEVIA</h3>

${codeBlock('Requisição HTTP (estoque)',
`GET /rest/items?$top=200 HTTP/1.1
Host: api.minhaempresa.com.br
Accept: application/json
Authorization: Basic YWRtaW4uY2xldmlhOnNlbmhh
Content-Type: application/json`)

}

<h3 class="sub">Exemplo de resposta do TOTVS Protheus</h3>

${codeBlock('Resposta JSON do TOTVS (estoque)',
`{
  "items": [
    {
      "code": "P001",
      "description": "Rolamento SKF 6205",
      "quantity": 50,
      "reorderPoint": 10,
      "unitCost": 45.90,
      "supplier": "SKF do Brasil"
    },
    {
      "code": "P002",
      "description": "Correia V B-56",
      "quantity": 8,
      "reorderPoint": 15,
      "unitCost": 22.50,
      "supplier": "Goodyear"
    }
  ]
}`)

}

<h3 class="sub">Como o CLEVIA grava os dados</h3>

<p style="font-size:13px;color:${SLATE};line-height:1.8;">Para cada item retornado pelo TOTVS, o CLEVIA verifica se ja existe um item com o mesmo codigo no estoque da empresa. Se existe, atualiza a quantidade, o custo e o fornecedor. Se nao existe, cria um novo item. Isso e feito automaticamente, sem intervencao manual. O processo se chama "upsert" (inserir ou atualizar).</p>

${infoBox('Mapeamento de campos',
  'O CLEVIA mapeia automaticamente os campos mais comuns do TOTVS para os campos do CLEVIA: "code/description" vira codigo e nome do item; "quantity/stock" vira quantidade em estoque; "reorderPoint/minQuantity" vira quantidade minima; "unitCost/cost" vira custo; "supplier" vira fornecedor. Se o seu TOTVS usa nomes de campos diferentes, entre em contato com o suporte para ajustar o mapeamento.',
  VIOLET, '#f5f3ff'
)}

<h2 class="section"><span class="num">5</span>Outros ERPs Suportados</h2>

<p class="intro">Alem do TOTVS, o CLEVIA pode se integrar com qualquer ERP que tenha API REST. Abaixo estao os exemplos mais comuns:</p>

<div class="two-col">
  <div class="compare-card" style="border-top:4px solid ${BRAND};">
    <h4 style="color:${BRAND_DARK};">SAP ERP / S4HANA</h4>
    <ul>
      <li><strong>Tipo:</strong> SAP (nativo)</li>
      <li><strong>Endpoint:</strong> URL do SAP Gateway / OData</li>
      <li><strong>Autenticação:</strong> Bearer Token ou usuario/senha</li>
      <li><strong>Sincroniza:</strong> Ordens de produção, notificações de manutenção, equipamentos</li>
      <li><strong>Observação:</strong> O SAP cria ordens de serviço automaticamente no CLEVIA a partir das notificações de manutenção</li>
    </ul>
  </div>
  <div class="compare-card" style="border-top:4px solid ${EMERALD};">
    <h4 style="color:${EMERALD_DARK};">Oracle NetSuite</h4>
    <ul>
      <li><strong>Tipo:</strong> ERP Genérico</li>
      <li><strong>Endpoint:</strong> URL do SuiteTalk REST</li>
      <li><strong>Autenticação:</strong> Bearer Token (OAuth 2.0)</li>
      <li><strong>Sincroniza:</strong> Estoque, ordens de serviço</li>
    </ul>
  </div>
</div>

<div class="two-col" style="margin-top:12px;">
  <div class="compare-card" style="border-top:4px solid ${AMBER};">
    <h4 style="color:${AMBER_DARK};">Omie API</h4>
    <ul>
      <li><strong>Tipo:</strong> ERP Genérico</li>
      <li><strong>Endpoint:</strong> https://app.omie.com.br/api/v1</li>
      <li><strong>Autenticação:</strong> API Key (App Key + App Secret)</li>
      <li><strong>Sincroniza:</strong> Estoque, fornecedores</li>
    </ul>
  </div>
  <div class="compare-card" style="border-top:4px solid ${VIOLET};">
    <h4 style="color:${VIOLET_DARK};">Sankhya</h4>
    <ul>
      <li><strong>Tipo:</strong> ERP Genérico</li>
      <li><strong>Endpoint:</strong> URL do Sankhya API</li>
      <li><strong>Autenticação:</strong> Usuario/senha (Basic Auth)</li>
      <li><strong>Sincroniza:</strong> Estoque, ordens de serviço</li>
    </ul>
  </div>
</div>

<h2 class="section"><span class="num">6</span>Solucionando Problemas Comuns</h2>

${table(
  ['Problema', 'Causa Provável', 'Solução'],
  [
    ['Status "Erro" apos sincronizar', 'URL incorreta, credenciais invalidas, ou ERP offline', 'Verifique a URL e as credenciais. Confirme que o ERP esta online e a API esta ativa. Clique em "Sincronizar" novamente apos corrigir.'],
    ['Nenhum registro sincronizado', 'O ERP retornou lista vazia ou os nomes dos campos nao batem com o esperado', 'Verifique se o ERP tem dados no endpoint /items. Se os campos tiverem nomes diferentes, contate o suporte para ajustar o mapeamento.'],
    ['Erro "Endereço invalido"', 'A URL nao e HTTPS ou e um endereco interno de rede local', 'O CLEVIA so aceita URLs HTTPS publicas. Se o ERP so tem endereco interno, considere usar um middleware ou expor a API com HTTPS publico.'],
    ['Integracao nao aparece na lista', 'O recurso de Integrações nao esta liberado para a empresa', 'Entre em contato com o administrador do sistema para liberar o recurso na tela "Liberação de Recursos por Empresa".'],
    ['Sincronizacao lenta', 'ERP com muitos dados ou conexao lenta', 'O CLEVIA busca ate 200 itens por sincronizacao. Se precisar de mais, contate o suporte para ajustar o tamanho do lote.'],
  ]
)}

${infoBox('Suporte técnico',
  'Se voce encontrar problemas que nao estao listados aqui, entre em contato com o suporte tecnico do CLEVIA. Tenha em maos: o nome da integracao, a URL do endpoint, o tipo de ERP, e a mensagem de erro mostrada na tela (se houver). O suporte pode acessar os logs do servidor para diagnosticar o problema.',
  BRAND, BG_TINT
)}

<h2 class="section"><span class="num">7</span>Checklist de Implantação</h2>

<p class="intro">Use este checklist para garantir que a integracao foi configurada corretamente:</p>

${stepCard(1, 'Confirmar que o ERP tem API REST ativa', 'O administrador do ERP confirmou que a API REST esta habilitada e acessivel por HTTPS.', BRAND)}
${stepCard(2, 'Obter URL e credenciais', 'Voce tem a URL base da API e as credenciais (token ou usuario/senha) fornecidas pelo administrador do ERP.', BRAND)}
${stepCard(3, 'Criar a integracao no CLEVIA', 'A integracao foi criada na tela de Integracoes com o tipo, nome, URL e credenciais corretos.', BRAND)}
${stepCard(4, 'Executar a primeira sincronizacao', 'O botao "Sincronizar" foi clicado e o status mudou para "Sucesso" (verde).', EMERALD)}
${stepCard(5, 'Verificar os dados no CLEVIA', 'Os itens de estoque (ou ordens de serviço) do ERP aparecem no CLEVIA na tela de Estoque (ou OS).', EMERALD)}
${stepCard(6, 'Configurar sincronizacao automatica (opcional)', 'Se desejar sincronizacao automatica periodica, contate o suporte para configurar o intervalo (ex: a cada 1 hora).', AMBER)}

<div class="footer">
  CLEVIA Cloud 2.0 — Plataforma Inteligente de Gestão Industrial e Manutenção<br/>
  Guia de Integração gerado em ${today} para ${companyName}<br/>
  Desenvolvedor: Clebson Bernardo Velho
</div>

</body>
</html>`;

  printHTMLtoPDF(html, `Guia-Integracao-CLEVIA-${companyName.replace(/\s+/g, '-')}`);
}
