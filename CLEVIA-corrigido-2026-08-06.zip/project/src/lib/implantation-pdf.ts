import { printHTMLtoPDF } from './pdf';

const BRAND = '#0ea5e9';
const BRAND_DARK = '#0369a1';
const SLATE = '#1e293b';
const MUTED = '#64748b';
const BG_TINT = '#f0f9ff';
const CARD_BORDER = '#e2e8f0';
const AMBER = '#f59e0b';
const AMBER_DARK = '#92400e';
const EMERALD = '#10b981';
const EMERALD_DARK = '#047857';

function stepCard(num: number, title: string, body: string, accent: string): string {
  return `<div style="display:flex;gap:14px;padding:16px 18px;border:1px solid ${CARD_BORDER};border-radius:10px;background:#fff;page-break-inside:avoid;margin-bottom:10px;">
    <div style="flex-shrink:0;width:32px;height:32px;border-radius:50%;background:${accent};display:flex;align-items:center;justify-content:center;">
      <span style="color:#fff;font-size:14px;font-weight:800;">${num}</span>
    </div>
    <div>
      <div style="font-weight:700;font-size:14px;color:${SLATE};margin-bottom:4px;">${title}</div>
      <div style="font-size:12px;color:${MUTED};line-height:1.6;">${body}</div>
    </div>
  </div>`;
}

function infoBox(title: string, body: string, accent: string, bg: string): string {
  return `<div style="background:${bg};border-left:4px solid ${accent};border-radius:0 8px 8px 0;padding:14px 18px;margin:16px 0;">
    <div style="font-weight:700;font-size:13px;color:${SLATE};margin-bottom:4px;">${title}</div>
    <div style="font-size:12px;color:${MUTED};line-height:1.6;">${body}</div>
  </div>`;
}

export function generateImplantationPDF(companyName: string = 'Nova Empresa') {
  const today = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Guia de Implantação CLEVIA — ${companyName}</title>
<style>
  @page { margin: 16mm 14mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI','Helvetica Neue',Arial,sans-serif; margin:0; color:${SLATE}; line-height:1.6; }
  .cover { text-align:center; padding:50px 36px 36px; background:linear-gradient(135deg,${BG_TINT},#fff); border-radius:16px; margin-bottom:30px; }
  .cover-badge { display:inline-block; padding:6px 18px; border-radius:999px; background:${BRAND}; color:#fff; font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-bottom:18px; }
  .cover h1 { font-size:32px; font-weight:900; color:${SLATE}; margin:0 0 6px; letter-spacing:2px; }
  .cover h2 { font-size:15px; font-weight:600; color:${BRAND_DARK}; margin:0 0 20px; }
  .cover-meta { display:flex; justify-content:center; gap:36px; margin-top:24px; }
  .cover-meta .label { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:${MUTED}; }
  .cover-meta .value { font-size:13px; font-weight:700; color:${SLATE}; margin-top:2px; }
  h2.section { font-size:20px; font-weight:800; color:${SLATE}; margin:28px 0 14px; padding-bottom:8px; border-bottom:2px solid ${BRAND}; page-break-after:avoid; }
  h2.section .num { display:inline-block; width:28px; height:28px; border-radius:6px; background:${BRAND}; color:#fff; font-size:14px; text-align:center; line-height:28px; margin-right:10px; }
  p.intro { font-size:13px; color:${MUTED}; line-height:1.8; margin-bottom:20px; }
  .footer { margin-top:36px; padding-top:14px; border-top:1px solid ${CARD_BORDER}; text-align:center; font-size:11px; color:${MUTED}; }
  .two-col { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .compare-card { border:1px solid ${CARD_BORDER}; border-radius:10px; padding:16px; }
  .compare-card h4 { font-size:14px; font-weight:800; margin:0 0 8px; }
  .compare-card ul { margin:0; padding-left:16px; }
  .compare-card li { font-size:12px; color:${MUTED}; line-height:1.7; }
</style>
</head>
<body>

<div class="cover">
  <div class="cover-badge">Guia de Implantação — Passo a Passo</div>
  <h1>CLEVIA</h1>
  <h2>Plataforma Inteligente de Gestão Industrial e Manutenção</h2>
  <p style="font-size:13px;color:${MUTED};max-width:500px;margin:0 auto;">Guia completo de implantação do sistema na empresa e nos celulares dos mecânicos, com explicação de como o banco de dados mantém os clientes separados.</p>
  <div class="cover-meta">
    <div><div class="label">Cliente</div><div class="value">${companyName}</div></div>
    <div><div class="label">Data</div><div class="value">${today}</div></div>
    <div><div class="label">Versão</div><div class="value">Cloud 2.0</div></div>
  </div>
</div>

<p class="intro">Este documento descreve o processo completo de implantação do CLEVIA em uma nova empresa cliente, desde o cadastro inicial até a instalação nos celulares dos mecânicos. Siga cada passo na ordem indicada.</p>

<h2 class="section"><span class="num">1</span>Implantação na Empresa (Computador)</h2>

${stepCard(1, 'Cadastro da Empresa',
  'Acesse o sistema com seu login de administrador. Vá em "Empresas" e clique em "Nova Empresa". Preencha o nome da empresa, CNPJ e dados básicos. O sistema cria automaticamente um identificador único para essa empresa, que será usado para separar todos os dados dela das demais empresas.',
  BRAND)}

${stepCard(2, 'Criação do Usuário CEO do Cliente',
  'Ainda na tela de Empresas, adicione o primeiro usuário da empresa cliente com o cargo "CEO". Esse será o login do dono ou responsável pela empresa. Ele receberá um e-mail com as instruções de acesso e senha. O CEO da empresa cliente terá acesso a todas as telas e configurações internas da empresa dele.',
  BRAND)}

${stepCard(3, 'Configuração da Licença',
  'Vá em "Licenças" e configure o plano da empresa: Básico ou Premium. O plano Básico inclui as telas essenciais (Dashboard, OS, Máquinas, Mecânicos, Preventivas, Indicadores, Estoque, Empresas, Usuários). O plano Premium adiciona telas avançadas (Quadro de Setores, Mapa da Fábrica, Históricos, Relatórios, IA Preditiva, Assistente IA, Auditoria, Conformidade, Gerenciar Telas, Localização de Mecânicos). Defina também a mensalidade e a data de vencimento.',
  BRAND)}

${stepCard(4, 'Liberação de Recursos Extras (Opcional)',
  'Se o cliente solicitou funcionalidades específicas que não fazem parte de nenhum plano (como Contratos, Configurações, Integrações ou Documento Técnico), vá na tela "Liberação de Recursos por Empresa" (exclusiva do administrador do sistema). Encontre a empresa e ative apenas os recursos que ela contratou. Os outros clientes não são afetados.',
  AMBER)}

${stepCard(5, 'Cadastro de Máquinas e Setores',
  'O CEO do cliente (ou você em nome dele) acessa o sistema e cadastra as máquinas, setores e filiais. Vá em "Máquinas" e adicione cada equipamento com nome, código, setor, modelo e fabricante. O status de cada máquina é controlado automaticamente pelo sistema conforme as ordens de serviço são abertas e fechadas.',
  BRAND)}

${stepCard(6, 'Cadastro de Mecânicos',
  'Vá em "Mecânicos" e cadastre cada mecânico da empresa. Para cada um, informe nome, especialidade, telefone e e-mail. Depois, vá em "Usuários" e crie o login de cada mecânico com o cargo "Mecânico". Cada mecânico receberá um e-mail para definir sua senha e acessar o sistema pelo celular.',
  BRAND)}

${stepCard(7, 'Configuração de Permissões',
  'Vá em "Permissões" (exclusivo do CEO da empresa) e defina o que cada usuário pode fazer. Por exemplo: o CEO pode liberar para um supervisor apenas "Registrar Produção" e "Gerenciar OS", sem dar acesso a "Gerenciar Usuários" ou "Gerenciar Empresas". As permissões são granulares e por usuário.',
  BRAND)}

${stepCard(8, 'Configuração de Telas de Monitor (Opcional)',
  'Se a empresa quer telas de produção expostas nos setores (monitores na parede), vá em "Gerenciar Telas" e configure quais setores e informações cada monitor vai exibir. O monitor pode ser aberto em qualquer navegador e fica em exibição contínua.',
  BRAND)}

<h2 class="section"><span class="num">2</span>Implantação nos Celulares dos Mecânicos</h2>

${stepCard(1, 'Instalação do App no Celular',
  'O mecânico abre o navegador do celular (Google Chrome ou Safari) e digita o endereço do sistema. Faz login com seu e-mail e senha. O sistema funciona como aplicativo: ao adicionar à tela inicial, cria um ícone no celular igual a um app nativo. No Chrome: menu (3 pontinhos) > "Adicionar à tela inicial". No Safari (iPhone): botão compartilhar > "Adicionar à Tela de Início".',
  AMBER)}

${stepCard(2, 'Ativação das Notificações',
  'Ao entrar no sistema pelo celular pela primeira vez, aparece um banner pedindo para ativar as notificações. O mecânico deve tocar em "Ativar". O navegador vai pedir permissão — ele deve aceitar. Isso é essencial: sem notificações, o mecânico não recebe aviso de novas OS. Se ele recusar por engano, precisa ir nas configurações do navegador e permitir notificações para o site.',
  AMBER)}

${stepCard(3, 'Como Funciona o Aviso de Nova OS',
  'Quando uma nova ordem de serviço é atribuída ao mecânico, ele recebe imediatamente uma notificação no celular com som e vibração. A notificação mostra o título da OS. Se ele não aceitar a OS em 1 minuto, o sistema reenvia o aviso com um som mais forte e vibração mais longa. Isso continua a cada minuto até ele aceitar. Para aceitar, basta abrir a notificação ou ir em "Ordens de Serviço" e tocar em "Aceitar".',
  AMBER)}

${stepCard(4, 'Execução da OS no Celular',
  'O mecânico abre a OS atribuída, lê a descrição do defeito, toca em "Iniciar" quando começar o trabalho. Pode registrar o diagnóstico, o procedimento realizado e as peças usadas. Se precisar pausar (por exemplo, para aguardar peça), toca em "Pausar" e depois "Retomar". Ao terminar, toca em "Encerrar" e preenche o que foi feito.',
  AMBER)}

${stepCard(5, 'Checklist de Conformidade',
  'Se a empresa usa checklists de conformidade (ISO 55001 ou NR-12), o mecânico acessa "Conformidade" no celular e preenche os checklists atribuídos. O sistema registra quem preencheu e quando.',
  AMBER)}

${infoBox('Importante para o Mecânico',
  'O mecânico só precisa de duas coisas: conexão com internet no celular e notificações ativadas. O sistema funciona mesmo em internet lenta. Se o mecânico ficar sem sinal temporariamente, as OS já carregadas continuam acessíveis e, quando a internet voltar, o sistema sincroniza tudo automaticamente.',
  AMBER, '#fffbeb')}

<h2 class="section"><span class="num">3</span>Como o Banco de Dados Separa os Clientes</h2>

<p class="intro">Esta seção explica de forma simples como o sistema mantém os dados de cada empresa separados. Use esta explicação caso o cliente pergunte: "Meus dados estão misturados com os de outras empresas?"</p>

${infoBox('Resposta direta para o cliente',
  'Não. Cada empresa tem seus dados completamente separados. É como um prédio de escritórios: todas as empresas dividem o mesmo prédio (o servidor), mas cada uma tem sua sala trancada com sua própria chave. Ninguém entra na sala do outro.',
  EMERALD, '#ecfdf5')}

${stepCard(1, 'Identificador Único por Empresa',
  'Quando uma empresa é cadastrada no sistema, ela recebe um identificador único (um código interno que ninguém vê). Esse código é como o "CPF" da empresa dentro do sistema. Cada empresa tem o seu e não existem duas empresas com o mesmo código.',
  EMERALD)}

${stepCard(2, 'Todos os Dados Carregam o Código da Empresa',
  'Toda informação cadastrada no sistema — cada máquina, cada ordem de serviço, cada mecânico, cada item de estoque, cada preventiva — carrega o campo "empresa" preenchido com o código da empresa dona. Ou seja, quando a Empresa A cadastra uma máquina, essa máquina fica marcada como pertencente à Empresa A. A Empresa B não consegue vê-la.',
  EMERALD)}

${stepCard(3, 'Bloqueio Automático de Acesso (RLS)',
  'O banco de dados tem uma camada de segurança chamada RLS (Row Level Security) que funciona automaticamente, sem que ninguém precise configurar. Toda vez que um usuário tenta ver ou modificar algo, o sistema verifica: "Esse usuário pertence à empresa X? Então ele só pode ver e modificar dados da empresa X." Se ele tentar acessar dados de outra empresa, o banco de dados simplesmente retorna vazio — como se os dados não existissem.',
  EMERALD)}

${stepCard(4, 'O CEO da Empresa Só Vê a Empresa Dele',
  'O CEO da empresa cliente faz login e o sistema identifica automaticamente a qual empresa ele pertence. Ele só vê máquinas, OS, mecânicos, estoque e relatórios da empresa dele. Ele não sabe que outras empresas existem no sistema, não vê os dados delas e não consegue acessá-los de nenhuma forma.',
  EMERALD)}

${stepCard(5, 'O Administrador do Sistema Vê Tudo',
  'Apenas o administrador do sistema (você, dono do software) tem acesso a todas as empresas. Você pode ver todas as empresas cadastradas, gerenciar licenças, liberar recursos específicos por empresa e acessar a tela de Auditoria. Esse acesso é exclusivo do administrador e não pode ser concedido a nenhum cliente.',
  EMERALD)}

<h2 class="section"><span class="num">4</span>Recursos Exclusivos por Cliente</h2>

<p class="intro">Se um cliente quiser uma funcionalidade que os outros não têm, o sistema oferece três níveis de controle para garantir que a mudança afete apenas a empresa que solicitou.</p>

<div class="two-col">
  <div class="compare-card" style="border-top:4px solid ${BRAND};">
    <h4 style="color:${BRAND_DARK};">Plano da Empresa</h4>
    <ul>
      <li><strong>Básico:</strong> telas essenciais (Dashboard, OS, Máquinas, Mecânicos, Preventivas, Indicadores, Estoque, Empresas, Usuários).</li>
      <li><strong>Premium:</strong> adiciona Quadro de Setores, Mapa da Fábrica, Históricos, Relatórios, IA, Auditoria, Conformidade, Telas e Localização.</li>
      <li>Mudar o plano de uma empresa não afeta as demais.</li>
    </ul>
  </div>
  <div class="compare-card" style="border-top:4px solid ${AMBER};">
    <h4 style="color:${AMBER_DARK};">Liberação por Empresa</h4>
    <ul>
      <li>Recursos fora dos planos (Contratos, Configurações, Integrações, Documento Técnico) podem ser ativados individualmente por empresa.</li>
      <li>A ativação é feita pelo administrador do sistema na tela "Liberação de Recursos por Empresa".</li>
      <li>Apenas a empresa selecionada passa a ver o recurso. Nenhum outro cliente é impactado.</li>
    </ul>
  </div>
</div>

<div class="compare-card" style="border-top:4px solid ${EMERALD};margin-top:12px;">
  <h4 style="color:${EMERALD_DARK};">Permissões por Usuário (dentro da empresa)</h4>
  <ul style="columns:2;">
    <li>Registrar Produção</li>
    <li>Gerenciar Máquinas</li>
    <li>Gerenciar Ordens de Serviço</li>
    <li>Gerenciar Mecânicos</li>
    <li>Gerenciar Preventivas</li>
    <li>Gerenciar Estoque</li>
    <li>Gerenciar Empresas</li>
    <li>Gerenciar Usuários</li>
    <li>Gerenciar Telas</li>
    <li>Ver Indicadores</li>
    <li>Ver Localização de Mecânicos</li>
    <li>Ver Histórico de OS</li>
    <li>Ver Histórico de Máquinas</li>
  </ul>
  <p style="font-size:11px;color:${MUTED};margin-top:8px;">O CEO da empresa concede ou revoga essas permissões individualmente para cada funcionário, sem afetar outras empresas.</p>
</div>

${infoBox('Resumo para Explicar ao Cliente',
  'Cada empresa tem seus dados separados por um código único. O sistema bloqueia automaticamente qualquer tentativa de acesso cruzado entre empresas. Se um cliente quiser um recurso extra só para ele, o administrador ativa esse recurso apenas para a empresa dele, sem que os outros clientes vejam ou sejam afetados.',
  BRAND, BG_TINT)}

<div class="footer">
  CLEVIA Cloud 2.0 — Plataforma Inteligente de Gestão Industrial e Manutenção<br/>
  Documento gerado em ${today} para ${companyName}<br/>
  Desenvolvedor: Clebson Bernardo Velho
</div>

</body>
</html>`;

  printHTMLtoPDF(html, `Guia-Implantacao-CLEVIA-${companyName.replace(/\s+/g, '-')}`);
}
