import { useEffect, useMemo, useState, useRef } from 'react';
import { supabase, type ProductionLog, type Machine, type ProductionSector, type MonitorScreen, type ProductionOrder } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { BarChart3, Clock, TrendingUp, Activity, Gauge, Factory, Zap, ArrowDownToLine, AlertTriangle, Package, CheckCircle2, Play, Plus, X, Settings, BarChart2, LineChart as LineIcon, Pause, Archive, History } from 'lucide-react';

type Range = 'hora' | 'dia' | 'semana' | 'mes';

const SECTOR_COLORS = [
  { from: '#06b6d4', to: '#0ea5e9', glow: 'rgba(6,182,212,0.45)' },
  { from: '#f59e0b', to: '#fbbf24', glow: 'rgba(245,158,11,0.45)' },
  { from: '#ec4899', to: '#f472b6', glow: 'rgba(236,72,153,0.45)' },
  { from: '#10b981', to: '#34d399', glow: 'rgba(16,185,129,0.45)' },
  { from: '#ef4444', to: '#f87171', glow: 'rgba(239,68,68,0.45)' },
  { from: '#3b82f6', to: '#60a5fa', glow: 'rgba(59,130,246,0.45)' },
  { from: '#14b8a6', to: '#2dd4bf', glow: 'rgba(20,184,166,0.45)' },
  { from: '#f97316', to: '#fb923c', glow: 'rgba(249,115,22,0.45)' },
];

export default function SectorProductionChart() {
  const { activeCompany, activeRole } = useAuth();
  const canRegister = ['ceo', 'gerente', 'supervisora', 'lider', 'encarregado'].includes(activeRole ?? '');
  const cid = activeCompany?.id;
  const [production, setProduction] = useState<ProductionLog[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [prodSectors, setProdSectors] = useState<ProductionSector[]>([]);
  const [monitorScreens, setMonitorScreens] = useState<MonitorScreen[]>([]);
  const [orders, setOrders] = useState<ProductionOrder[]>([]);
  const [selectedSector, setSelectedSector] = useState<string | null>(null);
  const [range, setRange] = useState<Range>('hora');
  const [chartMode, setChartMode] = useState<'bars' | 'line' | 'combo'>('combo');
  const [showConfig, setShowConfig] = useState(false);
  const [newSectorName, setNewSectorName] = useState('');

  const [opInput, setOpInput] = useState('');
  const [opNumber, setOpNumber] = useState('');
  const [targetPerHour, setTargetPerHour] = useState('');
  const [submittingOp, setSubmittingOp] = useState(false);
  const [hourUnits, setHourUnits] = useState('');
  const [submittingHour, setSubmittingHour] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (!cid) return;
    let cancelled = false;
    const load = async () => {
      const [prodRes, machRes, secRes, screenRes, orderRes] = await Promise.all([
        supabase.from('production_logs').select('*').eq('company_id', cid).order('log_date', { ascending: true }).limit(500),
        supabase.from('machines').select('*').eq('company_id', cid),
        supabase.from('production_sectors').select('*').eq('company_id', cid).order('sector_name', { ascending: true }),
        supabase.from('monitor_screens').select('*').eq('company_id', cid).order('sort_order', { ascending: true }),
        supabase.from('production_orders').select('*').eq('company_id', cid).order('started_at', { ascending: false }).limit(200),
      ]);
      if (cancelled) return;
      setProduction(prodRes.data ?? []);
      setMachines(machRes.data ?? []);
      setProdSectors(secRes.data ?? []);
      setMonitorScreens(screenRes.data ?? []);
      setOrders(orderRes.data ?? []);
    };
    load();
    const channel = supabase.channel('sector-prod-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'production_logs', filter: `company_id=eq.${cid}` }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'machines', filter: `company_id=eq.${cid}` }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'production_sectors', filter: `company_id=eq.${cid}` }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'monitor_screens', filter: `company_id=eq.${cid}` }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'production_orders', filter: `company_id=eq.${cid}` }, load)
      .subscribe();
    const poll = setInterval(load, 5000);
    return () => { cancelled = true; clearInterval(poll); supabase.removeChannel(channel); };
  }, [cid]);

  // Names of sectors that still exist as monitor screens
  const screenNames = useMemo(() => new Set(monitorScreens.map((s) => s.name)), [monitorScreens]);

  // Sectors enabled for production chart — only those that still exist as a screen
  const enabledSectors = useMemo(() =>
    prodSectors
      .map((s) => s.sector_name)
      .filter((name) => screenNames.has(name)),
    [prodSectors, screenNames]
  );

  // All available sectors (from screens + manually added, filtered by existing screens)
  const allSectors = useMemo(() => {
    const set = new Set<string>();
    monitorScreens.forEach((s) => set.add(s.name));
    prodSectors.forEach((s) => { if (screenNames.has(s.sector_name)) set.add(s.sector_name); });
    return Array.from(set).sort();
  }, [monitorScreens, prodSectors, screenNames]);

  useEffect(() => {
    if (!selectedSector && enabledSectors.length > 0) setSelectedSector(enabledSectors[0]);
    if (selectedSector && enabledSectors.length > 0 && !enabledSectors.includes(selectedSector)) setSelectedSector(enabledSectors[0]);
    if (enabledSectors.length === 0) setSelectedSector(null);
  }, [enabledSectors, selectedSector]);

  const sectorColor = useMemo(() => {
    const idx = enabledSectors.indexOf(selectedSector ?? '');
    return SECTOR_COLORS[(idx >= 0 ? idx : 0) % SECTOR_COLORS.length];
  }, [enabledSectors, selectedSector]);

  const sectorProd = useMemo(() => {
    if (!selectedSector) return [];
    const machineIdsInSector = new Set(machines.filter((m) => m.sector === selectedSector).map((m) => m.id));
    return production.filter((p) => p.sector === selectedSector || (p.sector === null && p.machine_id && machineIdsInSector.has(p.machine_id)));
  }, [production, machines, selectedSector]);

  const activeOrder = useMemo(() => orders.find((order) => order.sector === selectedSector && order.status !== 'archived') ?? null, [orders, selectedSector]);
  const archivedOrders = useMemo(() => orders.filter((order) => order.sector === selectedSector && order.status === 'archived'), [orders, selectedSector]);
  const activeOrderLogs = useMemo(() => activeOrder ? sectorProd.filter((log) => log.production_order_id === activeOrder.id) : [], [sectorProd, activeOrder]);
  const entradaOpHoje = activeOrder?.input_quantity ?? 0;
  const producaoHoje = useMemo(() => activeOrderLogs.reduce((sum, log) => sum + (log.units_produced ?? 0), 0), [activeOrderLogs]);
  const backlogHoje = Math.max(0, entradaOpHoje - producaoHoje);

  useEffect(() => { setOpInput(''); setOpNumber(''); setTargetPerHour(''); setHourUnits(''); setMsg(null); }, [selectedSector]);

  // Auto-cycle chart modes for a dynamic, alternating feel
  useEffect(() => {
    const cycle = setInterval(() => {
      setChartMode((prev) => prev === 'combo' ? 'bars' : prev === 'bars' ? 'line' : 'combo');
    }, 6000);
    return () => clearInterval(cycle);
  }, []);

  const chartData = useMemo(() => {
    const now = new Date();
    const build = (label: string, detail: string, filter: (p: ProductionLog) => boolean) => {
      const source = range === 'hora' && activeOrder ? activeOrderLogs : sectorProd;
      const filtered = source.filter(filter);
      return { label, detail, producao: filtered.reduce((s, p) => s + (p.units_produced ?? 0), 0), entrada: filtered.reduce((s, p) => s + (p.op_input ?? 0), 0), meta: range === 'hora' ? (activeOrder?.target_per_hour ?? 0) : 0 };
    };
    if (range === 'hora') {
      const arr: ReturnType<typeof build>[] = [];
      for (let i = 11; i >= 0; i--) {
        const h = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() - i);
        const isoDate = h.toISOString().slice(0, 10);
        const hour = h.getHours();
        arr.push(build(`${hour}h`, `${h.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })} às ${hour}h`, (p) => p.log_date === isoDate && p.production_hour === hour));
      }
      return arr;
    }
    if (range === 'dia') {
      const arr: ReturnType<typeof build>[] = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
        const iso = d.toISOString().slice(0, 10);
        arr.push(build(i === 0 ? 'Hoje' : d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''), d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' }), (p) => p.log_date === iso));
      }
      return arr;
    }
    if (range === 'semana') {
      const arr: ReturnType<typeof build>[] = [];
      for (let i = 5; i >= 0; i--) {
        const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i * 7);
        const start = new Date(end); start.setDate(start.getDate() - 6);
        arr.push(build(`S${i === 0 ? ' atual' : `-${i}`}`, `${start.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })} a ${end.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}`, (p) => p.log_date >= start.toISOString().slice(0, 10) && p.log_date <= end.toISOString().slice(0, 10)));
      }
      return arr;
    }
    const arr: ReturnType<typeof build>[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthStr = d.toISOString().slice(0, 7);
      arr.push(build(d.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', ''), d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }), (p) => (p.log_date ?? '').slice(0, 7) === monthStr));
    }
    return arr;
  }, [sectorProd, range, activeOrder, activeOrderLogs]);

  const totalThisWeek = useMemo(() => {
    const now = new Date();
    const start = new Date(now); start.setDate(start.getDate() - 6);
    return sectorProd.filter((p) => p.log_date >= start.toISOString().slice(0, 10) && p.log_date <= now.toISOString().slice(0, 10)).reduce((s, p) => s + (p.units_produced ?? 0), 0);
  }, [sectorProd]);

  const totalThisMonth = useMemo(() => {
    const monthStr = new Date().toISOString().slice(0, 7);
    return sectorProd.filter((p) => (p.log_date ?? '').slice(0, 7) === monthStr).reduce((s, p) => s + (p.units_produced ?? 0), 0);
  }, [sectorProd]);

  const efficiency = useMemo(() => entradaOpHoje === 0 ? 0 : Math.min(100, Math.round((producaoHoje / entradaOpHoje) * 100)), [entradaOpHoje, producaoHoje]);
  const hourlyAverage = useMemo(() => {
    const productive = activeOrderLogs.filter((log) => log.units_produced > 0);
    return productive.length ? Math.round(producaoHoje / productive.length) : 0;
  }, [activeOrderLogs, producaoHoje]);

  // Chart scale calculations
  const maxVal = Math.max(...chartData.map((d) => Math.max(d.producao, d.entrada, d.meta)), 1);
  const yMax = Math.ceil(maxVal * 1.15);
  const yTicks = 5;
  const yStep = Math.ceil(yMax / yTicks) || 1;

  // Add/remove sectors
  const addSector = async (name: string) => {
    if (!cid || !name.trim()) return;
    const trimmed = name.trim();
    if (prodSectors.some((s) => s.sector_name === trimmed)) { setMsg({ ok: false, text: 'Este setor já está no gráfico.' }); return; }
    const tempId = `temp-${Date.now()}`;
    setProdSectors((prev) => [...prev, { id: tempId, company_id: cid, sector_name: trimmed, created_at: new Date().toISOString() }]);
    setNewSectorName('');
    setMsg({ ok: true, text: `Setor "${trimmed}" adicionado ao gráfico.` });
    setTimeout(() => setMsg(null), 3000);
    const { error } = await supabase.from('production_sectors').insert({ company_id: cid, sector_name: trimmed });
    if (error) {
      setProdSectors((prev) => prev.filter((s) => s.id !== tempId));
      setMsg({ ok: false, text: 'Erro ao adicionar setor.' });
    }
  };

  const removeSector = async (name: string) => {
    if (!cid) return;
    const sector = prodSectors.find((s) => s.sector_name === name);
    if (!sector) return;
    setProdSectors((prev) => prev.filter((s) => s.sector_name !== name));
    if (selectedSector === name) setSelectedSector(null);
    const { error } = await supabase.from('production_sectors').delete().eq('id', sector.id);
    if (error) {
      setProdSectors((prev) => [...prev, sector]);
      setMsg({ ok: false, text: 'Erro ao remover setor.' });
    }
  };

  const submitOp = async () => {
    if (!cid || !selectedSector) return;
    const n = parseInt(opInput, 10);
    if (isNaN(n) || n <= 0) { setMsg({ ok: false, text: 'Digite uma quantidade válida.' }); return; }
    if (!opNumber.trim()) { setMsg({ ok: false, text: 'Informe o número da OP.' }); return; }
    if (activeOrder) { setMsg({ ok: false, text: `A OP ${activeOrder.order_number} precisa ser arquivada antes de iniciar outra.` }); return; }
    setSubmittingOp(true); setMsg(null);
    const now = new Date();
    const logDate = now.toISOString().slice(0, 10);
    const hour = now.getHours();
    const { data: order, error: orderError } = await supabase.from('production_orders').insert({
      company_id: cid, sector: selectedSector, order_number: opNumber.trim(), input_quantity: n,
      target_per_hour: Math.max(0, parseInt(targetPerHour, 10) || 0), status: 'active',
    }).select('*').single();
    let error = orderError;
    if (order && !error) {
      const result = await supabase.from('production_logs').insert({ company_id: cid, production_order_id: order.id, log_date: logDate, production_hour: hour, units_produced: 0, sector: selectedSector, op_input: n, op_output: 0 });
      error = result.error;
      if (!error) setOrders((previous) => [order as ProductionOrder, ...previous]);
    }
    setSubmittingOp(false);
    if (error) setMsg({ ok: false, text: error.message.includes('duplicate') ? 'Este número de OP já existe neste setor.' : 'Erro ao iniciar a OP.' });
    else { setMsg({ ok: true, text: `OP ${opNumber.trim()} iniciada com ${n} peças.` }); setOpInput(''); setOpNumber(''); setTargetPerHour(''); setTimeout(() => setMsg(null), 3000); }
  };

  const submitHour = async () => {
    if (!cid || !selectedSector) return;
    const n = parseInt(hourUnits, 10);
    if (isNaN(n) || n < 0) { setMsg({ ok: false, text: 'Quantidade inválida.' }); return; }
    if (!activeOrder) { setMsg({ ok: false, text: 'Inicie uma OP primeiro.' }); return; }
    if (activeOrder.status === 'paused') { setMsg({ ok: false, text: 'A OP está pausada. Retome antes de registrar produção.' }); return; }
    setSubmittingHour(true); setMsg(null);
    const now = new Date();
    const logDate = now.toISOString().slice(0, 10);
    const hour = now.getHours();
    const tempId = `temp-${Date.now()}`;
    setProduction((prev) => [...prev, { id: tempId, company_id: cid, machine_id: null, production_order_id: activeOrder.id, log_date: logDate, units_produced: n, uptime_hours: 1, production_hour: hour, created_at: now.toISOString(), sector: selectedSector, op_input: 0, op_output: 0 }]);
    const { error } = await supabase.from('production_logs').insert({ company_id: cid, production_order_id: activeOrder.id, log_date: logDate, production_hour: hour, units_produced: n, sector: selectedSector, op_input: 0, op_output: 0 });
    setSubmittingHour(false);
    if (error) { setProduction((prev) => prev.filter((p) => p.id !== tempId)); setMsg({ ok: false, text: 'Erro ao registrar.' }); }
    else { setMsg({ ok: true, text: `${n} peças registradas.` }); setHourUnits(''); setTimeout(() => setMsg(null), 3000); }
  };

  const togglePause = async () => {
    if (!activeOrder) return;
    const pausing = activeOrder.status === 'active';
    const { error } = await supabase.from('production_orders').update({
      status: pausing ? 'paused' : 'active', paused_at: pausing ? new Date().toISOString() : null,
    }).eq('id', activeOrder.id);
    if (error) setMsg({ ok: false, text: 'Não foi possível alterar o estado da OP.' });
    else {
      setOrders((previous) => previous.map((order) => order.id === activeOrder.id ? { ...order, status: pausing ? 'paused' : 'active', paused_at: pausing ? new Date().toISOString() : null } : order));
      setMsg({ ok: true, text: pausing ? `OP ${activeOrder.order_number} pausada.` : `OP ${activeOrder.order_number} retomada.` });
    }
  };

  const archiveOrder = async () => {
    if (!activeOrder) return;
    if (!confirm(`Encerrar e arquivar a OP ${activeOrder.order_number}? Os dados permanecerão no histórico.`)) return;
    const now = new Date().toISOString();
    const { error } = await supabase.from('production_orders').update({ status: 'archived', output_quantity: producaoHoje, completed_at: now, archived_at: now }).eq('id', activeOrder.id);
    if (error) setMsg({ ok: false, text: 'Não foi possível arquivar a OP.' });
    else {
      setOrders((previous) => previous.map((order) => order.id === activeOrder.id ? { ...order, status: 'archived', output_quantity: producaoHoje, completed_at: now, archived_at: now } : order));
      setMsg({ ok: true, text: `OP ${activeOrder.order_number} arquivada. O setor está liberado para uma nova OP.` });
    }
  };

  // Empty state: no sectors enabled
  if (enabledSectors.length === 0) {
    return (
      <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 border border-slate-700/50 overflow-hidden shadow-2xl">
        <div className="p-4 sm:p-6 border-b border-slate-700/50 bg-slate-900/60">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center animate-icon-glow" style={{ background: 'linear-gradient(135deg, #06b6d4, #0ea5e9)', boxShadow: '0 0 20px rgba(6,182,212,0.45)' }}>
                <Factory className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white">Gráfico de Produção por Setor</h3>
                <p className="text-[11px] sm:text-xs text-slate-400">Selecione quais setores usam o gráfico de produção</p>
              </div>
            </div>
          </div>
        </div>
        <div className="p-6 sm:p-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-slate-800/60 flex items-center justify-center mx-auto mb-4">
              <Settings className="w-8 h-8 text-slate-500 animate-icon-glow" />
            </div>
            <p className="text-sm text-slate-400 mb-2">Nenhum setor está usando o gráfico de produção ainda.</p>
            <p className="text-xs text-slate-500">Adicione setores que controlam produção (ex: Injeção, Montagem). Setores como Tratamento de Água não precisam ser adicionados.</p>
          </div>
          {/* Config panel inline */}
          <div className="rounded-2xl bg-slate-800/40 border border-slate-700/40 p-4">
            <p className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Plus className="w-4 h-4 text-cyan-400 animate-icon-glow" /> Adicionar setor ao gráfico
            </p>
            <div className="flex flex-col sm:flex-row gap-2 mb-4">
              <input
                type="text" value={newSectorName} onChange={(e) => setNewSectorName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && newSectorName.trim()) addSector(newSectorName); }}
                placeholder="Nome do setor (ex: Injeção)"
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
              />
              <button onClick={() => addSector(newSectorName)} disabled={!newSectorName.trim()}
                className="px-4 py-2.5 rounded-xl font-bold text-white text-sm transition-all duration-300 disabled:opacity-40 hover:scale-105 active:scale-95 whitespace-nowrap"
                style={{ background: 'linear-gradient(135deg, #06b6d4, #0ea5e9)' }}>
                Adicionar
              </button>
            </div>
            {allSectors.length > 0 && (
              <div className="space-y-2">
                <p className="text-[11px] text-slate-500">Setores disponíveis (clique para adicionar):</p>
                <div className="flex flex-wrap gap-2">
                  {allSectors.map((s) => (
                    <button key={s} onClick={() => addSector(s)}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800/60 border border-slate-700/50 hover:border-cyan-500/40 hover:text-cyan-300 transition flex items-center gap-1.5">
                      <Plus className="w-3 h-3" /> {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {msg && (
              <div className={`mt-3 text-xs font-medium flex items-center gap-1.5 ${msg.ok ? 'text-emerald-400' : 'text-rose-400'}`}>
                {msg.ok ? <CheckCircle2 className="w-3.5 h-3.5 animate-icon-glow" /> : <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />}
                {msg.text}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // SVG chart dimensions
  const chartW = 100;
  const chartH = 100;
  const padL = 10;
  const padR = 4;
  const padT = 8;
  const padB = 8;
  const plotW = chartW - padL - padR;
  const plotH = chartH - padT - padB;

  const xFor = (i: number) => padL + (chartData.length > 1 ? (i / (chartData.length - 1)) * plotW : plotW / 2);
  const yFor = (v: number) => padT + plotH - (v / yMax) * plotH;

  const linePoints = chartData.map((d, i) => ({ x: xFor(i), y: yFor(d.producao), ...d }));
  const linePath = linePoints.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(' ');
  const areaPath = `${linePath} L ${xFor(chartData.length - 1).toFixed(2)} ${(padT + plotH).toFixed(2)} L ${padL.toFixed(2)} ${(padT + plotH).toFixed(2)} Z`;
  const entradaPoints = chartData.map((d, i) => ({ x: xFor(i), y: yFor(d.entrada), ...d }));
  const entradaPath = entradaPoints.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(' ');
  const metaPath = chartData.map((d, i) => `${i === 0 ? 'M' : 'L'} ${xFor(i).toFixed(2)} ${yFor(d.meta).toFixed(2)}`).join(' ');

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 border border-slate-700/50 overflow-hidden shadow-2xl">
      {/* Header with title */}
      <div className="p-4 sm:p-6 border-b border-slate-700/50 bg-slate-900/60">
        <div className="flex items-center justify-between mb-4 sm:mb-5 flex-wrap gap-3">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center animate-icon-glow" style={{ background: `linear-gradient(135deg, ${sectorColor.from}, ${sectorColor.to})`, boxShadow: `0 0 20px ${sectorColor.glow}` }}>
              <Factory className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">Gráfico de Produção por Setor</h3>
              <p className="text-[11px] sm:text-xs text-slate-400">Entrada de OP · Produção por Hora · Eficiência Automática</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] sm:text-xs text-slate-400 flex items-center gap-1.5 bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
              <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> Tempo real
            </span>
            {canRegister && (
              <button onClick={() => setShowConfig(!showConfig)}
                className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/50 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40 transition">
                <Settings className={`w-4 h-4 animate-icon-glow ${showConfig ? 'text-cyan-400' : ''}`} />
              </button>
            )}
          </div>
        </div>

        {/* Sector tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          {enabledSectors.map((s, i) => {
            const c = SECTOR_COLORS[i % SECTOR_COLORS.length];
            const active = s === selectedSector;
            return (
              <button key={s} onClick={() => setSelectedSector(s)}
                className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all duration-300 border whitespace-nowrap flex-shrink-0 ${active ? 'text-white border-transparent scale-105 shadow-lg' : 'text-slate-400 border-slate-700/50 hover:text-slate-200 hover:border-slate-600'}`}
                style={active ? { background: `linear-gradient(135deg, ${c.from}, ${c.to})`, boxShadow: `0 0 20px ${c.glow}` } : {}}>
                {s}
              </button>
            );
          })}
        </div>

        {/* Config panel — toggle sectors on/off */}
        {showConfig && (
          <div className="mt-4 rounded-2xl bg-slate-800/40 border border-slate-700/40 p-4 animate-area-fade">
            <p className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Settings className="w-4 h-4 text-cyan-400 animate-icon-glow" /> Gerenciar setores no gráfico
            </p>
            <div className="flex flex-col sm:flex-row gap-2 mb-4">
              <input type="text" value={newSectorName} onChange={(e) => setNewSectorName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && newSectorName.trim()) addSector(newSectorName); }}
                placeholder="Nome do setor (ex: Injeção)"
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition" />
              <button onClick={() => addSector(newSectorName)} disabled={!newSectorName.trim()}
                className="px-4 py-2.5 rounded-xl font-bold text-white text-sm transition-all duration-300 disabled:opacity-40 hover:scale-105 active:scale-95 whitespace-nowrap"
                style={{ background: 'linear-gradient(135deg, #06b6d4, #0ea5e9)' }}>
                <Plus className="w-4 h-4 inline mr-1" /> Adicionar
              </button>
            </div>
            <div className="space-y-2">
              <p className="text-[11px] text-slate-500">Setores ativos no gráfico (clique no X para remover):</p>
              <div className="flex flex-wrap gap-2">
                {enabledSectors.map((s) => (
                  <span key={s} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-cyan-300 bg-cyan-500/10 border border-cyan-500/20">
                    {s}
                    <button onClick={() => removeSector(s)} className="hover:text-rose-400 transition">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
              </div>
              {allSectors.filter((s) => !enabledSectors.includes(s)).length > 0 && (
                <>
                  <p className="text-[11px] text-slate-500 mt-3">Setores disponíveis:</p>
                  <div className="flex flex-wrap gap-2">
                    {allSectors.filter((s) => !enabledSectors.includes(s)).map((s) => (
                      <button key={s} onClick={() => addSector(s)}
                        className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800/60 border border-slate-700/50 hover:border-cyan-500/40 hover:text-cyan-300 transition flex items-center gap-1.5">
                        <Plus className="w-3 h-3" /> {s}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3 p-4 sm:p-6">
        <KpiCard icon={ArrowDownToLine} label="Entrada de OP" value={entradaOpHoje} sub="peças" color="#06b6d4" />
        <KpiCard icon={Zap} label="Produção (Hoje)" value={producaoHoje} sub="peças" color="#f59e0b" />
        <KpiCard icon={AlertTriangle} label="Ficou para trás" value={backlogHoje} sub={backlogHoje === 0 ? 'em dia' : 'pendentes'} color={backlogHoje > 0 ? '#ef4444' : '#10b981'} pulse={backlogHoje > 0} />
        <KpiCard icon={Gauge} label="Eficiência" value={efficiency} sub="%" color={efficiency >= 90 ? '#10b981' : efficiency >= 70 ? '#f59e0b' : '#ef4444'} />
      </div>

      {/* Secondary KPIs + circular progress */}
      <div className="px-4 sm:px-6 pb-3 grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
        <MiniKpi icon={BarChart3} label="Produção da semana" value={totalThisWeek} color={sectorColor.from} />
        <MiniKpi icon={TrendingUp} label="Produção do mês" value={totalThisMonth} color={sectorColor.from} />
        <div className="rounded-xl bg-slate-800/50 border border-slate-700/40 p-3 flex items-center gap-3">
          <div className="relative w-12 h-12 flex-shrink-0">
            <svg viewBox="0 0 48 48" className="w-full h-full -rotate-90">
              <circle cx="24" cy="24" r="20" fill="none" stroke="#1e293b" strokeWidth="4" />
              <circle cx="24" cy="24" r="20" fill="none" strokeWidth="4" strokeLinecap="round"
                stroke={`url(#progGrad-${sectorColor.from.replace('#', '')})`}
                strokeDasharray={`${(efficiency / 100) * 125.66} 125.66`}
                className="transition-all duration-1000 ease-out"
                style={{ filter: `drop-shadow(0 0 4px ${sectorColor.glow})` }} />
              <defs>
                <linearGradient id={`progGrad-${sectorColor.from.replace('#', '')}`} x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor={sectorColor.from} />
                  <stop offset="100%" stopColor={sectorColor.to} />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <Gauge className="w-4 h-4 animate-icon-glow" style={{ color: sectorColor.from }} />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[11px] text-slate-400 font-medium block">Progresso da OP</span>
            <span className="text-sm font-black" style={{ color: efficiency >= 90 ? '#10b981' : efficiency >= 70 ? '#f59e0b' : '#ef4444' }}>{efficiency}%</span>
          </div>
        </div>
      </div>

      {/* OP Status badge */}
      {activeOrder && (
        <div className="px-4 sm:px-6 pb-3">
          <div className={`flex flex-wrap items-center justify-between gap-3 px-4 py-3 rounded-xl border ${activeOrder.status === 'paused' ? 'bg-amber-500/10 border-amber-500/30' : 'bg-cyan-500/10 border-cyan-500/30'}`}>
            <div className="flex items-center gap-3">
              {activeOrder.status === 'paused' ? <Pause className="w-5 h-5 text-amber-300 animate-pulse" /> : <Play className="w-5 h-5 text-cyan-300 animate-pulse" />}
              <div><p className="text-sm font-black text-white">OP {activeOrder.order_number}</p><p className="text-[11px] text-slate-400">{activeOrder.status === 'paused' ? 'Pausada' : 'Em produção'} · iniciada em {new Date(activeOrder.started_at).toLocaleString('pt-BR')}</p></div>
            </div>
            {canRegister && <div className="flex gap-2"><button onClick={togglePause} className="px-3 py-2 rounded-lg text-xs font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">{activeOrder.status === 'paused' ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}{activeOrder.status === 'paused' ? 'Retomar' : 'Pausar'}</button><button onClick={archiveOrder} className="px-3 py-2 rounded-lg text-xs font-bold bg-violet-500/15 text-violet-300 border border-violet-500/30 flex items-center gap-1.5"><Archive className="w-3.5 h-3.5" />Encerrar e arquivar</button></div>}
          </div>
        </div>
      )}

      {/* Range selector + chart mode toggle */}
      <div className="px-4 sm:px-6 pb-3 flex flex-wrap items-center gap-2">
        <div className="inline-flex items-center gap-1 bg-slate-800/60 rounded-lg p-1 overflow-x-auto max-w-full">
          {(['hora', 'dia', 'semana', 'mes'] as Range[]).map((r) => (
            <button key={r} onClick={() => setRange(r)}
              className={`px-3 sm:px-3.5 py-1.5 rounded-md text-xs font-medium transition whitespace-nowrap ${range === r ? 'text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
              style={range === r ? { background: `linear-gradient(135deg, ${sectorColor.from}, ${sectorColor.to})` } : {}}>
              {r === 'hora' ? 'Por hora' : r === 'dia' ? 'Por dia' : r === 'semana' ? 'Por semana' : 'Por mês'}
            </button>
          ))}
        </div>
        <div className="inline-flex items-center gap-1 bg-slate-800/60 rounded-lg p-1">
          {([['combo', BarChart2], ['bars', BarChart3], ['line', LineIcon]] as const).map(([mode, Icon]) => (
            <button key={mode} onClick={() => setChartMode(mode)}
              className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition ${chartMode === mode ? 'text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
              style={chartMode === mode ? { background: `linear-gradient(135deg, ${sectorColor.from}, ${sectorColor.to})` } : {}}>
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>
      </div>

      {/* Animated SVG chart — alternating bars, line, and combo */}
      <div className="px-4 sm:px-6 pb-4 sm:pb-6">
        <div className="relative w-full">
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-56 sm:h-72">
            <defs>
              <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={sectorColor.from} stopOpacity="0.35" />
                <stop offset="100%" stopColor={sectorColor.from} stopOpacity="0" />
              </linearGradient>
              <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={sectorColor.from} />
                <stop offset="100%" stopColor={sectorColor.to} />
              </linearGradient>
              <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={sectorColor.to} stopOpacity="0.9" />
                <stop offset="100%" stopColor={sectorColor.from} stopOpacity="0.4" />
              </linearGradient>
              <filter id="lineGlow">
                <feGaussianBlur stdDeviation="0.8" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
            </defs>

            {/* Grid lines (horizontal) */}
            {Array.from({ length: yTicks + 1 }, (_, i) => {
              const val = i * yStep;
              const y = yFor(val);
              return (
                <g key={`grid-${i}`}>
                  <line x1={padL} y1={y} x2={chartW - padR} y2={y} stroke="#1e293b" strokeWidth="0.2" vectorEffect="non-scaling-stroke" />
                  <text x={padL - 1.5} y={y + 1} fontSize="2.5" fill="#64748b" textAnchor="end" vectorEffect="non-scaling-stroke" className="tabular-nums">
                    {val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val}
                  </text>
                </g>
              );
            })}

            {/* Vertical grid lines */}
            {chartData.map((_, i) => (
              <line key={`vgrid-${i}`} x1={xFor(i)} y1={padT} x2={xFor(i)} y2={padT + plotH} stroke="#1e293b" strokeWidth="0.15" vectorEffect="non-scaling-stroke" opacity="0.5" />
            ))}

            {/* Y-axis */}
            <line x1={padL} y1={padT} x2={padL} y2={padT + plotH} stroke="#334155" strokeWidth="0.3" vectorEffect="non-scaling-stroke" />
            {/* X-axis */}
            <line x1={padL} y1={padT + plotH} x2={chartW - padR} y2={padT + plotH} stroke="#334155" strokeWidth="0.3" vectorEffect="non-scaling-stroke" />

            {/* Bars (shown in bars/combo mode) */}
            {(chartMode === 'bars' || chartMode === 'combo') && chartData.map((d, i) => {
              if (d.producao <= 0) return null;
              const barW = (chartW - padL - padR) / chartData.length * 0.55;
              const cx = xFor(i);
              const barH = padT + plotH - yFor(d.producao);
              const by = yFor(d.producao);
              const barColor = SECTOR_COLORS[i % SECTOR_COLORS.length];
              return (
                <g key={`bar-${i}`}>
                  <rect x={cx - barW / 2} y={by} width={barW} height={Math.max(0, barH)} rx="0.8"
                    fill={`url(#barGrad-${i})`} className="animate-bar-grow"
                    style={{ animationDelay: `${i * 0.06}s` }} vectorEffect="non-scaling-stroke" />
                  <text x={cx} y={by - 1.5} fontSize="2.5" fill={barColor.to} textAnchor="middle" vectorEffect="non-scaling-stroke"
                    className="font-bold tabular-nums animate-point-pop" style={{ animationDelay: `${i * 0.06 + 0.2}s` }}>
                    {d.producao >= 1000 ? `${(d.producao / 1000).toFixed(1)}k` : d.producao}
                  </text>
                  <defs>
                    <linearGradient id={`barGrad-${i}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={barColor.to} stopOpacity="0.9" />
                      <stop offset="100%" stopColor={barColor.from} stopOpacity="0.3" />
                    </linearGradient>
                  </defs>
                </g>
              );
            })}

            {/* Area fill under line (shown in line/combo mode) */}
            {(chartMode === 'line' || chartMode === 'combo') && (
              <path d={areaPath} fill="url(#areaGrad)" className="animate-area-fade" />
            )}

            {/* Entrada de OP line (dashed cyan) — always shown */}
            {chartData.some((d) => d.entrada > 0) && (
              <path d={entradaPath} fill="none" stroke="#06b6d4" strokeWidth="0.6" strokeDasharray="1.5 1" vectorEffect="non-scaling-stroke" opacity="0.7" />
            )}

            {/* Meta horária da OP — linha de referência estilo BI */}
            {range === 'hora' && chartData.some((d) => d.meta > 0) && (
              <path d={metaPath} fill="none" stroke="#facc15" strokeWidth="0.7" strokeDasharray="2 1" vectorEffect="non-scaling-stroke" opacity="0.9" className="animate-line-draw" />
            )}

            {/* Animated production line (shown in line/combo mode) */}
            {(chartMode === 'line' || chartMode === 'combo') && (
              <>
                <path d={linePath} fill="none" stroke="url(#lineGrad)" strokeWidth="1.2" vectorEffect="non-scaling-stroke"
                  className="animate-line-draw" filter="url(#lineGlow)" strokeLinecap="round" strokeLinejoin="round" />
                {linePoints.map((p, i) => (
                  <g key={`pt-${i}`}>
                    <circle cx={p.x} cy={p.y} r={i === linePoints.length - 1 && p.producao > 0 ? 1.5 : 1} fill={sectorColor.to}
                      stroke="#0f172a" strokeWidth="0.3" vectorEffect="non-scaling-stroke"
                      className="animate-point-pop" style={{ animationDelay: `${i * 0.08}s` }} />
                    {i === linePoints.length - 1 && p.producao > 0 && (
                      <circle cx={p.x} cy={p.y} r="2.5" fill="none" stroke={sectorColor.to} strokeWidth="0.4" vectorEffect="non-scaling-stroke" opacity="0.4" className="animate-pulse" />
                    )}
                  </g>
                ))}
              </>
            )}
          </svg>

          {/* X-axis labels */}
          <div className="flex justify-between mt-1 px-2" style={{ paddingLeft: '8%', paddingRight: '3%' }}>
            {chartData.map((d, i) => (
              <span key={i} className="text-[9px] sm:text-[11px] text-slate-400 capitalize text-center flex-1 truncate">{d.label}</span>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-4 sm:gap-6 mt-3 sm:mt-4 flex-wrap">
          {(chartMode === 'line' || chartMode === 'combo') && (
            <span className="text-[11px] sm:text-xs text-slate-300 flex items-center gap-2">
              <span className="w-4 h-0.5 rounded-full" style={{ background: `linear-gradient(90deg, ${sectorColor.from}, ${sectorColor.to})` }} /> Produção (linha)
            </span>
          )}
          {(chartMode === 'bars' || chartMode === 'combo') && (
            <span className="text-[11px] sm:text-xs text-slate-300 flex items-center gap-2">
              <span className="w-3 h-3 rounded" style={{ background: `linear-gradient(180deg, ${sectorColor.to}, ${sectorColor.from})` }} /> Produção (barras)
            </span>
          )}
          {chartData.some((d) => d.entrada > 0) && (
            <span className="text-[11px] sm:text-xs text-slate-300 flex items-center gap-2">
              <span className="w-4 h-0.5 rounded-full bg-cyan-400" style={{ borderTop: '1px dashed #06b6d4' }} /> Entrada de OP
            </span>
          )}
          {range === 'hora' && chartData.some((d) => d.meta > 0) && (
            <span className="text-[11px] sm:text-xs text-slate-300 flex items-center gap-2"><span className="w-4 h-0.5 border-t border-dashed border-yellow-300" /> Meta por hora ({activeOrder?.target_per_hour})</span>
          )}
        </div>
        <p className="text-[11px] sm:text-xs text-slate-500 mt-2 text-center">
          {range === 'hora' ? 'Produção por hora (últimas 12 horas)' : range === 'dia' ? 'Produção por dia (últimos 7 dias)' : range === 'semana' ? 'Produção por semana (últimas 6 semanas)' : 'Produção por mês (últimos 6 meses)'}
        </p>
      </div>

      {/* Two-button registration form */}
      <div className="border-t border-slate-700/50 p-4 sm:p-6 bg-slate-900/60">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
          {/* Entrada de OP */}
          <div className="rounded-2xl bg-slate-800/40 border border-cyan-500/20 p-3 sm:p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-cyan-500/20">
                <Package className="w-4 h-4 text-cyan-400 animate-icon-glow" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Entrada de OP</p>
                <p className="text-[11px] text-slate-400">Registrada uma vez até finalizar a OP</p>
              </div>
            </div>
            {canRegister ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-2">
                  <input type="text" value={opNumber} onChange={(e) => setOpNumber(e.target.value)} placeholder="Número da OP" disabled={Boolean(activeOrder)} className="px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 disabled:opacity-50" />
                  <input type="number" inputMode="numeric" min={0} value={opInput}
                    onChange={(e) => setOpInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter' && !submittingOp) submitOp(); }}
                    placeholder="Quantidade de entrada" disabled={Boolean(activeOrder)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition disabled:opacity-50" />
                  <input type="number" inputMode="numeric" min={0} value={targetPerHour} onChange={(e) => setTargetPerHour(e.target.value)} placeholder="Meta por hora" disabled={Boolean(activeOrder)} className="px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 disabled:opacity-50" />
                </div>
                <button onClick={submitOp} disabled={submittingOp || !opInput || !opNumber.trim() || Boolean(activeOrder)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl font-bold text-white text-sm transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed hover:scale-105 active:scale-95 whitespace-nowrap"
                    style={{ background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)', boxShadow: opInput && !activeOrder ? '0 0 20px rgba(6,182,212,0.4)' : 'none' }}>
                    {submittingOp ? 'Iniciando...' : 'Iniciar nova OP'}
                </button>
                {activeOrder && (
                  <p className="text-xs text-cyan-400 mt-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 animate-icon-glow" /> OP ativa: {activeOrder.order_number} · {entradaOpHoje} peças
                  </p>
                )}
              </>
            ) : (
              <p className="text-xs text-slate-500 flex items-center gap-1.5 py-2">
                <Settings className="w-3.5 h-3.5" /> Apenas CEO, Gerente, Supervisor, Líder e Encarregado podem registrar produção.
              </p>
            )}
          </div>

          {/* Produção por Hora */}
          <div className="rounded-2xl bg-slate-800/40 border p-3 sm:p-4" style={{ borderColor: `${sectorColor.from}30` }}>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${sectorColor.from}20` }}>
                <Clock className="w-4 h-4 animate-icon-glow" style={{ color: sectorColor.from }} />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Produção da Hora</p>
                <p className="text-[11px] text-slate-400">Registrada de hora em hora pelo supervisor</p>
              </div>
            </div>
            {canRegister ? (
              <>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input type="number" inputMode="numeric" min={0} value={hourUnits}
                    onChange={(e) => setHourUnits(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter' && !submittingHour) submitHour(); }}
                    placeholder="Peças produzidas nesta hora" disabled={!activeOrder || activeOrder.status === 'paused'}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900/80 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none transition disabled:opacity-50"
                    style={{ boxShadow: hourUnits ? `0 0 0 1px ${sectorColor.from}40` : 'none' }} />
                  <button onClick={submitHour} disabled={submittingHour || !hourUnits || !activeOrder || activeOrder.status === 'paused'}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl font-bold text-white text-sm transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed hover:scale-105 active:scale-95 whitespace-nowrap"
                    style={{ background: `linear-gradient(135deg, ${sectorColor.from}, ${sectorColor.to})`, boxShadow: hourUnits && entradaOpHoje > 0 ? `0 0 16px ${sectorColor.glow}` : 'none' }}>
                    {submittingHour ? '...' : 'Registrar'}
                  </button>
                </div>
                {!activeOrder && (
                  <p className="text-xs text-amber-400 mt-2 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 animate-pulse" /> Registre a Entrada de OP primeiro
                  </p>
                )}
                {activeOrder && (
                  <p className="text-xs mt-2 flex items-center gap-1.5" style={{ color: sectorColor.from }}>
                    <Zap className="w-3.5 h-3.5 animate-icon-glow" /> {producaoHoje} / {entradaOpHoje} peças · média {hourlyAverage}/h · meta {activeOrder.target_per_hour || '—'}/h
                  </p>
                )}
              </>
            ) : (
              <p className="text-xs text-slate-500 flex items-center gap-1.5 py-2">
                <Settings className="w-3.5 h-3.5" /> Apenas CEO, Gerente, Supervisor, Líder e Encarregado podem registrar produção.
              </p>
            )}
          </div>
        </div>

        {archivedOrders.length > 0 && (
          <div className="mt-4 rounded-2xl bg-gradient-to-r from-violet-500/10 via-slate-800/50 to-cyan-500/10 border border-violet-500/20 p-4">
            <div className="flex items-center gap-2 mb-3"><History className="w-4 h-4 text-violet-300 animate-icon-glow" /><p className="text-sm font-bold text-white">Histórico de OPs arquivadas</p><span className="text-[10px] px-2 py-0.5 rounded-full bg-violet-500/15 text-violet-300">{archivedOrders.length}</span></div>
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-2">
              {archivedOrders.slice(0, 6).map((order) => {
                const archivedLogs = sectorProd.filter((log) => log.production_order_id === order.id);
                const produced = archivedLogs.reduce((sum, log) => sum + (log.units_produced || 0), 0);
                const archivedEfficiency = order.input_quantity ? Math.min(100, Math.round(produced / order.input_quantity * 100)) : 0;
                return <div key={order.id} className="rounded-xl bg-slate-950/45 border border-slate-700/40 p-3 hover:border-violet-500/40 transition">
                  <div className="flex justify-between gap-2"><p className="text-sm font-black text-white">OP {order.order_number}</p><span className="text-xs font-bold text-emerald-300">{archivedEfficiency}%</span></div>
                  <div className="mt-2 h-1.5 rounded-full bg-slate-800 overflow-hidden"><div className="h-full rounded-full bg-gradient-to-r from-violet-500 via-cyan-400 to-emerald-400 transition-all duration-1000" style={{ width: `${archivedEfficiency}%` }} /></div>
                  <p className="text-[11px] text-slate-400 mt-2">{produced.toLocaleString('pt-BR')} de {order.input_quantity.toLocaleString('pt-BR')} peças</p>
                  <p className="text-[10px] text-slate-500 mt-1">Arquivada em {new Date(order.archived_at || order.updated_at).toLocaleString('pt-BR')}</p>
                </div>;
              })}
            </div>
          </div>
        )}

        {msg && (
          <div className={`mt-3 text-xs font-medium flex items-center gap-1.5 ${msg.ok ? 'text-emerald-400' : 'text-rose-400'}`}>
            {msg.ok ? <CheckCircle2 className="w-3.5 h-3.5 animate-icon-glow" /> : <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />}
            {msg.text}
          </div>
        )}
        {backlogHoje > 0 && (
          <div className="mt-3 flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-2">
            <AlertTriangle className="w-3.5 h-3.5 animate-pulse flex-shrink-0" />
            <span>Atenção: {backlogHoje} peça(s) da Entrada de OP ainda não foram produzidas.</span>
          </div>
        )}
      </div>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, sub, color, pulse }: { icon: typeof Clock; label: string; value: number; sub: string; color: string; pulse?: boolean }) {
  return (
    <div className="rounded-xl sm:rounded-2xl bg-slate-800/50 border border-slate-700/40 p-3 sm:p-4 transition-all duration-300 hover:border-slate-600/60 hover:bg-slate-800/70 relative overflow-hidden">
      <div className="absolute -top-4 -right-4 w-16 sm:w-20 h-16 sm:h-20 rounded-full opacity-10" style={{ background: `radial-gradient(circle, ${color}, transparent 70%)` }} />
      <div className="flex items-center gap-1.5 mb-2">
        <div className={`w-6 sm:w-7 h-6 sm:h-7 rounded-lg flex items-center justify-center ${pulse ? 'animate-pulse' : 'animate-icon-glow'}`} style={{ background: `${color}20` }}>
          <Icon className="w-3.5 sm:w-4 sm:h-4 h-3.5" style={{ color }} />
        </div>
        <span className="text-[10px] sm:text-[11px] text-slate-400 font-medium leading-tight">{label}</span>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className="text-xl sm:text-2xl font-black text-white tabular-nums">{value.toLocaleString('pt-BR')}</span>
        <span className="text-[11px] sm:text-xs text-slate-500">{sub}</span>
      </div>
    </div>
  );
}

function MiniKpi({ icon: Icon, label, value, color }: { icon: typeof Clock; label: string; value: number; color: string }) {
  return (
    <div className="rounded-xl bg-slate-800/50 border border-slate-700/40 p-3">
      <div className="flex items-center gap-1.5 mb-1">
        <Icon className="w-3.5 h-3.5 animate-icon-glow" style={{ color }} />
        <span className="text-[11px] text-slate-400 font-medium">{label}</span>
      </div>
      <span className="text-lg sm:text-xl font-black text-white tabular-nums">{value.toLocaleString('pt-BR')}</span>
    </div>
  );
}
