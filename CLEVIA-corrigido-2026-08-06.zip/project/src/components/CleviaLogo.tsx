import { useState, useEffect, type ReactNode } from 'react';

export type LogoVariant = 'whitec' | 'hexshield' | 'gearorbit' | 'bolt' | 'minimal' | 'cube3d';

const STORAGE_KEY = 'clevia-logo-variant-v2';

export function getChosenLogo(): LogoVariant {
  if (typeof localStorage !== 'undefined') {
    const v = localStorage.getItem(STORAGE_KEY) as LogoVariant | null;
    if (v && ['whitec', 'hexshield', 'gearorbit', 'bolt', 'minimal', 'cube3d'].includes(v)) return v;
  }
  return 'gearorbit';
}

export function setChosenLogo(v: LogoVariant) {
  localStorage.setItem(STORAGE_KEY, v);
  window.dispatchEvent(new Event('clevia-logo-changed'));
  applyPwaIcon(v);
}

let manifestUrl: string | null = null;

export function applyPwaIcon(variant: LogoVariant) {
  const manifest = {
    name: 'CLEVIA Plataforma - Inteligente de Gestão Industrial e Manutenção',
    short_name: 'CLEVIA',
    description: 'Gestão de manutenção industrial: ordens de serviço, preventivas, conformidade e indicadores.',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    display_override: 'standalone',
    orientation: 'portrait',
    background_color: '#0f172a',
    theme_color: '#0ea5e9',
    categories: ['business', 'productivity', 'industrial'],
    icons: [
      { src: `/logos/${variant}-192.png`, sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: `/logos/${variant}-192.png`, sizes: '192x192', type: 'image/png', purpose: 'maskable' },
      { src: `/logos/${variant}-512.png`, sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: `/logos/${variant}-512.png`, sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };

  const blob = new Blob([JSON.stringify(manifest)], { type: 'application/manifest+json' });
  const url = URL.createObjectURL(blob);
  let link = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
  if (!link) {
    link = document.createElement('link');
    link.rel = 'manifest';
    document.head.appendChild(link);
  }
  link.href = url;
  if (manifestUrl) URL.revokeObjectURL(manifestUrl);
  manifestUrl = url;

  const apple = document.querySelector<HTMLLinkElement>('link[rel="apple-touch-icon"]');
  if (apple) apple.href = `/logos/${variant}-192.png`;
  const favicon = document.querySelector<HTMLLinkElement>('link[rel="icon"][type="image/svg+xml"]');
  if (favicon) favicon.href = `/logos/${variant}.svg`;
}

export function useChosenLogo(): LogoVariant {
  const [variant, setVariant] = useState<LogoVariant>(getChosenLogo);
  useEffect(() => {
    const handler = () => setVariant(getChosenLogo());
    window.addEventListener('clevia-logo-changed', handler);
    return () => window.removeEventListener('clevia-logo-changed', handler);
  }, []);
  return variant;
}

/* ============ Variant 0: White C (default) ============ */
function WhiteCLogo({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} style={{ width: size, height: size }} aria-label="CLEVIA">
      <defs>
        <linearGradient id="wc-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#0f172a" /><stop offset="100%" stopColor="#020617" /></linearGradient>
        <filter id="wc-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="6" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
      <rect x="0" y="0" width="512" height="512" rx="112" fill="url(#wc-bg)" />
      <rect x="0" y="0" width="512" height="256" rx="112" fill="#fff" opacity="0.03" />
      <rect x="0" y="0" width="512" height="512" rx="112" fill="none" stroke="#1e293b" strokeWidth="2" />
      <g filter="url(#wc-glow)"><path d="M350 165 C320 135 280 120 235 125 C175 132 130 170 115 225 C100 280 120 335 165 370 C205 400 260 405 305 385 C330 373 350 355 365 335" fill="none" stroke="#ffffff" strokeWidth="42" strokeLinecap="round" /></g>
      <circle cx="256" cy="256" r="14" fill="#38bdf8" filter="url(#wc-glow)" />
    </svg>
  );
}

/* ============ Variant 1: Hex Shield ============ */
function HexShield({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} style={{ width: size, height: size }} aria-label="CLEVIA">
      <defs>
        <linearGradient id="hs-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#0ea5e9" /><stop offset="45%" stopColor="#2563eb" /><stop offset="100%" stopColor="#0c1d4d" />
        </linearGradient>
        <linearGradient id="hs-stroke" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#a5f3fc" /><stop offset="50%" stopColor="#38bdf8" /><stop offset="100%" stopColor="#0284c7" />
        </linearGradient>
        <linearGradient id="hs-accent" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#fde047" /><stop offset="100%" stopColor="#f59e0b" /></linearGradient>
        <filter id="hs-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="8" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        <filter id="hs-shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="#0c1d4d" floodOpacity="0.6" /></filter>
      </defs>
      <g filter="url(#hs-shadow)"><path d="M256 28 L448 140 L448 372 L256 484 L64 372 L64 140 Z" fill="url(#hs-bg)" /></g>
      <path d="M256 28 L448 140 L256 200 L64 140 Z" fill="#fff" opacity="0.08" />
      <path d="M256 48 L430 150 L430 362 L256 464 L82 362 L82 150 Z" fill="none" stroke="#7dd3fc" strokeWidth="2" opacity="0.3" />
      <g filter="url(#hs-glow)"><path d="M330 160 C300 140 270 130 240 132 C190 136 150 166 132 210 C114 254 122 304 152 340 C182 376 228 392 272 384 C300 379 324 366 342 348" fill="none" stroke="url(#hs-stroke)" strokeWidth="38" strokeLinecap="round" /></g>
      <circle cx="330" cy="160" r="18" fill="url(#hs-stroke)" filter="url(#hs-glow)" />
      <circle cx="342" cy="348" r="14" fill="#38bdf8" />
      <circle cx="152" cy="340" r="11" fill="#7dd3fc" opacity="0.85" />
      <circle cx="256" cy="256" r="16" fill="url(#hs-accent)" filter="url(#hs-glow)" />
      <g fill="#fde047" opacity="0.95"><path d="M400 210 l4.5 13 13 4.5 -13 4.5 -4.5 13 -4.5 -13 -13 -4.5 13 -4.5 z" /><path d="M118 310 l3.5 10 10 3.5 -10 3.5 -3.5 10 -3.5 -10 -10 -3.5 10 -3.5 z" opacity="0.75" /></g>
    </svg>
  );
}

/* ============ Variant 2: Gear Orbit ============ */
function GearOrbit({ size }: { size: number }) {
  const teeth = Array.from({ length: 12 }, (_, i) => {
    const a = (i * 30) * Math.PI / 180;
    return { x: 256 + Math.cos(a) * 200, y: 256 + Math.sin(a) * 200, a };
  });
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} style={{ width: size, height: size }} aria-label="CLEVIA">
      <defs>
        <linearGradient id="go-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#1e293b" /><stop offset="100%" stopColor="#020617" /></linearGradient>
        <linearGradient id="go-ring" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#22d3ee" /><stop offset="50%" stopColor="#3b82f6" /><stop offset="100%" stopColor="#1d4ed8" /></linearGradient>
        <linearGradient id="go-c" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#67e8f9" /><stop offset="100%" stopColor="#0284c7" /></linearGradient>
        <radialGradient id="go-core" cx="0.5" cy="0.4"><stop offset="0%" stopColor="#38bdf8" /><stop offset="100%" stopColor="#0c4a6e" /></radialGradient>
        <filter id="go-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="6" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
      <circle cx="256" cy="256" r="240" fill="url(#go-bg)" />
      {teeth.map((t, i) => (
        <rect key={i} x={t.x - 16} y={t.y - 28} width="32" height="56" rx="6" fill="url(#go-ring)" transform={`rotate(${i * 30 + 90} ${t.x} ${t.y})`} filter="url(#go-glow)" />
      ))}
      <circle cx="256" cy="256" r="200" fill="none" stroke="url(#go-ring)" strokeWidth="6" opacity="0.5" />
      <circle cx="256" cy="256" r="155" fill="url(#go-core)" filter="url(#go-glow)" />
      <circle cx="256" cy="256" r="155" fill="none" stroke="#7dd3fc" strokeWidth="2" opacity="0.4" />
      <path d="M310 190 C290 170 260 160 230 165 C185 173 150 205 140 250 C130 295 150 340 190 365 C230 390 280 385 315 355" fill="none" stroke="url(#go-c)" strokeWidth="30" strokeLinecap="round" />
      <circle cx="256" cy="256" r="12" fill="#fde047" filter="url(#go-glow)" />
    </svg>
  );
}

/* ============ Variant 3: Bolt ============ */
function BoltLogo({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} style={{ width: size, height: size }} aria-label="CLEVIA">
      <defs>
        <linearGradient id="bl-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#0c4a6e" /><stop offset="100%" stopColor="#020617" /></linearGradient>
        <linearGradient id="bl-bolt" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#fbbf24" /><stop offset="50%" stopColor="#f59e0b" /><stop offset="100%" stopColor="#d97706" /></linearGradient>
        <linearGradient id="bl-c" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#22d3ee" /><stop offset="100%" stopColor="#2563eb" /></linearGradient>
        <filter id="bl-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="10" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        <filter id="bl-shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="4" stdDeviation="8" floodColor="#000" floodOpacity="0.5" /></filter>
      </defs>
      <rect x="32" y="32" width="448" height="448" rx="100" fill="url(#bl-bg)" filter="url(#bl-shadow)" />
      <rect x="32" y="32" width="448" height="224" rx="100" fill="#fff" opacity="0.04" />
      <rect x="32" y="32" width="448" height="448" rx="100" fill="none" stroke="#1e3a5f" strokeWidth="2" />
      {/* Lightning bolt */}
      <g filter="url(#bl-glow)">
        <path d="M280 80 L180 260 L250 260 L220 432 L340 220 L265 220 L300 80 Z" fill="url(#bl-bolt)" stroke="#fde68a" strokeWidth="2" strokeLinejoin="round" />
      </g>
      {/* C arc overlay */}
      <path d="M340 170 C320 150 290 140 260 145 C215 153 180 185 170 230 C160 275 180 320 220 345 C255 365 295 363 325 343" fill="none" stroke="url(#bl-c)" strokeWidth="16" strokeLinecap="round" opacity="0.9" />
      <circle cx="256" cy="256" r="8" fill="#22d3ee" filter="url(#bl-glow)" />
    </svg>
  );
}

/* ============ Variant 4: Minimal ============ */
function MinimalLogo({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} style={{ width: size, height: size }} aria-label="CLEVIA">
      <defs>
        <linearGradient id="mn-grad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#0ea5e9" /><stop offset="100%" stopColor="#1e3a8a" /></linearGradient>
        <linearGradient id="mn-accent" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#38bdf8" /><stop offset="100%" stopColor="#0284c7" /></linearGradient>
      </defs>
      <rect x="48" y="48" width="416" height="416" rx="24" fill="#020617" />
      <rect x="48" y="48" width="416" height="416" rx="24" fill="url(#mn-grad)" opacity="0.08" />
      <rect x="48" y="48" width="416" height="416" rx="24" fill="none" stroke="#1e293b" strokeWidth="2" />
      {/* Clean geometric C */}
      <path d="M340 160 C310 130 270 115 225 120 C170 127 125 165 110 220 C95 275 115 335 160 370 C200 400 255 405 300 385 C325 373 345 355 360 335" fill="none" stroke="url(#mn-grad)" strokeWidth="44" strokeLinecap="round" />
      {/* Inner accent arc */}
      <path d="M310 195 C290 175 260 165 230 170 C190 177 160 200 150 235 C140 270 155 310 185 335 C210 355 245 360 275 350" fill="none" stroke="url(#mn-accent)" strokeWidth="10" strokeLinecap="round" opacity="0.6" />
      {/* Dot */}
      <circle cx="256" cy="256" r="14" fill="#fde047" />
      <circle cx="256" cy="256" r="14" fill="none" stroke="#fbbf24" strokeWidth="1" opacity="0.5" />
    </svg>
  );
}

/* ============ Variant 5: Cube 3D ============ */
function Cube3DLogo({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 512 512" width={size} height={size} style={{ width: size, height: size }} aria-label="CLEVIA">
      <defs>
        <linearGradient id="cb-top" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#38bdf8" /><stop offset="100%" stopColor="#0ea5e9" /></linearGradient>
        <linearGradient id="cb-left" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#1e40af" /><stop offset="100%" stopColor="#1d4ed8" /></linearGradient>
        <linearGradient id="cb-right" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#2563eb" /><stop offset="100%" stopColor="#1e3a8a" /></linearGradient>
        <linearGradient id="cb-c" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#a5f3fc" /><stop offset="100%" stopColor="#7dd3fc" /></linearGradient>
        <filter id="cb-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="6" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
        <filter id="cb-shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="8" stdDeviation="14" floodColor="#020617" floodOpacity="0.7" /></filter>
      </defs>
      <g filter="url(#cb-shadow)">
        {/* Top face */}
        <path d="M256 60 L420 150 L256 240 L92 150 Z" fill="url(#cb-top)" />
        {/* Left face */}
        <path d="M92 150 L256 240 L256 440 L92 350 Z" fill="url(#cb-left)" />
        {/* Right face */}
        <path d="M420 150 L256 240 L256 440 L420 350 Z" fill="url(#cb-right)" />
      </g>
      {/* Edges */}
      <path d="M256 60 L420 150 L256 240 L92 150 Z" fill="none" stroke="#7dd3fc" strokeWidth="2" opacity="0.5" />
      <path d="M92 150 L256 240 L256 440" fill="none" stroke="#3b82f6" strokeWidth="2" opacity="0.4" />
      <path d="M420 150 L256 240 L256 440" fill="none" stroke="#3b82f6" strokeWidth="2" opacity="0.4" />
      {/* C on top face */}
      <g filter="url(#cb-glow)" transform="translate(256,150)">
        <path d="M50 -30 C35 -50 10 -60 -20 -55 C-55 -48 -80 -20 -85 15 C-90 50 -70 85 -35 100 C-5 112 25 108 48 92" fill="none" stroke="url(#cb-c)" strokeWidth="20" strokeLinecap="round" />
      </g>
      {/* Sparkle */}
      <circle cx="256" cy="150" r="8" fill="#fde047" filter="url(#cb-glow)" />
    </svg>
  );
}

const VARIANTS: Record<LogoVariant, { name: string; desc: string; Comp: (p: { size: number }) => ReactNode }> = {
  whitec: { name: 'C Branco', desc: 'Logo branco com C — logo oficial do software', Comp: WhiteCLogo },
  hexshield: { name: 'Escudo Hex', desc: 'Escudo hexagonal com engrenagens', Comp: HexShield },
  gearorbit: { name: 'Órbita Gear', desc: 'Engrenagem orbital em rotação', Comp: GearOrbit },
  bolt: { name: 'Raio', desc: 'Raio de energia com arco C', Comp: BoltLogo },
  minimal: { name: 'Minimal', desc: 'Limpo e geométrico', Comp: MinimalLogo },
  cube3d: { name: 'Cubo 3D', desc: 'Cubo isométrico moderno', Comp: Cube3DLogo },
};

export const LOGO_VARIANTS = VARIANTS;

export function CleviaGear({ size = 40, className = '' }: { size?: number; className?: string }) {
  const variant = useChosenLogo();
  const Comp = VARIANTS[variant].Comp;
  return <div className={className}><Comp size={size} /></div>;
}

type Props = { size?: number; showWord?: boolean; className?: string };

export default function CleviaLogo({ size = 40, showWord = true, className = '' }: Props) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <CleviaGear size={size} />
      {showWord && (
        <span className="font-extrabold tracking-tight bg-gradient-to-r from-sky-400 via-blue-500 to-blue-600 bg-clip-text text-transparent">
          CLEVIA
        </span>
      )}
    </div>
  );
}
