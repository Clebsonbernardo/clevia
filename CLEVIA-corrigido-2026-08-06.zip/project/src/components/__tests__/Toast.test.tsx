import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, act, fireEvent } from '@testing-library/react';
import { ToastProvider, useToast } from '@/components/ui';

function TestComponent() {
  const { toast } = useToast();
  return (
    <div>
      <button onClick={() => toast('success', 'Operação concluída')}>Success</button>
      <button onClick={() => toast('error', 'Algo deu errado')}>Error</button>
      <button onClick={() => toast('info', 'Informação útil')}>Info</button>
    </div>
  );
}

afterEach(() => {
  vi.useRealTimers();
});

describe('ToastProvider', () => {
  it('shows success toast when triggered', () => {
    render(
      <ToastProvider>
        <TestComponent />
      </ToastProvider>
    );

    fireEvent.click(screen.getByText('Success'));
    expect(screen.getByText('Operação concluída')).toBeInTheDocument();
  });

  it('shows error toast when triggered', () => {
    render(
      <ToastProvider>
        <TestComponent />
      </ToastProvider>
    );

    fireEvent.click(screen.getByText('Error'));
    expect(screen.getByText('Algo deu errado')).toBeInTheDocument();
  });

  it('shows info toast when triggered', () => {
    render(
      <ToastProvider>
        <TestComponent />
      </ToastProvider>
    );

    fireEvent.click(screen.getByText('Info'));
    expect(screen.getByText('Informação útil')).toBeInTheDocument();
  });

  it('auto-dismisses toast after timeout', () => {
    vi.useFakeTimers();
    render(
      <ToastProvider>
        <TestComponent />
      </ToastProvider>
    );

    fireEvent.click(screen.getByText('Success'));
    expect(screen.getByText('Operação concluída')).toBeInTheDocument();

    act(() => {
      vi.advanceTimersByTime(5000);
    });

    expect(screen.queryByText('Operação concluída')).not.toBeInTheDocument();
  });

  it('allows manual dismissal via close button', () => {
    render(
      <ToastProvider>
        <TestComponent />
      </ToastProvider>
    );

    fireEvent.click(screen.getByText('Success'));
    expect(screen.getByText('Operação concluída')).toBeInTheDocument();

    const closeButtons = screen.getAllByRole('button', { name: '' });
    fireEvent.click(closeButtons[closeButtons.length - 1]);

    expect(screen.queryByText('Operação concluída')).not.toBeInTheDocument();
  });
});
