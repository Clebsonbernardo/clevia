import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { X, CheckCircle2, AlertCircle, Info } from 'lucide-react';

export function Modal({ title, onClose, children, maxWidth = 'max-w-lg', fixed = false }: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  maxWidth?: string;
  fixed?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 md:top-16 md:left-64 md:bottom-12 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div className={`bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full ${maxWidth} max-h-[92dvh] flex flex-col border border-slate-200 dark:border-slate-800 animate-[slideUp_0.2s_ease-out]`} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 sm:px-5 sm:py-3.5 border-b border-slate-100 dark:border-slate-800 flex-shrink-0">
          <h3 className="font-black text-slate-800 dark:text-slate-50 text-lg sm:text-xl md:text-2xl truncate pr-2 drop-shadow-[0_0_8px_rgba(34,211,238,0.2)]">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 dark:text-slate-500 flex-shrink-0">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className={fixed ? 'p-4 sm:p-5 flex-1 flex flex-col min-h-0 overflow-y-auto' : 'p-4 sm:p-5 flex-1 overflow-y-auto min-h-0'}>{children}</div>
      </div>
    </div>
  );
}

export const inputCls = 'w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-600 rounded-xl text-lg font-semibold text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 transition';

export function Field({ label, children, required }: { label: string; children: ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-lg font-bold text-slate-700 dark:text-slate-200 mb-2">
        {label}{required && <span className="text-rose-500"> *</span>}
      </label>
      {children}
    </div>
  );
}

export function EmptyState({ icon: Icon, text }: { icon: typeof X; text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <Icon className="w-16 h-16 text-slate-300 dark:text-slate-600 mb-4 drop-shadow-[0_0_8px_rgba(100,116,139,0.3)]" />
      <p className="text-xl font-bold text-slate-500 dark:text-slate-400 max-w-md">{text}</p>
    </div>
  );
}

export function Spinner({ className = '' }: { className?: string }) {
  return <div className={`border-3 border-slate-200 dark:border-slate-700 border-t-cyan-500 rounded-full animate-spin ${className}`} style={{ width: '2rem', height: '2rem' }} />;
}

type ToastType = 'success' | 'error' | 'info';
interface Toast { id: number; type: ToastType; message: string; }

const ToastContext = createContext<{ toast: (type: ToastType, message: string) => void }>({ toast: () => {} });
export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toast = useCallback((type: ToastType, message: string) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4000);
  }, []);
  const icons = { success: CheckCircle2, error: AlertCircle, info: Info };
  const colors = {
    success: 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300',
    error: 'bg-rose-50 dark:bg-rose-950/80 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300',
    info: 'bg-cyan-50 dark:bg-cyan-950/80 border-cyan-200 dark:border-cyan-800 text-cyan-800 dark:text-cyan-300',
  };
  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 max-w-sm">
        {toasts.map((t) => {
          const Icon = icons[t.type];
          return (
            <div key={t.id} className={`flex items-start gap-3 px-4 py-3 rounded-xl border shadow-lg animate-[slideUp_0.2s_ease-out] ${colors[t.type]}`}>
              <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <p className="text-sm font-medium flex-1">{t.message}</p>
              <button onClick={() => setToasts((prev) => prev.filter((x) => x.id !== t.id))} className="flex-shrink-0 opacity-60 hover:opacity-100">
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}
