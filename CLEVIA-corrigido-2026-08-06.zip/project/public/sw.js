// Service worker for CLEVIA — push notifications + offline caching

const CACHE_NAME = "clevia-v7";
const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/icon-192.png",
  "/icon-512.png",
  "/logo.svg",
  "/logos/bolt.svg",
  "/logos/bolt-192.png",
  "/logos/bolt-512.png",
];

// ─── Install: pre-cache static assets ───
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS)).then(() => self.skipWaiting())
  );
});

// ─── Activate: copy old cached assets into new cache before deleting old caches ───
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      const oldKeys = keys.filter((k) => k !== CACHE_NAME);
      if (oldKeys.length === 0) return Promise.resolve();
      // Copy all entries from old caches into the new cache, then delete old caches
      return Promise.all(
        oldKeys.map((oldKey) =>
          caches.open(oldKey).then((oldCache) =>
            oldCache.keys().then((oldReqs) =>
              Promise.all(
                oldReqs.map((oldReq) =>
                  oldCache.match(oldReq).then((oldResp) =>
                    caches.open(CACHE_NAME).then((newCache) => newCache.put(oldReq, oldResp))
                  )
                )
              )
            )
          )
        )
      ).then(() => Promise.all(oldKeys.map((k) => caches.delete(k))));
    }).then(() => self.clients.claim())
  );
});

// ─── Fetch: network-first for navigation, cache-first for assets ───
self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Skip non-GET and Supabase API calls
  if (req.method !== "GET" || req.url.includes("supabase.co") || req.url.includes("/functions/")) {
    return;
  }

  // Navigation requests: network-first, fallback to cached page
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((resp) => {
          const copy = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          return resp;
        })
        .catch(() => caches.match(req).then((cached) => cached || caches.match("/index.html")))
    );
    return;
  }

  // Same-origin assets (JS, CSS, fonts, images): cache-first, cache on fetch
  const url = new URL(req.url);
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((resp) => {
          if (resp.ok) {
            const copy = resp.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          }
          return resp;
        }).catch(() => cached);
      })
    );
  }
});

// ─── Message: allow app to trigger skipWaiting on new SW ───
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

// ─── Push notifications ───
self.addEventListener("push", (event) => {
  let data;
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = {};
  }

  const title = data.title || "CLEVIA";
  const body = data.body || "Nova notificação";
  const url = data.url || "/";

  const isOsUrgent = data.tag === "clevia-os-urgent" || data.tag === "clevia-os-reminder";

  let options;
  if (isOsUrgent) {
    options = {
      body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      data: { url },
      tag: data.tag || "clevia-os-urgent",
      renotify: true,
      requireInteraction: true,
      silent: false,
      vibrate: [500, 200, 500, 200, 500, 200, 800, 200, 500, 200, 500, 200, 800],
      actions: [{ action: "view", title: "Ver OS" }],
    };
  } else {
    const isReminder = data.tag === "clevia-reminder";
    options = {
      body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      data: { url },
      tag: isReminder ? "clevia-reminder" : "clevia-os-" + Date.now(),
      renotify: true,
      requireInteraction: isReminder ? false : true,
      silent: false,
      vibrate: isReminder ? [400, 150, 400, 150, 600] : [300, 100, 300, 100, 400],
    };
  }

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((clientList) => {
        for (const client of clientList) {
          if ("focus" in client && "navigate" in client) {
            client.focus();
            client.navigate(url);
            return;
          }
        }
        return self.clients.openWindow(url);
      })
  );
});
